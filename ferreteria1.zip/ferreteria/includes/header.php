<?php
require_once __DIR__ . '/auth.php';
Auth::requireLogin();
$user    = Auth::currentUser();
$empresa = getSetting('empresa_nombre') ?: 'Ferretería La Curva';
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle).' — ' : '' ?><?= htmlspecialchars($empresa) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet">
<link href="<?= APP_URL ?>/css/app.css" rel="stylesheet">
</head>
<body>
<div class="wrapper">

<!-- SIDEBAR -->
<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="bi bi-shop-window"></i>
            <span><?= htmlspecialchars($empresa) ?></span>

        </div>
    </div>
    <ul class="sidebar-menu">
        <li><a href="<?= APP_URL ?>/index.php" class="<?= basename($_SERVER['PHP_SELF'])=='index.php'?'active':'' ?>">
            <i class="bi bi-speedometer2"></i><span>Dashboard</span></a></li>

        <li class="menu-header">Ventas</li>
        <li><a href="<?= APP_URL ?>/modules/ventas/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/ventas/')!==false?'active':'' ?>">
            <i class="bi bi-cart3"></i><span>Ventas</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/clientes/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/clientes/')!==false?'active':'' ?>">
            <i class="bi bi-people"></i><span>Clientes</span></a></li>

        <li class="menu-header">Inventario</li>
        <li><a href="<?= APP_URL ?>/modules/compras/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/compras/')!==false?'active':'' ?>">
            <i class="bi bi-truck"></i><span>Compras / Ingresos</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/productos/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/productos/')!==false?'active':'' ?>">
            <i class="bi bi-box-seam"></i><span>Productos</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/existencias/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/existencias/')!==false?'active':'' ?>">
            <i class="bi bi-clipboard-data"></i><span>Existencias</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/proveedores/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/proveedores/')!==false?'active':'' ?>">
            <i class="bi bi-building"></i><span>Proveedores</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/categorias/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/categorias/')!==false?'active':'' ?>">
            <i class="bi bi-tags"></i><span>Categorías</span></a></li>

        <li class="menu-header">Operaciones</li>
        <li><a href="<?= APP_URL ?>/modules/gastos/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/gastos/')!==false?'active':'' ?>">
            <i class="bi bi-receipt"></i><span>Gastos Empresa</span></a></li>

        <li class="menu-header">Reportes</li>
        <li><a href="<?= APP_URL ?>/modules/reportes/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/reportes/')!==false?'active':'' ?>">
            <i class="bi bi-bar-chart-line"></i><span>Reportes</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/pagos/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/pagos/')!==false?'active':'' ?>">
            <i class="bi bi-cash-coin"></i><span>Pagos Pendientes</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/exportar/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/exportar/')!==false?'active':'' ?>">
            <i class="bi bi-file-earmark-excel"></i><span>Exportar a Excel</span></a></li>

        <?php if (Auth::isAdmin()): ?>
        <li class="menu-header">Admin</li>
        <li><a href="<?= APP_URL ?>/modules/usuarios/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/usuarios/')!==false?'active':'' ?>">
            <i class="bi bi-person-gear"></i><span>Usuarios</span></a></li>
        <li><a href="<?= APP_URL ?>/modules/configuracion/index.php" class="<?= strpos($_SERVER['PHP_SELF'],'/configuracion/')!==false?'active':'' ?>">
            <i class="bi bi-gear"></i><span>Configuración</span></a></li>
        <?php endif; ?>
    </ul>
</nav>

<div id="content">
<!-- NAVBAR TOP -->
<nav class="navbar-top">
    <div class="navbar-top-left">
        <button class="btn-toggle" id="sidebarToggle" aria-label="Abrir/cerrar menú">
            <i class="bi bi-list"></i>
        </button>
    </div>
    <div class="navbar-top-right">
        <div class="dropdown">
            <button class="btn btn-link dropdown-toggle text-decoration-none d-flex align-items-center gap-1 px-2"
                    data-bs-toggle="dropdown" aria-expanded="false" style="color:#374151">
                <i class="bi bi-person-circle fs-5"></i>
                <span class="navbar-user-name"><?= htmlspecialchars($user['nombre']) ?></span>
                <small class="navbar-user-role ms-1">(<?= htmlspecialchars($user['rol']) ?>)</small>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                <li>
                    <span class="dropdown-item-text text-muted" style="font-size:.8rem">
                        <?= htmlspecialchars($user['nombre']) ?><br>
                        <small><?= htmlspecialchars($user['rol']) ?></small>
                    </span>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= APP_URL ?>/logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="main-content">

<?php
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) session_start();

class Auth {
    public static function login($user, $pass) {
        $db  = Database::getInstance();
        $row = $db->fetchOne(
            "SELECT u.*, r.nombre as rol_nombre, r.permisos
             FROM usuarios u JOIN roles r ON u.rol_id = r.id
             WHERE (u.username = ? OR u.email = ?) AND u.activo = 1",
            array($user, $user)
        );
        if ($row && password_verify($pass, $row['password'])) {
            $db->query('UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?', array($row['id']));
            $_SESSION['user_id']      = $row['id'];
            $_SESSION['user_nombre']  = $row['nombre'] . ' ' . $row['apellido'];
            $_SESSION['user_email']   = $row['email'];
            $_SESSION['user_rol']     = $row['rol_nombre'];
            $_SESSION['user_rol_id']  = $row['rol_id'];
            $_SESSION['user_permisos']= json_decode($row['permisos'], true) ?: array();
            $_SESSION['logged_in']    = true;
            session_regenerate_id(true); // evita session fixation
            return true;
        }
        return false;
    }

    public static function logout() {
        $_SESSION = array();
        if (isset($_COOKIE[session_name()]))
            setcookie(session_name(), '', time() - 3600, '/');
        session_destroy();
        header('Location: ' . APP_URL . '/login.php');
        exit;
    }

    public static function isLoggedIn()  { return !empty($_SESSION['logged_in']); }
    public static function isAdmin()     { return isset($_SESSION['user_rol_id']) && $_SESSION['user_rol_id'] == 1; }

    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header('Location: ' . APP_URL . '/login.php');
            exit;
        }
    }

    public static function currentUser() {
        return array(
            'id'     => isset($_SESSION['user_id'])     ? $_SESSION['user_id']     : null,
            'nombre' => isset($_SESSION['user_nombre']) ? $_SESSION['user_nombre'] : '',
            'rol'    => isset($_SESSION['user_rol'])    ? $_SESSION['user_rol']    : '',
        );
    }
}

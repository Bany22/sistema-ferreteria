<?php
// ============================================================
// FERRETERÍA LA CURVA — Configuración del Sistema
// Optimizado para XAMPP 8.2.12
//   PHP:     8.2.12
//   MariaDB: 10.4.32
//   Apache:  2.4.58
// ============================================================

// ── Base de datos ────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_USER',    'root');
define('DB_PASS',    '');          // XAMPP default: root sin contraseña
define('DB_NAME',    'sistema_ventas');
define('DB_PORT',    3306);
define('DB_CHARSET', 'utf8mb4');

// ── Aplicación ───────────────────────────────────────────────
define('APP_NAME', 'Ferretería La Curva');
define('APP_URL',  'http://localhost/ferreteria');  // ← carpeta en htdocs
define('APP_PATH', __DIR__ . '/..');

// ── Entorno ──────────────────────────────────────────────────
// DESARROLLO: true → muestra errores en pantalla
// PRODUCCIÓN: false → oculta errores, los guarda en log
define('DEBUG_MODE', true);   // ← cambiar a false al entregar al cliente

// ── Zona horaria ─────────────────────────────────────────────
date_default_timezone_set('America/Guatemala');

// ── Manejo de errores según entorno ──────────────────────────
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

// ── Seguridad de sesión ───────────────────────────────────────
ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');

// ============================================================
// BASE DE DATOS — PDO Singleton
// Compatibilidad: MariaDB 10.4.32 / MySQL 8.0
// ============================================================
class Database {
    private static ?Database $instance = null;
    private \PDO $conn;

    private function __construct() {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
            );
            $this->conn = new \PDO($dsn, DB_USER, DB_PASS, [
                \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                \PDO::ATTR_EMULATE_PREPARES   => false,
                \PDO::MYSQL_ATTR_INIT_COMMAND =>
                    "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci,
                         time_zone = '-06:00'",   // GMT-6 Guatemala
            ]);
        } catch (\PDOException $e) {
            $msg = DEBUG_MODE
                ? 'Error BD: ' . $e->getMessage()
                : 'Error de conexión. Contacte al administrador.';
            die($msg);
        }
    }

    public static function getInstance(): static {
        if (!static::$instance) static::$instance = new static();
        return static::$instance;
    }

    public function query(string $sql, array $p = []): \PDOStatement {
        $s = $this->conn->prepare($sql);
        $s->execute($p);
        return $s;
    }

    public function fetchAll(string $sql, array $p = []): array {
        return $this->query($sql, $p)->fetchAll();
    }

    public function fetchOne(string $sql, array $p = []): array|false {
        return $this->query($sql, $p)->fetch();
    }

    public function lastInsertId(): string|false {
        return $this->conn->lastInsertId();
    }

    public function beginTransaction(): bool { return $this->conn->beginTransaction(); }
    public function commit(): bool           { return $this->conn->commit(); }
    public function rollback(): bool         { return $this->conn->rollBack(); }
}

// ============================================================
// HELPERS
// ============================================================

/** Lee configuración del sistema desde la tabla `configuracion` */
function getSetting(string $key): ?string {
    static $cfg = [];
    if (empty($cfg)) {
        try {
            $rows = Database::getInstance()->fetchAll(
                'SELECT clave, valor FROM configuracion'
            );
            $cfg = array_column($rows, 'valor', 'clave');
        } catch (\Exception) {
            $cfg = [];
        }
    }
    return $cfg[$key] ?? null;
}

/** Genera folio correlativo: ej. VTA-000001 */
function generarFolio(string $prefijo, string $tipo): string {
    $db    = Database::getInstance();
    $clave = 'folio_' . $tipo . '_contador';
    $db->query(
        'UPDATE configuracion SET valor = valor + 1 WHERE clave = ?',
        [$clave]
    );
    $row = $db->fetchOne(
        'SELECT valor FROM configuracion WHERE clave = ?',
        [$clave]
    );
    $num = $row ? str_pad((int)$row['valor'], 6, '0', STR_PAD_LEFT) : '000001';
    return $prefijo . '-' . $num;
}

/** Formatea moneda en Quetzales */
function formatMoney(float|int|string $v): string {
    return 'Q ' . number_format((float)$v, 2, '.', ',');
}

/** Sanitiza input del usuario */
function sanitize(string $v): string {
    return htmlspecialchars(strip_tags(trim($v)), ENT_QUOTES, 'UTF-8');
}

/** Respuesta JSON y termina ejecución */
function jsonResponse(mixed $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
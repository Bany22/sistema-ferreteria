<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
if (!Auth::isAdmin()) { header('Location: ' . APP_URL . '/index.php'); exit; }
$db = Database::getInstance();

// ── Acciones GET ────────────────────────────────────────────────
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id     = (int)($_GET['id'] ?? 0);

    if ($action === 'toggle' && $id && $id != $_SESSION['user_id']) {
        $r = $db->fetchOne("SELECT activo FROM usuarios WHERE id=?", [$id]);
        if ($r) $db->query("UPDATE usuarios SET activo=? WHERE id=?", [$r['activo'] ? 0 : 1, $id]);
        header('Location: index.php?ok=toggle'); exit;
    }
    if ($action === 'delete_rol' && $id) {
        $inUse = $db->fetchOne("SELECT COUNT(*) as n FROM usuarios WHERE rol_id=?", [$id]);
        if ($inUse['n'] > 0) {
            header('Location: index.php?err=rol_en_uso'); exit;
        }
        $db->query("DELETE FROM roles WHERE id=?", [$id]);
        header('Location: index.php?ok=rol_eliminado'); exit;
    }
}

$error = '';

// ── Guardar Usuario (POST) ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'usuario') {
    $nombre   = trim($_POST['nombre']   ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $username = trim($_POST['username'] ?? '');
    $rol_id   = (int)($_POST['rol_id']  ?? 1);
    $telefono = trim($_POST['telefono'] ?? '');
    $activo   = isset($_POST['activo']) ? 1 : 0;
    $password = $_POST['password'] ?? '';
    $id       = (int)($_POST['id'] ?? 0);

    if (empty($nombre) || empty($email) || empty($username)) {
        $error = 'Nombre, email y usuario son obligatorios.';
    } else {
        try {
            if ($id) {
                if (!empty($password)) {
                    $db->query(
                        "UPDATE usuarios SET nombre=?,apellido=?,email=?,username=?,rol_id=?,telefono=?,activo=?,password=? WHERE id=?",
                        [$nombre,$apellido,$email,$username,$rol_id,$telefono,$activo,password_hash($password,PASSWORD_DEFAULT),$id]
                    );
                } else {
                    $db->query(
                        "UPDATE usuarios SET nombre=?,apellido=?,email=?,username=?,rol_id=?,telefono=?,activo=? WHERE id=?",
                        [$nombre,$apellido,$email,$username,$rol_id,$telefono,$activo,$id]
                    );
                }
            } else {
                if (empty($password)) { $error = 'La contraseña es obligatoria para nuevos usuarios.'; }
                else {
                    $db->query(
                        "INSERT INTO usuarios (nombre,apellido,email,username,rol_id,telefono,activo,password) VALUES (?,?,?,?,?,?,?,?)",
                        [$nombre,$apellido,$email,$username,$rol_id,$telefono,$activo,password_hash($password,PASSWORD_DEFAULT)]
                    );
                }
            }
            if (!$error) { header('Location: index.php?ok=usuario'); exit; }
        } catch (Exception $e) { $error = 'Error: ' . $e->getMessage(); }
    }
}

// ── Guardar Rol (POST) ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'rol') {
    $rnombre = trim($_POST['rol_nombre'] ?? '');
    $rdesc   = trim($_POST['rol_desc']   ?? '');
    $rid     = (int)($_POST['rol_id']    ?? 0);
    if (empty($rnombre)) {
        $error = 'El nombre del rol es obligatorio.';
    } else {
        try {
            if ($rid) {
                $db->query("UPDATE roles SET nombre=?,descripcion=? WHERE id=?", [$rnombre,$rdesc,$rid]);
            } else {
                $db->query("INSERT INTO roles (nombre,descripcion,permisos) VALUES (?,?,?)", [$rnombre,$rdesc,'{}']);
            }
            header('Location: index.php?ok=rol'); exit;
        } catch (Exception $e) { $error = 'Error: ' . $e->getMessage(); }
    }
}

$pageTitle = 'Usuarios y Roles';
require_once __DIR__ . '/../../includes/header.php';
$usuarios = $db->fetchAll("SELECT u.*, r.nombre as rol FROM usuarios u JOIN roles r ON u.rol_id=r.id ORDER BY u.nombre");
$roles    = $db->fetchAll("SELECT r.*, (SELECT COUNT(*) FROM usuarios u WHERE u.rol_id=r.id) as total_usuarios FROM roles r ORDER BY r.id");
?>

<?php if (isset($_GET['ok'])): ?>
<div class="alert alert-success alert-auto-close">
    <i class="bi bi-check-circle me-2"></i>
    <?= $_GET['ok']==='usuario' ? 'Usuario guardado correctamente.' : ($_GET['ok']==='rol' ? 'Rol guardado correctamente.' : ($_GET['ok']==='rol_eliminado' ? 'Rol eliminado.' : 'Cambio aplicado.')) ?>
</div>
<?php endif; ?>
<?php if (isset($_GET['err']) && $_GET['err']==='rol_en_uso'): ?>
<div class="alert alert-danger alert-auto-close"><i class="bi bi-exclamation-triangle me-2"></i>No se puede eliminar: el rol tiene usuarios asignados.</div>
<?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-people me-2 text-primary"></i>Usuarios y Roles</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Usuarios</li>
        </ol></nav>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalRol" onclick="resetRolForm()">
            <i class="bi bi-shield-plus me-1"></i>Nuevo Rol
        </button>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalUser" onclick="resetUserForm()">
            <i class="bi bi-person-plus me-1"></i>Nuevo Usuario
        </button>
    </div>
</div>

<!-- ── TABS ─────────────────────────────────────────────────────── -->
<ul class="nav nav-tabs mb-3" id="tabsMain">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabUsuarios"><i class="bi bi-person-gear me-1"></i>Usuarios <span class="badge bg-primary ms-1"><?= count($usuarios) ?></span></button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabRoles"><i class="bi bi-shield-check me-1"></i>Roles <span class="badge bg-secondary ms-1"><?= count($roles) ?></span></button></li>
</ul>

<!-- ── TAB USUARIOS ─────────────────────────────────────────────── -->
<div class="tab-content">
<div class="tab-pane fade show active" id="tabUsuarios">
<div class="card"><div class="card-body p-0">
    <div class="table-responsive">
    <table class="table table-hover mb-0" id="tblUsers">
        <thead><tr>
            <th>#</th><th>Nombre</th><th>Usuario</th><th>Email</th>
            <th>Rol</th><th>Teléfono</th><th>Último Login</th><th>Estado</th><th>Acciones</th>
        </tr></thead>
        <tbody>
        <?php foreach ($usuarios as $u): ?>
        <tr>
            <td class="text-muted"><?= $u['id'] ?></td>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="avatar-circle bg-primary"><?= strtoupper(substr($u['nombre'],0,1)) ?></div>
                    <div>
                        <div class="fw-semibold"><?= htmlspecialchars($u['nombre'].' '.$u['apellido']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($u['email']) ?></small>
                    </div>
                </div>
            </td>
            <td><code><?= htmlspecialchars($u['username']) ?></code></td>
            <td class="col-hide-sm"><?= htmlspecialchars($u['email']) ?></td>
            <td><span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25"><?= htmlspecialchars($u['rol']) ?></span></td>
            <td class="col-hide-md"><?= htmlspecialchars($u['telefono'] ?: '—') ?></td>
            <td class="col-hide-md"><?= $u['ultimo_login'] ? date('d/m/Y H:i', strtotime($u['ultimo_login'])) : '<span class="text-muted">Nunca</span>' ?></td>
            <td><span class="badge-<?= $u['activo'] ? 'activo' : 'inactivo' ?>"><?= $u['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
            <td class="table-actions">
                <button class="btn btn-sm btn-outline-warning" title="Editar" onclick="editUser(<?= htmlspecialchars(json_encode($u)) ?>)">
                    <i class="bi bi-pencil"></i>
                </button>
                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                <a href="?action=toggle&id=<?= $u['id'] ?>"
                   class="btn btn-sm <?= $u['activo'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-delete"
                   data-msg="<?= $u['activo'] ? '¿Desactivar este usuario?' : '¿Activar este usuario?' ?>">
                    <i class="bi bi-<?= $u['activo'] ? 'person-slash' : 'person-check' ?>"></i>
                </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div></div>
</div>

<!-- ── TAB ROLES ─────────────────────────────────────────────────── -->
<div class="tab-pane fade" id="tabRoles">
<div class="row g-3">
<?php foreach ($roles as $rol): ?>
<div class="col-md-6 col-lg-4">
    <div class="card h-100">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div class="d-flex align-items-center gap-2">
                    <div class="stat-icon blue" style="width:38px;height:38px;font-size:.95rem">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 fw-bold"><?= htmlspecialchars($rol['nombre']) ?></h6>
                        <small class="text-muted"><?= $rol['total_usuarios'] ?> usuario<?= $rol['total_usuarios']!=1?'s':'' ?></small>
                    </div>
                </div>
                <div class="d-flex gap-1">
                    <button class="btn btn-sm btn-outline-warning" title="Editar rol"
                        onclick="editRol(<?= htmlspecialchars(json_encode($rol)) ?>)">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <?php if ($rol['total_usuarios'] == 0): ?>
                    <a href="?action=delete_rol&id=<?= $rol['id'] ?>" class="btn btn-sm btn-outline-danger btn-delete"
                       data-msg="¿Eliminar el rol '<?= htmlspecialchars($rol['nombre']) ?>'?">
                        <i class="bi bi-trash"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ($rol['descripcion']): ?>
            <p class="text-muted small mb-0"><?= htmlspecialchars($rol['descripcion']) ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>

<div class="col-md-6 col-lg-4">
    <div class="card h-100 border-dashed" style="border:2px dashed #e2e8f0;">
        <div class="card-body d-flex align-items-center justify-content-center">
            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalRol" onclick="resetRolForm()">
                <i class="bi bi-plus-circle me-1"></i>Nuevo Rol
            </button>
        </div>
    </div>
</div>
</div>
</div><!-- /tab-pane roles -->
</div><!-- /tab-content -->

<!-- ══════════════════════════════════════════════════════════════
     MODAL USUARIO
══════════════════════════════════════════════════════════════ -->
<div class="modal fade" id="modalUser" tabindex="-1">
<div class="modal-dialog modal-lg"><div class="modal-content">
<form method="POST">
<input type="hidden" name="form_type" value="usuario">
<input type="hidden" name="id" id="fId">
<div class="modal-header bg-primary text-white">
    <h5 class="modal-title" id="mTitle"><i class="bi bi-person-gear me-2"></i>Nuevo Usuario</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nombre *</label>
        <input type="text" name="nombre" id="fNombre" class="form-control" required placeholder="Nombre">
    </div>
    <div class="col-md-6">
        <label class="form-label">Apellido</label>
        <input type="text" name="apellido" id="fApellido" class="form-control" placeholder="Apellido">
    </div>
    <div class="col-md-6">
        <label class="form-label">Usuario (login) *</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-at"></i></span>
            <input type="text" name="username" id="fUsername" class="form-control" required placeholder="username">
        </div>
    </div>
    <div class="col-md-6">
        <label class="form-label">Email *</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
            <input type="email" name="email" id="fEmail" class="form-control" required placeholder="correo@ejemplo.com">
        </div>
    </div>
    <div class="col-md-6">
        <label class="form-label">Rol *</label>
        <select name="rol_id" id="fRol" class="form-select" required>
            <?php foreach ($roles as $r): ?>
            <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-6">
        <label class="form-label">Teléfono</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-telephone"></i></span>
            <input type="text" name="telefono" id="fTel" class="form-control" placeholder="00000000">
        </div>
    </div>
    <div class="col-12">
        <label class="form-label">Contraseña <small id="pwdNote" class="text-muted fw-normal">(obligatoria)</small></label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock"></i></span>
            <input type="password" name="password" id="fPwd" class="form-control" placeholder="Contraseña segura">
            <button type="button" class="btn btn-outline-secondary" id="btnShowPwd">
                <i class="bi bi-eye"></i>
            </button>
        </div>
    </div>
    <div class="col-12">
        <div class="form-check form-switch">
            <input type="checkbox" name="activo" id="fActivo" class="form-check-input" value="1" checked>
            <label class="form-check-label" for="fActivo">Usuario Activo</label>
        </div>
    </div>
</div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar Usuario</button>
</div>
</form>
</div></div>
</div>

<!-- ══════════════════════════════════════════════════════════════
     MODAL ROL
══════════════════════════════════════════════════════════════ -->
<div class="modal fade" id="modalRol" tabindex="-1">
<div class="modal-dialog"><div class="modal-content">
<form method="POST">
<input type="hidden" name="form_type" value="rol">
<input type="hidden" name="rol_id" id="rId">
<div class="modal-header bg-primary text-white">
    <h5 class="modal-title" id="rTitle"><i class="bi bi-shield-plus me-2"></i>Nuevo Rol</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<div class="row g-3">
    <div class="col-12">
        <label class="form-label">Nombre del Rol *</label>
        <input type="text" name="rol_nombre" id="rNombre" class="form-control" required placeholder="Ej: Supervisor, Cajero...">
    </div>
    <div class="col-12">
        <label class="form-label">Descripción</label>
        <textarea name="rol_desc" id="rDesc" class="form-control" rows="3" placeholder="Describe los permisos o funciones de este rol..."></textarea>
    </div>
    <div class="col-12">
        <div class="alert alert-info mb-0 py-2">
            <i class="bi bi-info-circle me-1"></i>
            <small>El rol <strong>Administrador</strong> tiene acceso total. Los demás roles tienen acceso según lo configure en el código.</small>
        </div>
    </div>
</div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar Rol</button>
</div>
</form>
</div></div>
</div>

<style>
.avatar-circle {
    width: 34px; height: 34px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    color: #fff; font-weight: 700; font-size: .85rem; flex-shrink: 0;
}
</style>
<script>
$(document).ready(function () {
    $('#tblUsers').DataTable();

    /* Mostrar/ocultar contraseña */
    $('#btnShowPwd').on('click', function () {
        var inp = $('#fPwd');
        var isPass = inp.attr('type') === 'password';
        inp.attr('type', isPass ? 'text' : 'password');
        $(this).find('i').toggleClass('bi-eye bi-eye-slash');
    });
});

function resetUserForm() {
    document.getElementById('fId').value = '';
    document.getElementById('mTitle').innerHTML = '<i class="bi bi-person-gear me-2"></i>Nuevo Usuario';
    document.getElementById('pwdNote').textContent = '(obligatoria)';
    ['fNombre','fApellido','fUsername','fEmail','fTel','fPwd'].forEach(function(id){
        document.getElementById(id).value = '';
    });
    document.getElementById('fRol').selectedIndex = 0;
    document.getElementById('fActivo').checked = true;
    document.getElementById('fPwd').setAttribute('type','password');
}

function editUser(u) {
    document.getElementById('fId').value       = u.id;
    document.getElementById('mTitle').innerHTML = '<i class="bi bi-pencil me-2"></i>Editar Usuario';
    document.getElementById('pwdNote').textContent = '(dejar en blanco para no cambiar)';
    document.getElementById('fNombre').value   = u.nombre   || '';
    document.getElementById('fApellido').value = u.apellido || '';
    document.getElementById('fUsername').value = u.username || '';
    document.getElementById('fEmail').value    = u.email    || '';
    document.getElementById('fTel').value      = u.telefono || '';
    document.getElementById('fPwd').value      = '';
    document.getElementById('fRol').value      = u.rol_id;
    document.getElementById('fActivo').checked = u.activo == 1;
    document.getElementById('fPwd').setAttribute('type','password');
    new bootstrap.Modal(document.getElementById('modalUser')).show();
}

function resetRolForm() {
    document.getElementById('rId').value    = '';
    document.getElementById('rTitle').innerHTML = '<i class="bi bi-shield-plus me-2"></i>Nuevo Rol';
    document.getElementById('rNombre').value = '';
    document.getElementById('rDesc').value   = '';
}

function editRol(r) {
    document.getElementById('rId').value     = r.id;
    document.getElementById('rTitle').innerHTML = '<i class="bi bi-pencil me-2"></i>Editar Rol';
    document.getElementById('rNombre').value = r.nombre      || '';
    document.getElementById('rDesc').value   = r.descripcion || '';
    new bootstrap.Modal(document.getElementById('modalRol')).show();
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

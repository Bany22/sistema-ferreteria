<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$pageTitle = 'Mi Perfil';
require_once __DIR__ . '/../../includes/header.php';
$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$user = $db->fetchOne("SELECT u.*, r.nombre as rol FROM usuarios u JOIN roles r ON u.rol_id=r.id WHERE u.id=?", [$userId]);
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $pwdActual = $_POST['pwd_actual'] ?? '';
    $pwdNueva = $_POST['pwd_nueva'] ?? '';
    $pwdConf = $_POST['pwd_conf'] ?? '';

    if (empty($nombre)) { $error = 'El nombre es obligatorio.'; }
    else {
        $db->query("UPDATE usuarios SET nombre=?,apellido=?,email=?,telefono=? WHERE id=?", [$nombre,$apellido,$email,$telefono,$userId]);
        $_SESSION['user_nombre'] = $nombre . ' ' . $apellido;

        if (!empty($pwdActual)) {
            if (!password_verify($pwdActual, $user['password'])) {
                $error = 'La contraseña actual no es correcta.';
            } elseif ($pwdNueva !== $pwdConf) {
                $error = 'Las contraseñas nuevas no coinciden.';
            } elseif (strlen($pwdNueva) < 6) {
                $error = 'La contraseña debe tener al menos 6 caracteres.';
            } else {
                $db->query("UPDATE usuarios SET password=? WHERE id=?", [password_hash($pwdNueva, PASSWORD_DEFAULT), $userId]);
                $success = 'Perfil y contraseña actualizados.';
            }
        } else {
            $success = 'Perfil actualizado exitosamente.';
        }
        $user = $db->fetchOne("SELECT u.*, r.nombre as rol FROM usuarios u JOIN roles r ON u.rol_id=r.id WHERE u.id=?", [$userId]);
    }
}
?>

<?php if ($success): ?><div class="alert alert-success alert-auto-close"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="page-header">
    <div><h1><i class="bi bi-person-circle me-2 text-primary"></i>Mi Perfil</h1></div>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card text-center">
            <div class="card-body py-4">
                <div style="width:80px;height:80px;background:#eff6ff;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:2rem;color:#2563eb">
                    <i class="bi bi-person"></i>
                </div>
                <h5 class="fw-bold"><?= htmlspecialchars($user['nombre'] . ' ' . $user['apellido']) ?></h5>
                <span class="badge bg-primary"><?= htmlspecialchars($user['rol']) ?></span>
                <p class="text-muted small mt-2"><?= htmlspecialchars($user['email']) ?></p>
                <p class="text-muted small">Último login: <?= $user['ultimo_login'] ? date('d/m/Y H:i', strtotime($user['ultimo_login'])) : 'N/A' ?></p>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <form method="POST">
        <div class="card mb-4">
            <div class="card-header">Información Personal</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6"><label class="form-label">Nombre *</label><input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($user['nombre']) ?>" required></div>
                    <div class="col-md-6"><label class="form-label">Apellido</label><input type="text" name="apellido" class="form-control" value="<?= htmlspecialchars($user['apellido']) ?>"></div>
                    <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>"></div>
                    <div class="col-md-6"><label class="form-label">Teléfono</label><input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($user['telefono'] ?? '') ?>"></div>
                </div>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header">Cambiar Contraseña</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-12"><label class="form-label">Contraseña Actual</label><input type="password" name="pwd_actual" class="form-control" placeholder="Ingrese su contraseña actual"></div>
                    <div class="col-md-6"><label class="form-label">Nueva Contraseña</label><input type="password" name="pwd_nueva" class="form-control"></div>
                    <div class="col-md-6"><label class="form-label">Confirmar Nueva</label><input type="password" name="pwd_conf" class="form-control"></div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar Cambios</button>
        </form>
    </div>
</div>

<script>const APP_URL = '<?= APP_URL ?>';</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// ── GUARDAR (crear o editar) ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int)(isset($_POST['edit_id']) ? $_POST['edit_id'] : 0);
    $nombre = trim(isset($_POST['nombre']) ? $_POST['nombre'] : '');
    $desc   = trim(isset($_POST['descripcion']) ? $_POST['descripcion'] : '');
    $tipo   = isset($_POST['tipo']) ? $_POST['tipo'] : 'otros';
    $activo = isset($_POST['activo']) ? 1 : 0;

    $tiposValidos = ['compra_productos','materiales','servicios','nomina','otros'];
    if (!in_array($tipo, $tiposValidos)) $tipo = 'otros';

    if ($nombre === '') {
        $err = 'El nombre de la categoría es obligatorio.';
    } else {
        try {
            if ($editId) {
                $db->query(
                    'UPDATE gastos_categorias SET nombre=?, descripcion=?, tipo=?, activo=? WHERE id=?',
                    [$nombre, $desc ?: null, $tipo, $activo, $editId]
                );
                $msg = 'Categoría actualizada correctamente.';
            } else {
                $db->query(
                    'INSERT INTO gastos_categorias (nombre, descripcion, tipo, activo) VALUES (?,?,?,?)',
                    [$nombre, $desc ?: null, $tipo, 1]
                );
                $msg = 'Categoría creada correctamente.';
            }
        } catch (Exception $e) {
            $err = 'Error: ' . $e->getMessage();
        }
    }
}

// ── ELIMINAR ─────────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'eliminar') {
    $delId = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    try {
        // Verificar si tiene gastos asociados
        $uso = $db->fetchOne('SELECT COUNT(*) AS n FROM gastos WHERE categoria_id=? AND activo=1', [$delId]);
        if ($uso && $uso['n'] > 0) {
            $err = 'No se puede eliminar: esta categoría tiene ' . $uso['n'] . ' gasto(s) asociado(s).';
        } else {
            $db->query('DELETE FROM gastos_categorias WHERE id=?', [$delId]);
            $msg = 'Categoría eliminada.';
        }
    } catch (Exception $e) {
        $err = 'Error: ' . $e->getMessage();
    }
}

// ── EDITAR: cargar datos ──────────────────────────────────────
$editando = null;
if (isset($_GET['action']) && $_GET['action'] === 'editar') {
    $editando = $db->fetchOne('SELECT * FROM gastos_categorias WHERE id=?', [(int)$_GET['id']]);
}

$categorias = $db->fetchAll('SELECT * FROM gastos_categorias ORDER BY nombre');

$tipoLabel = [
    'compra_productos' => 'Compra de Productos',
    'materiales'       => 'Materiales',
    'nomina'           => 'Nómina / Trabajadores',
    'servicios'        => 'Servicios',
    'otros'            => 'Otros',
];
$tipoBadge = [
    'compra_productos' => 'primary',
    'materiales'       => 'info',
    'nomina'           => 'warning',
    'servicios'        => 'secondary',
    'otros'            => 'dark',
];

$pageTitle = 'Categorías de Gastos';
require_once __DIR__ . '/../../../includes/header.php';
?>

<?php if ($msg): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-tags me-2 text-warning"></i>Categorías de Gastos</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="../index.php">Gastos</a></li>
            <li class="breadcrumb-item active">Categorías</li>
        </ol></nav>
    </div>
    <a href="../index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver a Gastos</a>
</div>

<div class="row g-4">

    <!-- ── Formulario crear/editar ────────────────────── -->
    <div class="col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header fw-semibold <?= $editando ? 'bg-warning text-dark' : 'bg-dark text-white' ?>">
                <i class="bi bi-<?= $editando ? 'pencil-square' : 'plus-circle' ?> me-2"></i>
                <?= $editando ? 'Editar Categoría' : 'Nueva Categoría' ?>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php if ($editando): ?>
                    <input type="hidden" name="edit_id" value="<?= $editando['id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nombre <span class="text-danger">*</span></label>
                        <input type="text" name="nombre" class="form-control"
                               placeholder="Ej. Combustible, Herramientas..."
                               value="<?= htmlspecialchars($editando['nombre'] ?? '') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tipo de Gasto</label>
                        <select name="tipo" class="form-select">
                            <?php foreach ($tipoLabel as $val => $lbl): ?>
                            <option value="<?= $val ?>" <?= ($editando['tipo'] ?? 'otros') === $val ? 'selected' : '' ?>>
                                <?= $lbl ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Agrupa los gastos para los reportes.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Descripción</label>
                        <textarea name="descripcion" class="form-control" rows="2"
                                  placeholder="Descripción opcional..."><?= htmlspecialchars($editando['descripcion'] ?? '') ?></textarea>
                    </div>

                    <?php if ($editando): ?>
                    <div class="mb-3 form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="activo" id="chkActivo"
                               <?= $editando['activo'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="chkActivo">Categoría activa</label>
                    </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-<?= $editando ? 'warning' : 'success' ?> fw-bold">
                            <i class="bi bi-<?= $editando ? 'save' : 'plus-circle' ?> me-1"></i>
                            <?= $editando ? 'Guardar Cambios' : 'Crear Categoría' ?>
                        </button>
                        <?php if ($editando): ?>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-x-circle me-1"></i>Cancelar
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Info -->
        <div class="alert alert-info mt-3 small">
            <i class="bi bi-lightbulb-fill me-1"></i>
            Las categorías organizan tus gastos en los <strong>reportes</strong>. 
            No puedes eliminar una categoría que tenga gastos activos asociados.
        </div>
    </div>

    <!-- ── Lista de categorías ────────────────────────── -->
    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header fw-semibold bg-dark text-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-list-ul me-2"></i>Categorías registradas</span>
                <span class="badge bg-warning text-dark"><?= count($categorias) ?> categorías</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($categorias)): ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-tags d-block fs-1 mb-2 opacity-25"></i>
                    No hay categorías registradas. ¡Crea la primera!
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Nombre</th>
                                <th>Tipo</th>
                                <th>Descripción</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Gastos</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($categorias as $cat):
                            $uso = $db->fetchOne('SELECT COUNT(*) AS n FROM gastos WHERE categoria_id=? AND activo=1', [$cat['id']]);
                            $nUso = $uso ? (int)$uso['n'] : 0;
                        ?>
                        <tr class="<?= !$cat['activo'] ? 'table-secondary opacity-75' : '' ?>">
                            <td>
                                <strong><?= htmlspecialchars($cat['nombre']) ?></strong>
                            </td>
                            <td>
                                <span class="badge bg-<?= $tipoBadge[$cat['tipo']] ?? 'dark' ?> bg-opacity-75">
                                    <?= $tipoLabel[$cat['tipo']] ?? $cat['tipo'] ?>
                                </span>
                            </td>
                            <td>
                                <small class="text-muted">
                                    <?= $cat['descripcion'] ? htmlspecialchars($cat['descripcion']) : '—' ?>
                                </small>
                            </td>
                            <td class="text-center">
                                <?php if ($cat['activo']): ?>
                                    <span class="badge bg-success">Activa</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactiva</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if ($nUso > 0): ?>
                                    <span class="badge bg-info text-dark"><?= $nUso ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center text-nowrap">
                                <a href="?action=editar&id=<?= $cat['id'] ?>"
                                   class="btn btn-sm btn-outline-warning" title="Editar">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php if ($nUso === 0): ?>
                                <a href="?action=eliminar&id=<?= $cat['id'] ?>"
                                   class="btn btn-sm btn-outline-danger btnConfirm"
                                   data-msg="¿Eliminar la categoría «<?= htmlspecialchars($cat['nombre']) ?>»?"
                                   title="Eliminar">
                                    <i class="bi bi-trash"></i>
                                </a>
                                <?php else: ?>
                                <button class="btn btn-sm btn-outline-secondary" disabled title="Tiene gastos asociados">
                                    <i class="bi bi-lock"></i>
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<?php
$extraJs = <<<JS
<script>
$(function(){
    $(document).on('click','.btnConfirm',function(e){
        e.preventDefault();
        var url=\$(this).attr('href'), msg=\$(this).data('msg')||'¿Confirmar?';
        Swal.fire({title:msg,icon:'warning',showCancelButton:true,
                   confirmButtonText:'Sí, eliminar',cancelButtonText:'Cancelar',
                   confirmButtonColor:'#dc2626'})
            .then(r=>{ if(r.isConfirmed) window.location=url; });
    });
});
</script>
JS;
require_once __DIR__ . '/../../../includes/footer.php';
?>

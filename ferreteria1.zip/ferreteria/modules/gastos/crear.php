<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';
$editMode = false;
$g = null;

// Editar
if (isset($_GET['id'])) {
    $editMode = true;
    $g = $db->fetchOne('SELECT * FROM gastos WHERE id = ? AND activo = 1', array((int)$_GET['id']));
    if (!$g) { header('Location: index.php'); exit; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $catId    = (int)$_POST['categoria_id'];
        $fecha    = $_POST['fecha'];
        $concepto = trim($_POST['concepto'] ?? '');
        $proveedor= trim($_POST['proveedor'] ?? '');
        $monto    = (float)str_replace(',', '', $_POST['monto'] ?? 0);
        $tipoPago = $_POST['tipo_pago'] ?? 'efectivo';
        $comprobante = trim($_POST['comprobante'] ?? '');
        $estado   = $_POST['estado'] ?? 'pagado';
        $notas    = trim($_POST['notas'] ?? '');
        $periodoMes  = (int)date('m', strtotime($fecha));
        $periodoAnio = (int)date('Y', strtotime($fecha));

        if (!$catId)    throw new Exception('Seleccione una categoría.');
        if (!$concepto) throw new Exception('Ingrese el concepto del gasto.');
        if ($monto <= 0) throw new Exception('El monto debe ser mayor a 0.');

        if ($editMode) {
            $db->query(
                "UPDATE gastos SET categoria_id=?, fecha=?, concepto=?, proveedor=?, monto=?,
                 tipo_pago=?, comprobante=?, estado=?, notas=?, periodo_mes=?, periodo_anio=?
                 WHERE id = ?",
                array($catId, $fecha, $concepto, $proveedor, $monto, $tipoPago, $comprobante,
                      $estado, $notas, $periodoMes, $periodoAnio, $g['id'])
            );
            header('Location: index.php?mes='.$periodoMes.'&anio='.$periodoAnio);
            exit;
        } else {
            // Folio
            $prefijo  = getSetting('folio_gasto_prefijo') ?: 'GST';
            $contador = (int)(getSetting('folio_gasto_contador') ?: 0) + 1;
            $folio    = $prefijo . str_pad($contador, 5, '0', STR_PAD_LEFT);

            $db->query(
                "INSERT INTO gastos
                 (folio, categoria_id, usuario_id, fecha, concepto, proveedor, monto, tipo_pago,
                  comprobante, estado, notas, periodo_mes, periodo_anio)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                array($folio, $catId, $_SESSION['user_id'], $fecha, $concepto, $proveedor, $monto,
                      $tipoPago, $comprobante, $estado, $notas, $periodoMes, $periodoAnio)
            );
            $db->query("UPDATE configuracion SET valor = ? WHERE clave = 'folio_gasto_contador'", array($contador));
            header('Location: index.php?mes='.$periodoMes.'&anio='.$periodoAnio);
            exit;
        }
    } catch (Exception $e) { $err = $e->getMessage(); }
}

$pageTitle = $editMode ? 'Editar Gasto' : 'Registrar Gasto';
require_once __DIR__ . '/../../includes/header.php';

$categorias = $db->fetchAll("SELECT * FROM gastos_categorias WHERE activo = 1 ORDER BY tipo, nombre");
?>

<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-receipt me-2 text-danger"></i><?= $editMode ? 'Editar Gasto' : 'Registrar Gasto' ?></h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Gastos</a></li>
            <li class="breadcrumb-item active"><?= $editMode ? 'Editar' : 'Nuevo' ?></li>
        </ol></nav>
    </div>
</div>

<div class="row justify-content-center">
<div class="col-lg-7">
<div class="card shadow-sm">
    <div class="card-header fw-semibold"><i class="bi bi-pencil-square me-1"></i>Datos del Gasto</div>
    <div class="card-body">
    <form method="POST">

        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Categoría <span class="text-danger">*</span></label>
                <select name="categoria_id" class="form-select" required>
                    <option value="">— Seleccionar —</option>
                    <?php
                    $lastTipo = '';
                    foreach ($categorias as $c):
                        if ($c['tipo'] !== $lastTipo):
                            $tipoLabels = array('compra_productos'=>'Compra Productos','materiales'=>'Materiales','nomina'=>'Nómina','servicios'=>'Servicios','otros'=>'Otros');
                            if ($lastTipo !== '') echo '</optgroup>';
                            echo '<optgroup label="'.htmlspecialchars($tipoLabels[$c['tipo']] ?? $c['tipo']).'">';
                            $lastTipo = $c['tipo'];
                        endif;
                    ?>
                        <option value="<?= $c['id'] ?>" <?= ($g && $g['categoria_id']==$c['id'])?'selected':'' ?>><?= htmlspecialchars($c['nombre']) ?></option>
                    <?php endforeach; ?>
                    </optgroup>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Fecha <span class="text-danger">*</span></label>
                <input type="date" name="fecha" class="form-control" value="<?= $g ? $g['fecha'] : date('Y-m-d') ?>" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-select">
                    <option value="pagado"    <?= ($g && $g['estado']==='pagado')   ?'selected':(!$g?'selected':'') ?>>Pagado</option>
                    <option value="pendiente" <?= ($g && $g['estado']==='pendiente')?'selected':'' ?>>Pendiente</option>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label">Concepto <span class="text-danger">*</span></label>
                <input type="text" name="concepto" class="form-control" placeholder="Descripción del gasto..." value="<?= htmlspecialchars($g['concepto'] ?? '') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Proveedor / Beneficiario</label>
                <input type="text" name="proveedor" class="form-control" placeholder="Nombre empresa o persona" value="<?= htmlspecialchars($g['proveedor'] ?? '') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Monto (Q) <span class="text-danger">*</span></label>
                <input type="number" name="monto" class="form-control" value="<?= $g ? $g['monto'] : '0' ?>" min="0.01" step="0.01" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tipo de Pago</label>
                <select name="tipo_pago" class="form-select">
                    <?php foreach (array('efectivo'=>'Efectivo','transferencia'=>'Transferencia','tarjeta'=>'Tarjeta','cheque'=>'Cheque','otro'=>'Otro') as $v => $l): ?>
                    <option value="<?= $v ?>" <?= ($g && $g['tipo_pago']===$v)?'selected':''; if (!$g && $v==='efectivo') echo 'selected'; ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">No. Comprobante / Factura</label>
                <input type="text" name="comprobante" class="form-control" placeholder="Factura, recibo, etc." value="<?= htmlspecialchars($g['comprobante'] ?? '') ?>">
            </div>
            <div class="col-12">
                <label class="form-label">Notas</label>
                <textarea name="notas" class="form-control" rows="2" placeholder="Observaciones adicionales..."><?= htmlspecialchars($g['notas'] ?? '') ?></textarea>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-danger"><i class="bi bi-save me-1"></i><?= $editMode ? 'Actualizar' : 'Guardar Gasto' ?></button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
    </div>
</div>
</div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

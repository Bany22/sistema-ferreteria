<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// Eliminar gasto
if (isset($_GET['action']) && $_GET['action'] === 'eliminar') {
    $gid = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    try {
        $db->query("UPDATE gastos SET activo = 0 WHERE id = ?", array($gid));
        $msg = 'Gasto eliminado.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}

// Anular gasto
if (isset($_GET['action']) && $_GET['action'] === 'anular') {
    $gid = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    try {
        $db->query("UPDATE gastos SET estado = 'anulado' WHERE id = ? AND activo = 1", array($gid));
        $msg = 'Gasto anulado.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}

$pageTitle = 'Gastos de Empresa';
require_once __DIR__ . '/../../includes/header.php';

// Filtros
$filMes  = isset($_GET['mes'])  ? (int)$_GET['mes']  : (int)date('m');
$filAnio = isset($_GET['anio']) ? (int)$_GET['anio'] : (int)date('Y');
$filCat  = isset($_GET['cat'])  ? (int)$_GET['cat']  : 0;

$where = "WHERE g.activo = 1";
$params = array();
if ($filMes && $filAnio) {
    $where  .= " AND g.periodo_mes = ? AND g.periodo_anio = ?";
    $params[] = $filMes;
    $params[] = $filAnio;
}
if ($filCat) {
    $where  .= " AND g.categoria_id = ?";
    $params[] = $filCat;
}

$gastos = $db->fetchAll(
    "SELECT g.*, gc.nombre AS categoria, gc.tipo,
            CONCAT(u.nombre,' ',u.apellido) AS registrado_por
     FROM gastos g
     JOIN gastos_categorias gc ON g.categoria_id = gc.id
     JOIN usuarios u ON g.usuario_id = u.id
     $where
     ORDER BY g.fecha DESC, g.id DESC",
    $params
);

$categorias = $db->fetchAll("SELECT * FROM gastos_categorias WHERE activo = 1 ORDER BY nombre");

// Suma total
$totalFiltro = array_sum(array_column(array_filter($gastos, function($g){ return $g['estado'] !== 'anulado'; }), 'monto'));

// Por tipo
$porTipo = array();
foreach ($gastos as $g) {
    if ($g['estado'] === 'anulado') continue;
    $t = $g['tipo'];
    if (!isset($porTipo[$t])) $porTipo[$t] = 0;
    $porTipo[$t] += $g['monto'];
}

$tipoLabel = array(
    'compra_productos' => 'Compra Productos',
    'materiales'       => 'Materiales',
    'nomina'           => 'Nómina/Trabajadores',
    'servicios'        => 'Servicios',
    'otros'            => 'Otros',
);
$tipoBadge = array(
    'compra_productos' => 'primary',
    'materiales'       => 'info',
    'nomina'           => 'warning',
    'servicios'        => 'secondary',
    'otros'            => 'dark',
);
$estadoBadge = array('pendiente'=>'warning','pagado'=>'success','anulado'=>'danger');
$meses = array('','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');
?>

<?php if ($msg): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-receipt me-2 text-danger"></i>Gastos de Empresa</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Gastos</li>
        </ol></nav>
    </div>
    <div class="d-flex gap-2">
        <a href="categorias/index.php" class="btn btn-outline-warning"><i class="bi bi-tags me-1"></i>Categorías</a>
        <a href="crear.php" class="btn btn-danger"><i class="bi bi-plus-circle me-1"></i>Registrar Gasto</a>
    </div>
</div>

<!-- Filtros -->
<div class="card shadow-sm mb-4">
    <div class="card-body py-2">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-auto">
                <label class="form-label mb-0">Mes</label>
                <select name="mes" class="form-select form-select-sm">
                    <?php for($m=1;$m<=12;$m++): ?>
                    <option value="<?= $m ?>" <?= $filMes==$m?'selected':'' ?>><?= $meses[$m] ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-auto">
                <label class="form-label mb-0">Año</label>
                <select name="anio" class="form-select form-select-sm">
                    <?php for($y=date('Y');$y>=date('Y')-3;$y--): ?>
                    <option value="<?= $y ?>" <?= $filAnio==$y?'selected':'' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-auto">
                <label class="form-label mb-0">Categoría</label>
                <select name="cat" class="form-select form-select-sm">
                    <option value="">Todas</option>
                    <?php foreach ($categorias as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $filCat==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-sm btn-primary">Filtrar</button>
                <a href="index.php" class="btn btn-sm btn-outline-secondary">Limpiar</a>
            </div>
        </form>
    </div>
</div>

<!-- Resumen por tipo -->
<div class="row g-3 mb-4">
    <?php foreach ($porTipo as $tipo => $monto): ?>
    <div class="col-6 col-md">
        <div class="card border-0 shadow-sm text-center py-2">
            <div class="fs-6 fw-bold text-<?= $tipoBadge[$tipo] ?? 'secondary' ?>">Q <?= number_format($monto,2) ?></div>
            <div class="text-muted" style="font-size:11px"><?= $tipoLabel[$tipo] ?? $tipo ?></div>
        </div>
    </div>
    <?php endforeach; ?>
    <div class="col-6 col-md">
        <div class="card border-0 shadow-sm text-center py-2 bg-danger bg-opacity-10">
            <div class="fs-5 fw-bold text-danger">Q <?= number_format($totalFiltro,2) ?></div>
            <div class="text-muted" style="font-size:11px">TOTAL <?= $filAnio ? ($meses[$filMes].' '.$filAnio) : 'Período' ?></div>
        </div>
    </div>
</div>

<!-- Tabla -->
<div class="card shadow-sm">
    <div class="card-body p-0">
        <table id="tblGastos" class="table table-hover mb-0 align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Folio</th>
                    <th>Fecha</th>
                    <th>Categoría</th>
                    <th>Concepto</th>
                    <th>Proveedor/Beneficiario</th>
                    <th>Pago</th>
                    <th class="text-end">Monto</th>
                    <th>Estado</th>
                    <th>Registrado por</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($gastos as $g): ?>
            <tr class="<?= $g['estado']==='anulado'?'table-danger opacity-50':'' ?>">
                <td><strong><?= htmlspecialchars($g['folio']) ?></strong></td>
                <td><?= date('d/m/Y', strtotime($g['fecha'])) ?></td>
                <td>
                    <span class="badge bg-<?= $tipoBadge[$g['tipo']] ?? 'secondary' ?> bg-opacity-75">
                        <?= htmlspecialchars($tipoLabel[$g['tipo']] ?? $g['tipo']) ?>
                    </span><br>
                    <small class="text-muted"><?= htmlspecialchars($g['categoria']) ?></small>
                </td>
                <td><?= htmlspecialchars($g['concepto']) ?></td>
                <td><?= htmlspecialchars($g['proveedor'] ?: '—') ?></td>
                <td><?= ucfirst($g['tipo_pago']) ?></td>
                <td class="text-end fw-bold">Q <?= number_format($g['monto'],2) ?></td>
                <td><span class="badge bg-<?= $estadoBadge[$g['estado']] ?>"><?= ucfirst($g['estado']) ?></span></td>
                <td><small><?= htmlspecialchars($g['registrado_por']) ?></small></td>
                <td class="text-center text-nowrap">
                    <?php if ($g['estado'] !== 'anulado'): ?>
                    <a href="editar.php?id=<?= $g['id'] ?>" class="btn btn-sm btn-outline-warning" title="Editar"><i class="bi bi-pencil"></i></a>
                    <a href="?action=anular&id=<?= $g['id'] ?>&mes=<?= $filMes ?>&anio=<?= $filAnio ?>" class="btn btn-sm btn-outline-danger btnConfirm" title="Anular" data-msg="¿Anular este gasto?"><i class="bi bi-x-circle"></i></a>
                    <?php endif; ?>
                    <a href="?action=eliminar&id=<?= $g['id'] ?>&mes=<?= $filMes ?>&anio=<?= $filAnio ?>" class="btn btn-sm btn-outline-dark btnConfirm" title="Eliminar" data-msg="¿Eliminar definitivamente?"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$extraJs = <<<JS
<script>
$(function(){
    $('#tblGastos').DataTable({
        language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'},
        order:[[1,'desc']]
    });
    $(document).on('click','.btnConfirm',function(e){
        e.preventDefault();
        var url=$(this).attr('href'), msg=$(this).data('msg')||'¿Confirmar?';
        Swal.fire({title:msg,icon:'warning',showCancelButton:true,confirmButtonText:'Sí',cancelButtonText:'No'})
            .then(r=>{ if(r.isConfirmed) window.location=url; });
    });
});
</script>
JS;
require_once __DIR__ . '/../../includes/footer.php';
?>

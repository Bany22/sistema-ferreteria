<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$pageTitle = 'Reportes';
require_once __DIR__ . '/../../includes/header.php';
$db = Database::getInstance();

$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$tipo = $_GET['tipo'] ?? 'ventas';

// Report data
$reporteVentas = $db->fetchAll(
    "SELECT v.folio, v.fecha, v.total, v.descuento, v.iva, v.subtotal, v.tipo_pago, v.estado,
            CONCAT(c.nombre,' ',c.apellido) as cliente, CONCAT(u.nombre,' ',u.apellido) as vendedor
     FROM ventas v JOIN clientes c ON v.cliente_id=c.id JOIN usuarios u ON v.usuario_id=u.id
     WHERE v.fecha BETWEEN ? AND ? AND v.activo=1
     ORDER BY v.fecha DESC",
    [$desde, $hasta]
);

$resumenVentas = $db->fetchOne(
    "SELECT COUNT(*) as total_ventas, COALESCE(SUM(total),0) as monto_total, 
            COALESCE(SUM(iva),0) as total_iva, COALESCE(SUM(descuento),0) as total_desc
     FROM ventas WHERE fecha BETWEEN ? AND ? AND activo=1 AND estado != 'cancelada'",
    [$desde, $hasta]
);

$ventasPorDia = $db->fetchAll(
    "SELECT DATE(fecha) as dia, COUNT(*) as ventas, SUM(total) as total
     FROM ventas WHERE fecha BETWEEN ? AND ? AND activo=1 AND estado != 'cancelada'
     GROUP BY DATE(fecha) ORDER BY dia",
    [$desde, $hasta]
);

$topProductos = $db->fetchAll(
    "SELECT p.codigo, p.nombre, SUM(vd.cantidad) as qty, SUM(vd.subtotal) as total,
            p.precio_costo, SUM(vd.cantidad * (vd.precio_unitario - p.precio_costo)) as utilidad
     FROM ventas_detalle vd
     JOIN ventas v ON vd.venta_id=v.id
     JOIN productos p ON vd.producto_id=p.id
     WHERE v.fecha BETWEEN ? AND ? AND v.activo=1 AND v.estado != 'cancelada' AND vd.activo=1
     GROUP BY p.id, p.codigo, p.nombre, p.precio_costo ORDER BY total DESC LIMIT 20",
    [$desde, $hasta]
);

$topClientes = $db->fetchAll(
    "SELECT CONCAT(c.nombre,' ',c.apellido) as cliente, c.empresa,
            COUNT(v.id) as num_ventas, SUM(v.total) as total
     FROM ventas v JOIN clientes c ON v.cliente_id=c.id
     WHERE v.fecha BETWEEN ? AND ? AND v.activo=1 AND v.estado != 'cancelada'
     GROUP BY c.id, c.nombre, c.apellido, c.empresa ORDER BY total DESC LIMIT 10",
    [$desde, $hasta]
);

$ventasPorVendedor = $db->fetchAll(
    "SELECT CONCAT(u.nombre,' ',u.apellido) as vendedor, COUNT(v.id) as ventas, SUM(v.total) as total
     FROM ventas v JOIN usuarios u ON v.usuario_id=u.id
     WHERE v.fecha BETWEEN ? AND ? AND v.activo=1 AND v.estado != 'cancelada'
     GROUP BY u.id, u.nombre, u.apellido ORDER BY total DESC",
    [$desde, $hasta]
);

$chartLabels = array_column($ventasPorDia, 'dia');
$chartData = array_column($ventasPorDia, 'total');
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-bar-chart-line me-2 text-primary"></i>Reportes de Ventas</h1>
    </div>
    <button onclick="window.print()" class="btn btn-outline-secondary no-print">
        <i class="bi bi-printer me-1"></i>Imprimir
    </button>
</div>

<!-- Filtros -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Desde</label>
                <input type="date" name="desde" class="form-control" value="<?= $desde ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Hasta</label>
                <input type="date" name="hasta" class="form-control" value="<?= $hasta ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Período rápido</label>
                <select class="form-select" onchange="setPeriodo(this.value)">
                    <option value="">-- Seleccionar --</option>
                    <option value="hoy">Hoy</option>
                    <option value="semana">Esta Semana</option>
                    <option value="mes">Este Mes</option>
                    <option value="mes_anterior">Mes Anterior</option>
                    <option value="anio">Este Año</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-funnel me-1"></i>Filtrar
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Resumen -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="bi bi-receipt"></i></div>
            <div>
                <div class="stat-value"><?= $resumenVentas['total_ventas'] ?></div>
                <div class="stat-label">Total Ventas</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-icon green"><i class="bi bi-currency-dollar"></i></div>
            <div>
                <div class="stat-value">Q <?= number_format($resumenVentas['monto_total'],0) ?></div>
                <div class="stat-label">Monto Total</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-icon orange"><i class="bi bi-percent"></i></div>
            <div>
                <div class="stat-value">Q <?= number_format($resumenVentas['total_iva'],0) ?></div>
                <div class="stat-label">Total IVA</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <div class="stat-icon purple"><i class="bi bi-graph-up"></i></div>
            <div>
                <div class="stat-value">Q <?= $resumenVentas['total_ventas'] > 0 ? number_format($resumenVentas['monto_total'] / $resumenVentas['total_ventas'],0) : '0' ?></div>
                <div class="stat-label">Ticket Promedio</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Gráfica ventas por día -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">Ventas por Día</div>
            <div class="card-body">
                <canvas id="reportChart" height="100"></canvas>
            </div>
        </div>
    </div>
    <!-- Ventas por vendedor -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">Por Vendedor</div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php foreach ($ventasPorVendedor as $v): ?>
                    <div class="list-group-item d-flex justify-content-between">
                        <div><div class="fw-semibold"><?= htmlspecialchars($v['vendedor']) ?></div>
                        <small class="text-muted"><?= $v['ventas'] ?> ventas</small></div>
                        <span class="fw-bold text-success">Q <?= number_format($v['total'],2) ?></span>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($ventasPorVendedor)): ?><div class="list-group-item text-muted text-center py-3">Sin datos</div><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Top productos -->
<div class="card mb-4">
    <div class="card-header"><i class="bi bi-trophy me-2"></i>Productos más Vendidos</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="tblTopProd">
                <thead><tr><th>#</th><th>Código</th><th>Producto</th><th>Qty Vendida</th><th>Total Venta</th><th>Utilidad Estimada</th></tr></thead>
                <tbody>
                    <?php foreach ($topProductos as $i => $p): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><code><?= htmlspecialchars($p['codigo']) ?></code></td>
                        <td><?= htmlspecialchars($p['nombre']) ?></td>
                        <td><?= number_format($p['qty'],2) ?></td>
                        <td class="fw-bold">Q <?= number_format($p['total'],2) ?></td>
                        <td class="text-success">Q <?= number_format($p['utilidad'],2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Top clientes -->
<div class="card mb-4">
    <div class="card-header"><i class="bi bi-people me-2"></i>Top Clientes</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table" id="tblTopClientes">
                <thead><tr><th>#</th><th>Cliente</th><th>Empresa</th><th>Num. Compras</th><th>Total</th></tr></thead>
                <tbody>
                    <?php foreach ($topClientes as $i => $c): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><?= htmlspecialchars($c['cliente']) ?></td>
                        <td><?= htmlspecialchars($c['empresa'] ?? '') ?></td>
                        <td><?= $c['num_ventas'] ?></td>
                        <td class="fw-bold text-success">Q <?= number_format($c['total'],2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Detalle de ventas -->
<div class="card">
    <div class="card-header"><i class="bi bi-list-ul me-2"></i>Detalle de Ventas</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm" id="tblDetalleVentas">
                <thead><tr><th>Folio</th><th>Fecha</th><th>Cliente</th><th>Vendedor</th><th>Subtotal</th><th>IVA</th><th>Total</th><th>Pago</th><th>Estado</th></tr></thead>
                <tbody>
                    <?php foreach ($reporteVentas as $v): ?>
                    <tr>
                        <td><a href="<?= APP_URL ?>/modules/ventas/ver.php?folio=<?= urlencode($v['folio']) ?>"><code><?= htmlspecialchars($v['folio']) ?></code></a></td>
                        <td><?= date('d/m/Y', strtotime($v['fecha'])) ?></td>
                        <td><?= htmlspecialchars($v['cliente']) ?></td>
                        <td><?= htmlspecialchars($v['vendedor']) ?></td>
                        <td>Q <?= number_format($v['subtotal'],2) ?></td>
                        <td>Q <?= number_format($v['iva'],2) ?></td>
                        <td class="fw-bold">Q <?= number_format($v['total'],2) ?></td>
                        <td><?= ucfirst($v['tipo_pago']) ?></td>
                        <td><span class="badge-<?= $v['estado'] ?>"><?= ucfirst($v['estado']) ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const APP_URL = '<?= APP_URL ?>';
$(document).ready(function() {
    $('#tblTopProd, #tblTopClientes, #tblDetalleVentas').DataTable();
    
    new Chart(document.getElementById('reportChart'), {
        type: 'line',
        data: {
            labels: <?= json_encode(array_map(function($d) { return date('d/m', strtotime($d)); }, $chartLabels)) ?>,
            datasets: [{
                label: 'Ventas',
                data: <?= json_encode(array_map('floatval', $chartData)) ?>,
                backgroundColor: 'rgba(37,99,235,0.1)',
                borderColor: 'rgba(37,99,235,0.8)',
                borderWidth: 2, tension: 0.4, fill: true,
                pointBackgroundColor: '#2563eb'
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { callback: function(v){ return 'Q ' + parseFloat(v).toLocaleString('es-GT'); } } } }
        }
    });
});

function setPeriodo(v) {
    const today = new Date();
    let desde, hasta = today.toISOString().split('T')[0];
    if (v === 'hoy') { desde = hasta; }
    else if (v === 'semana') {
        const d = new Date(today); d.setDate(d.getDate() - d.getDay());
        desde = d.toISOString().split('T')[0];
    } else if (v === 'mes') {
        desde = today.getFullYear() + '-' + String(today.getMonth()+1).padStart(2,'0') + '-01';
    } else if (v === 'mes_anterior') {
        const d = new Date(today.getFullYear(), today.getMonth()-1, 1);
        const d2 = new Date(today.getFullYear(), today.getMonth(), 0);
        desde = d.toISOString().split('T')[0]; hasta = d2.toISOString().split('T')[0];
    } else if (v === 'anio') {
        desde = today.getFullYear() + '-01-01';
    }
    if (desde) {
        document.querySelector('input[name=desde]').value = desde;
        document.querySelector('input[name=hasta]').value = hasta;
    }
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db = Database::getInstance();
$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);

$inst = $db->fetchOne(
    "SELECT i.*,
            CONCAT(c.nombre,' ',c.apellido) AS cliente_nombre, c.empresa, c.telefono AS cli_tel, c.email AS cli_email, c.direccion AS cli_dir,
            CONCAT(u.nombre,' ',u.apellido) AS tecnico
     FROM instalaciones i
     JOIN clientes c ON i.cliente_id = c.id
     JOIN usuarios u ON i.usuario_id = u.id
     WHERE i.id = ? AND i.activo = 1",
    array($id)
);
if (!$inst) { header('Location: index.php'); exit; }

$detalle = $db->fetchAll(
    "SELECT d.*, cm.nombre AS marca, ct.nombre AS tipo
     FROM instalaciones_detalle d
     JOIN camaras_marcas cm ON d.marca_id = cm.id
     LEFT JOIN camaras_tipos ct ON d.tipo_id = ct.id
     WHERE d.instalacion_id = ? AND d.activo = 1",
    array($id)
);

$empresa  = getSetting('empresa_nombre') ?: 'Ferretería La Curva';
$emp_dir  = getSetting('empresa_direccion') ?: '';
$emp_tel  = getSetting('empresa_telefono') ?: '';
$emp_email= getSetting('empresa_email') ?: '';

$estadoLabel = array('cotizacion'=>'COTIZACIÓN','aprobada'=>'APROBADA','en_proceso'=>'EN PROCESO','completada'=>'COMPLETADA','cancelada'=>'CANCELADA');
$esLabel = isset($estadoLabel[$inst['estado']]) ? $estadoLabel[$inst['estado']] : strtoupper($inst['estado']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Instalación <?= htmlspecialchars($inst['folio']) ?></title>
<style>
  body{font-family:Arial,sans-serif;font-size:12px;color:#222;margin:0;padding:20px}
  .header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #1a56db;padding-bottom:12px;margin-bottom:16px}
  .empresa-name{font-size:22px;font-weight:bold;color:#1a56db}
  .folio-box{text-align:right}
  .folio-box .folio{font-size:18px;font-weight:bold}
  .badge-estado{display:inline-block;background:#1a56db;color:#fff;padding:3px 12px;border-radius:4px;font-size:11px;margin-top:4px}
  .section{margin-bottom:14px}
  .section-title{font-weight:bold;background:#f0f4ff;padding:4px 8px;margin-bottom:6px;border-left:4px solid #1a56db}
  table{width:100%;border-collapse:collapse}
  th{background:#1a56db;color:#fff;padding:5px 6px;text-align:left;font-size:11px}
  td{padding:4px 6px;border-bottom:1px solid #e0e0e0}
  tr:nth-child(even) td{background:#f8f9ff}
  .totals{width:280px;float:right;margin-top:10px}
  .totals td{padding:3px 6px}
  .totals .grand{font-size:14px;font-weight:bold;color:#1a56db;background:#f0f4ff}
  .footer{margin-top:30px;border-top:1px solid #ccc;padding-top:8px;text-align:center;color:#666;font-size:10px}
  @media print{body{padding:10px}}
</style>
</head>
<body>

<div class="header">
    <div>
        <div class="empresa-name"><i>&#128247;</i> <?= htmlspecialchars($empresa) ?></div>
        <div><?= htmlspecialchars($emp_dir) ?></div>
        <div><?= htmlspecialchars($emp_tel) ?><?= ($emp_email ? ' | '.$emp_email : '') ?></div>
    </div>
    <div class="folio-box">
        <div class="folio"><?= htmlspecialchars($inst['folio']) ?></div>
        <div class="badge-estado"><?= $esLabel ?></div>
        <div style="margin-top:4px">Fecha: <strong><?= date('d/m/Y', strtotime($inst['fecha'])) ?></strong></div>
    </div>
</div>

<div class="section">
    <div class="section-title">Cliente</div>
    <table style="width:auto">
        <tr><td style="width:120px;color:#555">Nombre:</td><td><strong><?= htmlspecialchars($inst['cliente_nombre']) ?></strong><?= $inst['empresa'] ? ' — '.$inst['empresa'] : '' ?></td></tr>
        <?php if ($inst['cli_tel']): ?><tr><td style="color:#555">Teléfono:</td><td><?= htmlspecialchars($inst['cli_tel']) ?></td></tr><?php endif; ?>
        <?php if ($inst['cli_email']): ?><tr><td style="color:#555">Email:</td><td><?= htmlspecialchars($inst['cli_email']) ?></td></tr><?php endif; ?>
        <?php if ($inst['direccion_inst']): ?><tr><td style="color:#555">Dir. instalación:</td><td><?= htmlspecialchars($inst['direccion_inst']) ?></td></tr><?php endif; ?>
        <tr><td style="color:#555">Garantía:</td><td><?= $inst['garantia_meses'] ?> meses</td></tr>
        <tr><td style="color:#555">Forma de pago:</td><td><?= ucfirst($inst['tipo_pago']) ?></td></tr>
    </table>
</div>

<div class="section">
    <div class="section-title">Equipos y Cámaras de Seguridad</div>
    <table>
        <thead>
            <tr>
                <th>#</th><th>Marca</th><th>Tipo</th><th>Modelo/Descripción</th>
                <th style="text-align:center">Cant.</th><th style="text-align:right">P. Unit.</th>
                <th style="text-align:right">Descuento</th><th style="text-align:right">Subtotal</th>
            </tr>
        </thead>
        <tbody>
        <?php $n=0; foreach ($detalle as $d): $n++; ?>
        <tr>
            <td><?= $n ?></td>
            <td><strong><?= htmlspecialchars($d['marca']) ?></strong></td>
            <td><?= htmlspecialchars($d['tipo'] ?: '—') ?></td>
            <td><?= htmlspecialchars($d['modelo'] ?: '') ?><?= $d['descripcion'] ? '<br><em style="color:#666;font-size:10px">'.htmlspecialchars($d['descripcion']).'</em>' : '' ?></td>
            <td style="text-align:center"><?= $d['cantidad'] ?></td>
            <td style="text-align:right">Q <?= number_format($d['precio_unitario'],2) ?></td>
            <td style="text-align:right">Q <?= number_format($d['descuento'],2) ?></td>
            <td style="text-align:right"><strong>Q <?= number_format($d['subtotal'],2) ?></strong></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<table class="totals">
    <?php if ($inst['costo_mano_obra'] > 0): ?>
    <tr><td>Mano de Obra:</td><td style="text-align:right">Q <?= number_format($inst['costo_mano_obra'],2) ?></td></tr>
    <?php endif; ?>
    <?php if ($inst['costo_materiales'] > 0): ?>
    <tr><td>Materiales Adicionales:</td><td style="text-align:right">Q <?= number_format($inst['costo_materiales'],2) ?></td></tr>
    <?php endif; ?>
    <?php if ($inst['descuento'] > 0): ?>
    <tr><td>Descuento Global:</td><td style="text-align:right;color:red">- Q <?= number_format($inst['descuento'],2) ?></td></tr>
    <?php endif; ?>
    <tr><td>IVA:</td><td style="text-align:right">Q <?= number_format($inst['iva'],2) ?></td></tr>
    <tr class="grand"><td><strong>TOTAL:</strong></td><td style="text-align:right"><strong>Q <?= number_format($inst['total'],2) ?></strong></td></tr>
</table>
<div style="clear:both"></div>

<?php if ($inst['notas']): ?>
<div class="section" style="margin-top:10px">
    <div class="section-title">Notas / Condiciones</div>
    <p style="margin:4px 0"><?= nl2br(htmlspecialchars($inst['notas'])) ?></p>
</div>
<?php endif; ?>

<div class="footer">
    <?= htmlspecialchars($empresa) ?> — Sistemas de Seguridad y Videovigilancia<br>
    Documento generado el <?= date('d/m/Y H:i') ?> — Técnico: <?= htmlspecialchars($inst['tecnico']) ?>
</div>

<script>window.onload=function(){window.print()}</script>
</body>
</html>

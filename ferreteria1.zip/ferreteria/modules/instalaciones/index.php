<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// Cancelar instalación
if (isset($_GET['action']) && $_GET['action'] === 'cancelar') {
    $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    $inst = $db->fetchOne('SELECT * FROM instalaciones WHERE id = ? AND activo = 1', array($id));
    if ($inst && $inst['estado'] !== 'cancelada') {
        try {
            // Si estaba en un estado que descontó stock, devolver stock
            if (in_array($inst['estado'], array('aprobada','completada','en_proceso'))) {
                $dets = $db->fetchAll('SELECT * FROM instalaciones_detalle WHERE instalacion_id = ? AND activo = 1', array($id));
                foreach ($dets as $d) {
                    if ($d['producto_id']) {
                        $prod = $db->fetchOne('SELECT stock_actual FROM productos WHERE id=?', array($d['producto_id']));
                        if ($prod) {
                            $antes = (float)$prod['stock_actual'];
                            $nuevo = $antes + (float)$d['cantidad'];
                            $db->query('UPDATE productos SET stock_actual=? WHERE id=?', array($nuevo,$d['producto_id']));
                            $db->query("INSERT INTO inventario_movimientos
                                (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,referencia_id,usuario_id,notas)
                                VALUES (?,?,?,?,?,?,?,?,?)",
                                array($d['producto_id'],'devolucion',$d['cantidad'],$antes,$nuevo,
                                      'venta',$id,$_SESSION['user_id'],'Cancelación instalación '.$inst['folio']));
                        }
                    }
                }
            }
            $db->query("UPDATE instalaciones SET estado = 'cancelada' WHERE id = ?", array($id));
            $msg = 'Registro cancelado correctamente.';
        } catch (Exception $e) { $err = $e->getMessage(); }
    }
}

// Cambiar estado (y descontar stock si aplica)
if (isset($_GET['action']) && $_GET['action'] === 'cambiar_estado') {
    $id         = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    $nuevoEstado= isset($_GET['estado']) ? $_GET['estado'] : '';
    $estadosVal = array('cotizacion','aprobada','en_proceso','completada');
    $inst = $db->fetchOne('SELECT * FROM instalaciones WHERE id=? AND activo=1', array($id));
    if ($inst && in_array($nuevoEstado, $estadosVal)) {
        try {
            $estadoAnt = $inst['estado'];
            $db->query("UPDATE instalaciones SET estado=? WHERE id=?", array($nuevoEstado,$id));
            // Descontar stock si transición a estado activo
            if (in_array($nuevoEstado, array('aprobada','en_proceso','completada'))
             && !in_array($estadoAnt,  array('aprobada','en_proceso','completada'))) {
                $dets = $db->fetchAll('SELECT * FROM instalaciones_detalle WHERE instalacion_id=? AND activo=1', array($id));
                foreach ($dets as $d) {
                    if ($d['producto_id']) {
                        $prod = $db->fetchOne('SELECT stock_actual FROM productos WHERE id=?', array($d['producto_id']));
                        if ($prod) {
                            $antes = (float)$prod['stock_actual'];
                            $nuevo = max(0,$antes - (float)$d['cantidad']);
                            $db->query('UPDATE productos SET stock_actual=? WHERE id=?', array($nuevo,$d['producto_id']));
                            $db->query("INSERT INTO inventario_movimientos
                                (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,referencia_id,usuario_id,notas)
                                VALUES (?,?,?,?,?,?,?,?,?)",
                                array($d['producto_id'],'salida',$d['cantidad'],$antes,$nuevo,
                                      'venta',$id,$_SESSION['user_id'],'Instalación '.$inst['folio'].' → '.$nuevoEstado));
                        }
                    }
                }
                $msg = 'Estado actualizado a "'.ucfirst($nuevoEstado).'" y stock descontado.';
            } else {
                $msg = 'Estado actualizado a "'.ucfirst($nuevoEstado).'".';
            }
        } catch (Exception $e) { $err = $e->getMessage(); }
    }
}

// Eliminar
if (isset($_GET['action']) && $_GET['action'] === 'eliminar') {
    $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    try {
        $db->query("UPDATE instalaciones SET activo = 0 WHERE id = ?", array($id));
        $db->query("UPDATE instalaciones_detalle SET activo = 0 WHERE instalacion_id = ?", array($id));
        $msg = 'Registro eliminado.';
    } catch (Exception $e) { $err = $e->getMessage(); }
}

$pageTitle = 'Instalaciones de Cámaras';
require_once __DIR__ . '/../../includes/header.php';

$lista = $db->fetchAll(
    "SELECT i.*,
            CONCAT(c.nombre,' ',c.apellido) AS cliente,
            CONCAT(u.nombre,' ',u.apellido) AS tecnico
     FROM instalaciones i
     JOIN clientes c ON i.cliente_id = c.id
     JOIN usuarios u ON i.usuario_id = u.id
     WHERE i.activo = 1
     ORDER BY i.id DESC"
);

$estadoBadge = array(
    'cotizacion'  => 'secondary',
    'aprobada'    => 'info',
    'en_proceso'  => 'warning',
    'completada'  => 'success',
    'cancelada'   => 'danger',
);
$estadoLabel = array(
    'cotizacion'  => 'Cotización',
    'aprobada'    => 'Aprobada',
    'en_proceso'  => 'En Proceso',
    'completada'  => 'Completada',
    'cancelada'   => 'Cancelada',
);
?>

<?php if ($msg): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-camera-video me-2 text-primary"></i>Instalaciones de Cámaras</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Instalaciones</li>
        </ol></nav>
    </div>
    <a href="crear.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Nueva Instalación / Cotización</a>
</div>

<!-- Resumen rápido -->
<?php
$totCot  = 0; $totApr = 0; $totComp = 0; $totMonto = 0;
foreach ($lista as $r) {
    if ($r['estado'] === 'cotizacion') $totCot++;
    if ($r['estado'] === 'aprobada')   $totApr++;
    if ($r['estado'] === 'completada') { $totComp++; $totMonto += $r['total']; }
}
?>
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-secondary"><?= $totCot ?></div>
            <div class="text-muted small">Cotizaciones</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-info"><?= $totApr ?></div>
            <div class="text-muted small">Aprobadas</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-success"><?= $totComp ?></div>
            <div class="text-muted small">Completadas</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-primary">Q <?= number_format($totMonto,2) ?></div>
            <div class="text-muted small">Total Completadas</div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table id="tblInstalaciones" class="table table-hover mb-0 align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Folio</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Dirección</th>
                    <th>Cámaras</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Técnico</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($lista as $r): ?>
            <?php
                $numCams = $db->fetchOne(
                    'SELECT SUM(cantidad) as tot FROM instalaciones_detalle WHERE instalacion_id = ? AND activo = 1',
                    array($r['id'])
                );
                $numCams = $numCams ? (int)$numCams['tot'] : 0;
            ?>
            <tr>
                <td><strong><?= htmlspecialchars($r['folio']) ?></strong></td>
                <td><?= htmlspecialchars($r['cliente']) ?></td>
                <td><?= date('d/m/Y', strtotime($r['fecha'])) ?></td>
                <td class="text-truncate" style="max-width:160px"><?= htmlspecialchars($r['direccion_inst'] ?: '—') ?></td>
                <td><span class="badge bg-primary"><?= $numCams ?> cám.</span></td>
                <td class="fw-bold">Q <?= number_format($r['total'],2) ?></td>
                <td><span class="badge bg-<?= $estadoBadge[$r['estado']] ?>"><?= $estadoLabel[$r['estado']] ?></span></td>
                <td><?= htmlspecialchars($r['tecnico']) ?></td>
                <td class="text-center text-nowrap">
                    <a href="ver.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-info" title="Ver"><i class="bi bi-eye"></i></a>
                    <?php if ($r['estado'] !== 'cancelada' && $r['estado'] !== 'completada'): ?>
                    <a href="crear.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-warning" title="Editar"><i class="bi bi-pencil"></i></a>
                    <?php endif; ?>
                    <a href="pdf.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-secondary" title="PDF" target="_blank"><i class="bi bi-file-earmark-pdf"></i></a>
                    <?php if (!in_array($r['estado'], array('cancelada','completada'))): ?>
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-success dropdown-toggle" data-bs-toggle="dropdown" title="Cambiar Estado">
                            <i class="bi bi-arrow-repeat"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php foreach (array('cotizacion'=>'Cotización','aprobada'=>'✅ Aprobada','en_proceso'=>'🔧 En Proceso','completada'=>'🎉 Completada') as $ev=>$el): ?>
                            <?php if ($ev !== $r['estado']): ?>
                            <li><a class="dropdown-item" href="?action=cambiar_estado&id=<?= $r['id'] ?>&estado=<?= $ev ?>"><?= $el ?></a></li>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger btnConfirm" href="?action=cancelar&id=<?= $r['id'] ?>" data-msg="¿Cancelar este registro? Se devolverá el stock descontado.">❌ Cancelar</a></li>
                        </ul>
                    </div>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$extraJs = <<<JS
<script>
$(function(){
    $('#tblInstalaciones').DataTable({
        language:{url:'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json'},
        order:[[0,'desc']]
    });
    $(document).on('click','.btnConfirm',function(e){
        e.preventDefault();
        var url=$(this).attr('href'), msg=$(this).data('msg')||'¿Confirmar acción?';
        Swal.fire({title:msg,icon:'warning',showCancelButton:true,confirmButtonText:'Sí',cancelButtonText:'No'})
            .then(r=>{ if(r.isConfirmed) window.location=url; });
    });
});
</script>
JS;
require_once __DIR__ . '/../../includes/footer.php';
?>

<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$id  = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
$new = isset($_GET['new']);

$inst = $db->fetchOne(
    "SELECT i.*,
            CONCAT(c.nombre,' ',c.apellido) AS cliente_nombre, c.empresa, c.telefono AS cli_tel, c.email AS cli_email, c.direccion AS cli_dir,
            CONCAT(u.nombre,' ',u.apellido) AS tecnico
     FROM instalaciones i
     JOIN clientes c ON i.cliente_id = c.id
     JOIN usuarios u ON i.usuario_id = u.id
     WHERE i.id = ? AND i.activo = 1",
    array($id)
);
if (!$inst) { header('Location: index.php'); exit; }

$detalle = $db->fetchAll(
    "SELECT d.*, cm.nombre AS marca, ct.nombre AS tipo
     FROM instalaciones_detalle d
     JOIN camaras_marcas cm ON d.marca_id = cm.id
     LEFT JOIN camaras_tipos ct ON d.tipo_id = ct.id
     WHERE d.instalacion_id = ? AND d.activo = 1",
    array($id)
);

$estadoBadge = array('cotizacion'=>'secondary','aprobada'=>'info','en_proceso'=>'warning','completada'=>'success','cancelada'=>'danger');
$estadoLabel = array('cotizacion'=>'Cotización','aprobada'=>'Aprobada','en_proceso'=>'En Proceso','completada'=>'Completada','cancelada'=>'Cancelada');

$pageTitle = 'Instalación '.$inst['folio'];
require_once __DIR__ . '/../../includes/header.php';
?>

<?php if ($new): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i>Instalación/Cotización registrada exitosamente — <strong><?= htmlspecialchars($inst['folio']) ?></strong></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-camera-video me-2 text-primary"></i><?= htmlspecialchars($inst['folio']) ?></h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Instalaciones</a></li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($inst['folio']) ?></li>
        </ol></nav>
    </div>
    <div class="d-flex gap-2">
        <?php if (!in_array($inst['estado'],array('cancelada','completada'))): ?>
        <a href="editar.php?id=<?= $id ?>" class="btn btn-warning"><i class="bi bi-pencil me-1"></i>Editar</a>
        <?php endif; ?>
        <a href="pdf.php?id=<?= $id ?>" class="btn btn-outline-secondary" target="_blank"><i class="bi bi-file-earmark-pdf me-1"></i>PDF</a>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
    </div>
</div>

<div class="row g-4">
<div class="col-md-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header fw-semibold"><i class="bi bi-person me-1"></i>Cliente</div>
        <div class="card-body">
            <h6 class="mb-1"><?= htmlspecialchars($inst['cliente_nombre']) ?></h6>
            <?php if ($inst['empresa']): ?><div class="text-muted small mb-1"><?= htmlspecialchars($inst['empresa']) ?></div><?php endif; ?>
            <?php if ($inst['cli_tel']): ?><div><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($inst['cli_tel']) ?></div><?php endif; ?>
            <?php if ($inst['cli_email']): ?><div><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($inst['cli_email']) ?></div><?php endif; ?>
        </div>
    </div>
    <div class="card shadow-sm">
        <div class="card-header fw-semibold"><i class="bi bi-info-circle me-1"></i>Info</div>
        <div class="card-body">
            <table class="table table-sm table-borderless mb-0">
                <tr><td class="text-muted">Fecha:</td><td><?= date('d/m/Y', strtotime($inst['fecha'])) ?></td></tr>
                <tr><td class="text-muted">Estado:</td><td><span class="badge bg-<?= $estadoBadge[$inst['estado']] ?>"><?= $estadoLabel[$inst['estado']] ?></span></td></tr>
                <tr><td class="text-muted">Pago:</td><td><?= ucfirst($inst['tipo_pago']) ?></td></tr>
                <tr><td class="text-muted">Garantía:</td><td><?= $inst['garantia_meses'] ?> meses</td></tr>
                <tr><td class="text-muted">Técnico:</td><td><?= htmlspecialchars($inst['tecnico']) ?></td></tr>
                <?php if ($inst['direccion_inst']): ?>
                <tr><td class="text-muted">Dirección:</td><td><?= htmlspecialchars($inst['direccion_inst']) ?></td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<div class="col-md-8">
    <div class="card shadow-sm mb-4">
        <div class="card-header fw-semibold"><i class="bi bi-camera me-1"></i>Equipos / Cámaras</div>
        <div class="card-body p-0">
            <table class="table table-sm align-middle mb-0">
                <thead class="table-light">
                    <tr><th>#</th><th>Marca</th><th>Tipo</th><th>Modelo</th><th>Cant.</th><th>P.Unit</th><th>Desc</th><th>Subtotal</th></tr>
                </thead>
                <tbody>
                <?php $i=0; foreach ($detalle as $d): $i++; ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><strong><?= htmlspecialchars($d['marca']) ?></strong></td>
                    <td><?= htmlspecialchars($d['tipo'] ?: '—') ?></td>
                    <td><?= htmlspecialchars($d['modelo'] ?: '—') ?><?php if ($d['descripcion']): ?><br><small class="text-muted"><?= htmlspecialchars($d['descripcion']) ?></small><?php endif; ?></td>
                    <td><?= $d['cantidad'] ?></td>
                    <td>Q <?= number_format($d['precio_unitario'],2) ?></td>
                    <td>Q <?= number_format($d['descuento'],2) ?></td>
                    <td class="fw-bold">Q <?= number_format($d['subtotal'],2) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header fw-semibold"><i class="bi bi-calculator me-1"></i>Totales</div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <?php if ($inst['notas']): ?>
                    <p class="text-muted small"><strong>Notas:</strong><br><?= nl2br(htmlspecialchars($inst['notas'])) ?></p>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <table class="table table-sm table-borderless mb-0">
                        <tr><td>Equipos:</td><td class="text-end">Q <?= number_format($inst['subtotal'] - $inst['costo_mano_obra'] - $inst['costo_materiales'] + $inst['descuento'],2) ?></td></tr>
                        <?php if ($inst['costo_mano_obra'] > 0): ?>
                        <tr><td>Mano de Obra:</td><td class="text-end">Q <?= number_format($inst['costo_mano_obra'],2) ?></td></tr>
                        <?php endif; ?>
                        <?php if ($inst['costo_materiales'] > 0): ?>
                        <tr><td>Materiales:</td><td class="text-end">Q <?= number_format($inst['costo_materiales'],2) ?></td></tr>
                        <?php endif; ?>
                        <?php if ($inst['descuento'] > 0): ?>
                        <tr><td>Descuento:</td><td class="text-end text-danger">- Q <?= number_format($inst['descuento'],2) ?></td></tr>
                        <?php endif; ?>
                        <tr><td>IVA:</td><td class="text-end">Q <?= number_format($inst['iva'],2) ?></td></tr>
                        <tr class="table-active fw-bold fs-5"><td>TOTAL:</td><td class="text-end text-primary">Q <?= number_format($inst['total'],2) ?></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

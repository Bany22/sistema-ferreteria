<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db  = Database::getInstance();
$msg = $err = '';
$editMode = isset($_GET['id']);
$instId   = $editMode ? (int)$_GET['id'] : 0;
$instExist = null;
$detalleExist = array();

if ($editMode) {
    $instExist = $db->fetchOne("SELECT * FROM instalaciones WHERE id=? AND activo=1", array($instId));
    if (!$instExist) { header('Location: index.php'); exit; }
    $detalleExist = $db->fetchAll(
        "SELECT d.*, cm.nombre AS marca_nombre, ct.nombre AS tipo_nombre,
                p.nombre AS prod_nombre, p.codigo AS prod_codigo, p.stock_actual
         FROM instalaciones_detalle d
         JOIN camaras_marcas cm ON d.marca_id = cm.id
         LEFT JOIN camaras_tipos ct ON d.tipo_id = ct.id
         LEFT JOIN productos p ON d.producto_id = p.id
         WHERE d.instalacion_id=? AND d.activo=1", array($instId)
    );
}

// ---- Guardar ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $clienteId   = (int)$_POST['cliente_id'];
        $fecha       = $_POST['fecha'];
        $direccion   = trim($_POST['direccion_inst'] ?? '');
        $estado      = $_POST['estado'] ?? 'cotizacion';
        $tipoPago    = $_POST['tipo_pago'] ?? 'contado';
        $moObra      = (float)($_POST['costo_mano_obra'] ?? 0);
        $moMat       = (float)($_POST['costo_materiales'] ?? 0);
        $descGlobal  = (float)($_POST['descuento_global'] ?? 0);
        $garantia    = (int)($_POST['garantia_meses'] ?? 12);
        $notas       = trim($_POST['notas'] ?? '');
        $ivaPorc     = (float)(getSetting('iva_venta') ?: 5);

        $marcas     = $_POST['marca_id']      ?? array();
        $tipos      = $_POST['tipo_id']       ?? array();
        $modelos    = $_POST['modelo']        ?? array();
        $descs      = $_POST['detalle_desc']  ?? array();
        $cantids    = $_POST['cantidad']      ?? array();
        $precios    = $_POST['precio_unit']   ?? array();
        $descos     = $_POST['desc_item']     ?? array();
        $prodIds    = $_POST['producto_id']   ?? array();  // producto de inventario (puede ser 0)

        if (!$clienteId) throw new Exception('Seleccione un cliente.');
        if (empty($marcas)) throw new Exception('Agregue al menos un equipo/cámara.');

        $subtotalEquipos = 0;
        $items = array();
        for ($i=0; $i<count($marcas); $i++) {
            $cant   = max(1,(int)$cantids[$i]);
            $precio = (float)($precios[$i] ?? 0);
            $desco  = (float)($descos[$i] ?? 0);
            $sub    = ($cant * $precio) - $desco;
            $subtotalEquipos += $sub;
            $items[] = array(
                'marca_id'     => (int)$marcas[$i],
                'tipo_id'      => (int)($tipos[$i]??0) ?: null,
                'modelo'       => trim($modelos[$i]??''),
                'descripcion'  => trim($descs[$i]??''),
                'cantidad'     => $cant,
                'precio_unit'  => $precio,
                'descuento'    => $desco,
                'subtotal'     => $sub,
                'producto_id'  => (int)($prodIds[$i]??0) ?: null,
            );
        }

        $subtotal = $subtotalEquipos + $moObra + $moMat - $descGlobal;
        $iva      = round($subtotal * ($ivaPorc/100), 2);
        $total    = $subtotal + $iva;

        // Estado anterior (para saber si cambió)
        $estadoAnterior = $instExist ? $instExist['estado'] : 'cotizacion';

        if ($editMode) {
            $db->query("UPDATE instalaciones SET cliente_id=?,fecha=?,direccion_inst=?,estado=?,tipo_pago=?,
                subtotal=?,descuento=?,iva=?,total=?,costo_mano_obra=?,costo_materiales=?,garantia_meses=?,notas=?
                WHERE id=?",
                array($clienteId,$fecha,$direccion,$estado,$tipoPago,
                      $subtotal,$descGlobal,$iva,$total,$moObra,$moMat,$garantia,$notas,$instId));
            $db->query("UPDATE instalaciones_detalle SET activo=0 WHERE instalacion_id=?", array($instId));
        } else {
            $prefijo  = getSetting('folio_inst_prefijo') ?: 'INST';
            $contador = (int)(getSetting('folio_inst_contador') ?: 0) + 1;
            $folio    = $prefijo.str_pad($contador, 5, '0', STR_PAD_LEFT);
            $db->query("INSERT INTO instalaciones
                (folio,cliente_id,usuario_id,fecha,direccion_inst,estado,tipo_pago,
                 subtotal,descuento,iva,total,costo_mano_obra,costo_materiales,garantia_meses,notas)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                array($folio,$clienteId,$_SESSION['user_id'],$fecha,$direccion,$estado,$tipoPago,
                      $subtotal,$descGlobal,$iva,$total,$moObra,$moMat,$garantia,$notas));
            $instId = $db->lastInsertId();
            $db->query("UPDATE configuracion SET valor=? WHERE clave='folio_inst_contador'", array($contador));
        }

        // Insertar detalle
        foreach ($items as $it) {
            $db->query("INSERT INTO instalaciones_detalle
                (instalacion_id,marca_id,tipo_id,modelo,descripcion,cantidad,precio_unitario,descuento,subtotal,producto_id)
                VALUES (?,?,?,?,?,?,?,?,?,?)",
                array($instId,$it['marca_id'],$it['tipo_id'],$it['modelo'],$it['descripcion'],
                      $it['cantidad'],$it['precio_unit'],$it['descuento'],$it['subtotal'],$it['producto_id']));
        }

        // Descontar stock si estado es aprobada o completada (y antes no lo era)
        $descontarStock = in_array($estado, array('aprobada','completada','en_proceso'))
                       && !in_array($estadoAnterior, array('aprobada','completada','en_proceso'));

        if ($descontarStock) {
            foreach ($items as $it) {
                if ($it['producto_id']) {
                    $prod = $db->fetchOne("SELECT stock_actual FROM productos WHERE id=?", array($it['producto_id']));
                    if ($prod) {
                        $antes = (float)$prod['stock_actual'];
                        $nuevo = max(0, $antes - $it['cantidad']);
                        $db->query("UPDATE productos SET stock_actual=? WHERE id=?", array($nuevo, $it['producto_id']));
                        $db->query("INSERT INTO inventario_movimientos
                            (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,referencia_id,usuario_id,notas)
                            VALUES (?,?,?,?,?,?,?,?,?)",
                            array($it['producto_id'],'salida',$it['cantidad'],$antes,$nuevo,
                                  'venta',$instId,$_SESSION['user_id'],'Instalación '.$folio ?? ''));
                    }
                }
            }
        }

        header('Location: ver.php?id='.$instId.(!$editMode?'&new=1':'')); exit;

    } catch (Exception $e) { $err = $e->getMessage(); }
}

$pageTitle = $editMode ? 'Editar Instalación' : 'Nueva Instalación / Cotización';
require_once __DIR__ . '/../../includes/header.php';

$clientes = $db->fetchAll("SELECT id, CONCAT(nombre,' ',apellido) AS nombre_completo, empresa FROM clientes WHERE activo=1 ORDER BY nombre");
$marcas   = $db->fetchAll("SELECT * FROM camaras_marcas WHERE activo=1 ORDER BY nombre");
$tipos    = $db->fetchAll("SELECT * FROM camaras_tipos WHERE activo=1 ORDER BY nombre");
$ivaPorc  = (float)(getSetting('iva_venta') ?: 5);
?>

<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-camera-video-fill me-2 text-primary"></i><?= $pageTitle ?></h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Instalaciones</a></li>
            <li class="breadcrumb-item active"><?= $editMode?'Editar':'Nueva' ?></li>
        </ol></nav>
    </div>
</div>

<form method="POST" id="frmInstalacion">
<div class="row g-4">

<!-- Izquierda -->
<div class="col-lg-8">

    <div class="card shadow-sm mb-4">
        <div class="card-header fw-semibold"><i class="bi bi-info-circle me-1"></i>Datos Generales</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Cliente <span class="text-danger">*</span></label>
                    <select name="cliente_id" class="form-select select2" required>
                        <option value="">— Seleccionar —</option>
                        <?php foreach ($clientes as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($instExist && $instExist['cliente_id']==$c['id'])?'selected':'' ?>><?= htmlspecialchars($c['nombre_completo']) ?><?= $c['empresa']?' ('.$c['empresa'].')':'' ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Fecha</label>
                    <input type="date" name="fecha" class="form-control" value="<?= $instExist?$instExist['fecha']:date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Estado</label>
                    <select name="estado" class="form-select">
                        <?php
                        $estados = array('cotizacion'=>'Cotización','aprobada'=>'Aprobada','en_proceso'=>'En Proceso','completada'=>'Completada');
                        foreach ($estados as $v=>$l): ?>
                        <option value="<?= $v ?>" <?= ($instExist&&$instExist['estado']===$v)?'selected':'' ?>><?= $l ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-muted">Al aprobar/iniciar se descuenta stock.</small>
                </div>
                <div class="col-md-7">
                    <label class="form-label">Dirección de Instalación</label>
                    <input type="text" name="direccion_inst" class="form-control" value="<?= htmlspecialchars($instExist['direccion_inst']??'') ?>" placeholder="Zona, colonia, municipio...">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Garantía (meses)</label>
                    <input type="number" name="garantia_meses" class="form-control" value="<?= $instExist?$instExist['garantia_meses']:12 ?>" min="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tipo de Pago</label>
                    <select name="tipo_pago" class="form-select">
                        <?php foreach (array('contado'=>'Contado','credito'=>'Crédito','transferencia'=>'Transferencia','tarjeta'=>'Tarjeta') as $v=>$l): ?>
                        <option value="<?= $v ?>" <?= ($instExist&&$instExist['tipo_pago']===$v)?'selected':'' ?>><?= $l ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- TABLA DE EQUIPOS -->
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center fw-semibold">
            <span><i class="bi bi-camera me-1"></i>Equipos y Cámaras</span>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-sm btn-outline-primary" id="btnBuscarProd" title="Buscar en inventario">
                    <i class="bi bi-search me-1"></i>Buscar en Inventario
                </button>
                <button type="button" class="btn btn-sm btn-primary" id="btnAddCam">
                    <i class="bi bi-plus-circle me-1"></i>Fila Manual
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
            <table class="table table-sm align-middle mb-0" id="tblCamaras">
                <thead class="table-light">
                    <tr>
                        <th style="width:30px">#</th>
                        <th style="width:120px">Marca</th>
                        <th style="width:110px">Tipo</th>
                        <th>Modelo/Descripción</th>
                        <th style="width:60px">Cant.</th>
                        <th style="width:100px">P.Unit (Q)</th>
                        <th style="width:90px">Desc(Q)</th>
                        <th style="width:100px">Subtotal</th>
                        <th style="width:40px"></th>
                    </tr>
                </thead>
                <tbody id="tbodyCamaras">
                <?php foreach ($detalleExist as $d): ?>
                <tr class="camRow" data-prod-id="<?= $d['producto_id'] ?? 0 ?>">
                    <td class="rowNum text-muted small">—</td>
                    <td>
                        <select name="marca_id[]" class="form-select form-select-sm" required>
                            <?php foreach ($marcas as $m): ?>
                            <option value="<?= $m['id'] ?>" <?= $d['marca_id']==$m['id']?'selected':'' ?>><?= htmlspecialchars($m['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="producto_id[]" value="<?= $d['producto_id']??0 ?>">
                    </td>
                    <td>
                        <select name="tipo_id[]" class="form-select form-select-sm">
                            <option value="">—</option>
                            <?php foreach ($tipos as $t): ?>
                            <option value="<?= $t['id'] ?>" <?= ($d['tipo_id']&&$d['tipo_id']==$t['id'])?'selected':'' ?>><?= htmlspecialchars($t['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <input type="text" name="modelo[]" class="form-control form-control-sm" value="<?= htmlspecialchars($d['modelo']??'') ?>" placeholder="Modelo">
                        <input type="text" name="detalle_desc[]" class="form-control form-control-sm mt-1" value="<?= htmlspecialchars($d['descripcion']??'') ?>" placeholder="Descripción">
                    </td>
                    <td><input type="number" name="cantidad[]" class="form-control form-control-sm camCalc" value="<?= $d['cantidad'] ?>" min="1"></td>
                    <td><input type="number" name="precio_unit[]" class="form-control form-control-sm camCalc" value="<?= $d['precio_unitario'] ?>" min="0" step="0.01"></td>
                    <td><input type="number" name="desc_item[]" class="form-control form-control-sm camCalc" value="<?= $d['descuento'] ?>" min="0" step="0.01"></td>
                    <td><span class="rowSub fw-bold text-end d-block">Q <?= number_format($d['subtotal'],2) ?></span></td>
                    <td><button type="button" class="btn btn-sm btn-outline-danger btnDelRow"><i class="bi bi-trash"></i></button></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header fw-semibold"><i class="bi bi-chat-text me-1"></i>Notas</div>
        <div class="card-body">
            <textarea name="notas" class="form-control" rows="2" placeholder="Condiciones, garantías adicionales..."><?= htmlspecialchars($instExist['notas']??'') ?></textarea>
        </div>
    </div>
</div>

<!-- Derecha - totales -->
<div class="col-lg-4">
    <div class="card shadow-sm sticky-top" style="top:80px">
        <div class="card-header fw-semibold"><i class="bi bi-calculator me-1"></i>Resumen</div>
        <div class="card-body">
            <div class="mb-3">
                <label class="form-label">Mano de Obra (Q)</label>
                <input type="number" name="costo_mano_obra" id="moObra" class="form-control calcField" value="<?= $instExist?$instExist['costo_mano_obra']:0 ?>" min="0" step="0.01">
            </div>
            <div class="mb-3">
                <label class="form-label">Materiales Adicionales (Q)</label>
                <input type="number" name="costo_materiales" id="moMat" class="form-control calcField" value="<?= $instExist?$instExist['costo_materiales']:0 ?>" min="0" step="0.01">
            </div>
            <div class="mb-3">
                <label class="form-label">Descuento Global (Q)</label>
                <input type="number" name="descuento_global" id="descGlobal" class="form-control calcField" value="<?= $instExist?$instExist['descuento']:0 ?>" min="0" step="0.01">
            </div>
            <hr>
            <table class="table table-sm table-borderless mb-0">
                <tr><td>Equipos:</td><td class="text-end fw-bold" id="rSubEq">Q 0.00</td></tr>
                <tr><td>Mano de Obra:</td><td class="text-end" id="rMoObra">Q 0.00</td></tr>
                <tr><td>Materiales:</td><td class="text-end" id="rMoMat">Q 0.00</td></tr>
                <tr><td>Desc. Global:</td><td class="text-end text-danger" id="rDesc">- Q 0.00</td></tr>
                <tr><td>IVA (<?= $ivaPorc ?>%):</td><td class="text-end" id="rIva">Q 0.00</td></tr>
                <tr class="table-active fw-bold fs-5"><td>TOTAL:</td><td class="text-end text-primary" id="rTotal">Q 0.00</td></tr>
            </table>
            <div class="d-grid gap-2 mt-3">
                <button type="submit" class="btn btn-primary btn-lg"><i class="bi bi-save me-1"></i>Guardar</button>
                <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </div>
    </div>
</div>
</div>
</form>

<!-- MODAL BÚSQUEDA DE PRODUCTOS -->
<div class="modal fade" id="modalBuscarProd" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="bi bi-search me-2"></i>Buscar Producto del Inventario</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" id="inputBuscarProd" class="form-control" placeholder="Buscar por nombre, código, marca..." autofocus>
                    <button class="btn btn-primary" id="btnSearchProd"><i class="bi bi-search"></i></button>
                </div>
                <div class="mb-2">
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-secondary filterTipo active" data-tipo="">Todos</button>
                        <button type="button" class="btn btn-outline-primary filterTipo" data-tipo="camara">📷 Cámaras</button>
                        <button type="button" class="btn btn-outline-warning filterTipo" data-tipo="kit_combo">📦 Kits</button>
                        <button type="button" class="btn btn-outline-info filterTipo" data-tipo="accesorio">🔧 Accesorios</button>
                    </div>
                </div>
                <div id="resultadosBusqueda" style="max-height:400px;overflow-y:auto">
                    <div class="text-center text-muted py-4">Escriba para buscar...</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Template fila manual -->
<template id="rowTpl">
<tr class="camRow" data-prod-id="0">
    <td class="rowNum text-muted small">—</td>
    <td>
        <select name="marca_id[]" class="form-select form-select-sm" required>
            <?php foreach ($marcas as $m): ?>
            <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="hidden" name="producto_id[]" value="0">
    </td>
    <td>
        <select name="tipo_id[]" class="form-select form-select-sm">
            <option value="">—</option>
            <?php foreach ($tipos as $t): ?>
            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
    </td>
    <td>
        <input type="text" name="modelo[]" class="form-control form-control-sm" placeholder="Modelo">
        <input type="text" name="detalle_desc[]" class="form-control form-control-sm mt-1" placeholder="Descripción">
    </td>
    <td><input type="number" name="cantidad[]" class="form-control form-control-sm camCalc" value="1" min="1"></td>
    <td><input type="number" name="precio_unit[]" class="form-control form-control-sm camCalc" value="0" min="0" step="0.01"></td>
    <td><input type="number" name="desc_item[]" class="form-control form-control-sm camCalc" value="0" min="0" step="0.01"></td>
    <td><span class="rowSub fw-bold text-end d-block">Q 0.00</span></td>
    <td><button type="button" class="btn btn-sm btn-outline-danger btnDelRow"><i class="bi bi-trash"></i></button></td>
</tr>
</template>


<?php
$ivaJs     = (float)$ivaPorc;
$marcasArr = json_encode(array_map(function($m){ return array('id'=>(int)$m['id'],'nombre'=>$m['nombre']); }, $marcas));
$tiposArr  = json_encode(array_map(function($t){ return array('id'=>(int)$t['id'],'nombre'=>$t['nombre']); }, $tipos));
ob_start();
?>
<script>
var IVA        = <?php echo $ivaJs; ?> / 100;
var APP_URL    = '<?php echo APP_URL; ?>';
var tipoFiltro = '';

function calcRow(row){
    var cant  = parseFloat(row.querySelector('[name="cantidad[]"]').value)||0;
    var price = parseFloat(row.querySelector('[name="precio_unit[]"]').value)||0;
    var desc  = parseFloat(row.querySelector('[name="desc_item[]"]').value)||0;
    var sub   = cant*price - desc;
    row.querySelector('.rowSub').textContent = 'Q ' + sub.toFixed(2);
    return sub;
}
function calcTotals(){
    var subEq = 0;
    document.querySelectorAll('.camRow').forEach(function(r){ subEq += calcRow(r); });
    var n = 1;
    document.querySelectorAll('.camRow .rowNum').forEach(function(el){ el.textContent = n++; });
    var obra = parseFloat(document.getElementById('moObra').value)||0;
    var mat  = parseFloat(document.getElementById('moMat').value)||0;
    var desc = parseFloat(document.getElementById('descGlobal').value)||0;
    var base = subEq + obra + mat - desc;
    var iva  = base * IVA;
    var tot  = base + iva;
    document.getElementById('rSubEq').textContent  = 'Q ' + subEq.toFixed(2);
    document.getElementById('rMoObra').textContent = 'Q ' + obra.toFixed(2);
    document.getElementById('rMoMat').textContent  = 'Q ' + mat.toFixed(2);
    document.getElementById('rDesc').textContent   = '- Q ' + desc.toFixed(2);
    document.getElementById('rIva').textContent    = 'Q ' + iva.toFixed(2);
    document.getElementById('rTotal').textContent  = 'Q ' + tot.toFixed(2);
}

function addRowFromProduct(prod){
    var tpl = document.getElementById('rowTpl').content.cloneNode(true);
    var row = tpl.querySelector('tr');

    var marcaEl = row.querySelector('[name="marca_id[]"]');
    for(var i = 0; i < marcaEl.options.length; i++){
        if(marcaEl.options[i].text.toLowerCase() === (prod.marca_nombre||'').toLowerCase()){
            marcaEl.options[i].selected = true; break;
        }
    }
    if(prod.tipo_camara){
        var tipoEl = row.querySelector('[name="tipo_id[]"]');
        for(var j = 0; j < tipoEl.options.length; j++){
            if(tipoEl.options[j].text.toLowerCase() === prod.tipo_camara.toLowerCase()){
                tipoEl.options[j].selected = true; break;
            }
        }
    }
    row.querySelector('[name="modelo[]"]').value      = prod.nombre || '';
    var descTxt = '';
    if(prod.resolucion) descTxt += prod.resolucion + ' ';
    if(prod.tecnologia) descTxt += '| ' + prod.tecnologia;
    row.querySelector('[name="detalle_desc[]"]').value = descTxt.trim();
    row.querySelector('[name="precio_unit[]"]').value  = prod.precio_venta || 0;
    row.querySelector('[name="producto_id[]"]').value  = prod.id || 0;
    row.setAttribute('data-prod-id', prod.id || 0);

    if(prod.stock_actual !== undefined && prod.stock_actual !== null){
        var badge = document.createElement('span');
        badge.className   = 'badge bg-' + (prod.stock_actual > 0 ? 'success' : 'danger') + ' ms-1';
        badge.textContent = 'Stock: ' + prod.stock_actual;
        var modeloInput = row.querySelector('[name="modelo[]"]');
        modeloInput.parentNode.insertBefore(badge, modeloInput.nextSibling);
    }
    document.getElementById('tbodyCamaras').appendChild(tpl);
    calcTotals();
    var modalEl   = document.getElementById('modalBuscarProd');
    var modalInst = bootstrap.Modal.getInstance(modalEl);
    if(modalInst) modalInst.hide();
}

document.getElementById('btnAddCam').addEventListener('click', function(){
    var tpl = document.getElementById('rowTpl').content.cloneNode(true);
    document.getElementById('tbodyCamaras').appendChild(tpl);
    calcTotals();
});
document.getElementById('tbodyCamaras').addEventListener('input', function(e){
    if(e.target.classList.contains('camCalc')) calcTotals();
});
document.getElementById('tbodyCamaras').addEventListener('click', function(e){
    var btn = e.target.closest('.btnDelRow');
    if(btn){ btn.closest('tr').remove(); calcTotals(); }
});
document.querySelectorAll('.calcField').forEach(function(el){
    el.addEventListener('input', calcTotals);
});

document.querySelectorAll('.filterTipo').forEach(function(btn){
    btn.addEventListener('click', function(){
        document.querySelectorAll('.filterTipo').forEach(function(b){ b.classList.remove('active'); });
        this.classList.add('active');
        tipoFiltro = this.dataset.tipo;
        buscarProductos(document.getElementById('inputBuscarProd').value.trim());
    });
});

function buscarProductos(q){
    var div = document.getElementById('resultadosBusqueda');
    div.innerHTML = '<div class="text-center py-3"><div class="spinner-border spinner-border-sm"></div></div>';
    var url = APP_URL + '/api/camaras.php?q=' + encodeURIComponent(q);
    if(!q) url = APP_URL + '/api/camaras.php?tipo=camara';
    fetch(url)
        .then(function(r){ return r.json(); })
        .then(function(data){
            var rows = data;
            if(tipoFiltro) rows = rows.filter(function(p){ return p.tipo_producto === tipoFiltro; });
            if(!rows.length){
                div.innerHTML = '<div class="text-center text-muted py-3">Sin resultados</div>';
                return;
            }
            var tipoBadge = {camara:'primary', kit_combo:'warning', accesorio:'info', producto:'secondary'};
            var tipoLabel = {camara:'Camara', kit_combo:'Kit/Combo', accesorio:'Accesorio', producto:'Producto'};
            var html = '<table class="table table-sm table-hover mb-0">'
                     + '<thead class="table-dark"><tr>'
                     + '<th>Codigo</th><th>Producto</th><th>Tipo</th><th>Stock</th><th>Precio</th><th></th>'
                     + '</tr></thead><tbody>';
            rows.forEach(function(p){
                var tb = tipoBadge[p.tipo_producto] || 'secondary';
                var tl = tipoLabel[p.tipo_producto] || p.tipo_producto;
                var sb = (p.stock_actual > 0) ? 'success' : 'danger';
                var ex = '';
                if(p.marca_nombre) ex += '<span class="badge bg-primary me-1">' + p.marca_nombre + '</span>';
                if(p.resolucion)   ex += '<span class="badge bg-info text-dark me-1">' + p.resolucion + '</span>';
                if(p.tecnologia)   ex += '<span class="badge bg-secondary me-1">' + p.tecnologia + '</span>';
                var prodJson = JSON.stringify(p).replace(/'/g, '&#39;');
                html += '<tr>'
                      + '<td><code>' + p.codigo + '</code></td>'
                      + '<td><strong>' + p.nombre + '</strong><br><small>' + ex + '</small></td>'
                      + '<td><span class="badge bg-' + tb + '">' + tl + '</span></td>'
                      + '<td><span class="badge bg-' + sb + '">' + p.stock_actual + '</span></td>'
                      + '<td class="fw-bold">Q ' + parseFloat(p.precio_venta).toFixed(2) + '</td>'
                      + '<td><button type="button" class="btn btn-sm btn-primary btnSelectProd"'
                      + ' data-prod=\'' + prodJson + '\'><i class="bi bi-plus"></i></button></td>'
                      + '</tr>';
            });
            html += '</tbody></table>';
            div.innerHTML = html;
            div.querySelectorAll('.btnSelectProd').forEach(function(btn){
                btn.addEventListener('click', function(){
                    try { addRowFromProduct(JSON.parse(this.dataset.prod)); }
                    catch(e){ console.error('Parse error', e); }
                });
            });
        })
        .catch(function(){
            div.innerHTML = '<div class="alert alert-danger">Error al conectar con el servidor</div>';
        });
}

document.getElementById('btnBuscarProd').addEventListener('click', function(){
    var modal = new bootstrap.Modal(document.getElementById('modalBuscarProd'));
    modal.show();
    buscarProductos('');
});

var searchTimer;
document.getElementById('inputBuscarProd').addEventListener('input', function(){
    clearTimeout(searchTimer);
    var val = this.value.trim();
    searchTimer = setTimeout(function(){ buscarProductos(val); }, 350);
});
document.getElementById('btnSearchProd').addEventListener('click', function(){
    buscarProductos(document.getElementById('inputBuscarProd').value.trim());
});

$(document).on('click', '.btnConfirm', function(e){
    e.preventDefault();
    var url = $(this).attr('href');
    var msg = $(this).data('msg') || 'Confirmar accion?';
    Swal.fire({title: msg, icon: 'warning', showCancelButton: true,
               confirmButtonText: 'Si', cancelButtonText: 'No'})
        .then(function(r){ if(r.isConfirmed) window.location = url; });
});

calcTotals();
</script>
<?php
$extraJs = ob_get_clean();
require_once __DIR__ . '/../../includes/footer.php';
?>

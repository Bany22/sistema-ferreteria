<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$pageTitle = 'Existencias';
require_once __DIR__ . '/../../includes/header.php';
$db = Database::getInstance();

// ── Ajuste de inventario ─────────────────────────────────────────
$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajuste'])) {
    $prodId   = (int)$_POST['producto_id'];
    $cantidad = (float)$_POST['cantidad'];
    $tipo     = $_POST['tipo']  ?? '';
    $notas    = trim($_POST['notas'] ?? '');

    if ($prodId && $cantidad != 0) {
        $prod = $db->fetchOne("SELECT stock_actual, nombre FROM productos WHERE id=?", [$prodId]);
        if ($prod) {
            if ($tipo === 'ajuste')       { $nuevoStock = $cantidad; }
            elseif ($tipo === 'entrada')  { $nuevoStock = $prod['stock_actual'] + $cantidad; }
            else                          { $nuevoStock = $prod['stock_actual'] - $cantidad; }

            $db->query("UPDATE productos SET stock_actual=? WHERE id=?", [$nuevoStock, $prodId]);
            $db->query(
                "INSERT INTO inventario_movimientos
                 (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,usuario_id,notas)
                 VALUES (?,?,?,?,?,?,?,?)",
                [$prodId, $tipo, abs($cantidad), $prod['stock_actual'], $nuevoStock, 'ajuste', $_SESSION['user_id'], $notas]
            );
            $success = "Stock de '{$prod['nombre']}' actualizado. Nuevo stock: " . number_format($nuevoStock, 2);
        }
    }
}

// ── Consultas ────────────────────────────────────────────────────
$productos = $db->fetchAll(
    "SELECT p.*, c.nombre as categoria
     FROM productos p
     LEFT JOIN categorias c ON p.categoria_id = c.id
     WHERE p.activo = 1
     ORDER BY p.nombre"
);

$movimientos = $db->fetchAll(
    "SELECT im.*, p.nombre as producto, p.codigo,
            CONCAT(u.nombre,' ',u.apellido) as usuario
     FROM inventario_movimientos im
     JOIN productos p ON im.producto_id = p.id
     JOIN usuarios u  ON im.usuario_id  = u.id
     WHERE im.activo = 1
     ORDER BY im.id DESC LIMIT 50"
);

$letrasUsadas = $db->fetchAll(
    "SELECT DISTINCT seccion_letra FROM productos
     WHERE seccion_letra IS NOT NULL AND seccion_letra <> '' AND activo=1
     ORDER BY seccion_letra"
);
$numerosUsados = $db->fetchAll(
    "SELECT DISTINCT seccion_numero FROM productos
     WHERE seccion_numero IS NOT NULL AND seccion_numero <> '' AND activo=1
     ORDER BY seccion_numero"
);

$stockBajo = array_filter($productos, function($p) {
    return $p['stock_minimo'] > 0 && $p['stock_actual'] <= $p['stock_minimo'];
});
?>

<?php if ($success): ?>
<div class="alert alert-success alert-auto-close alert-dismissible">
    <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible">
    <?= htmlspecialchars($error) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Page Header -->
<div class="page-header">
    <div>
        <h1><i class="bi bi-clipboard-data me-2 text-primary"></i>Existencias</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Existencias</li>
        </ol></nav>
    </div>
    <button class="btn btn-primary btn-sm-full"
            data-bs-toggle="modal" data-bs-target="#modalAjuste">
        <i class="bi bi-arrow-left-right me-1"></i>
        <span class="d-none d-sm-inline">Ajuste de Inventario</span>
        <span class="d-sm-none">Ajuste</span>
    </button>
</div>

<?php if (!empty($stockBajo)): ?>
<div class="alert alert-warning alert-dismissible">
    <i class="bi bi-exclamation-triangle-fill me-2"></i>
    <strong><?= count($stockBajo) ?> producto(s)</strong> con stock por debajo del mínimo.
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- ═══════════════════════════════════════════════════
     CARD INVENTARIO
════════════════════════════════════════════════════ -->
<div class="card mb-4">

    <!-- Barra 1: título + buscador + filtros de stock -->
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <span class="fw-semibold">
                <i class="bi bi-boxes me-1"></i>Inventario Actual
                <small class="text-muted ms-1" id="filtroCount"></small>
            </span>
            <!-- Buscador + botones — colapsan verticalmente en móvil -->
            <div class="d-flex align-items-center flex-wrap gap-2 w-100 w-md-auto mt-2 mt-sm-0">
                <div class="input-group input-group-sm flex-grow-1" style="min-width:180px;max-width:320px">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" id="buscarProducto" class="form-control"
                           placeholder="Nombre, código o sección…" autocomplete="off">
                    <button class="btn btn-outline-secondary" type="button"
                            id="btnLimpiar" title="Limpiar búsqueda">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
                <!-- Botones de stock: texto corto en móvil, completo en desktop -->
                <div class="btn-group btn-group-sm" role="group" aria-label="Filtrar por stock">
                    <button id="bst-todos" class="btn btn-secondary"
                            onclick="setStock('todos',this)">
                        <i class="bi bi-list d-sm-none"></i>
                        <span class="d-none d-sm-inline">Todos</span>
                    </button>
                    <button id="bst-bajo" class="btn btn-outline-danger"
                            onclick="setStock('bajo',this)">
                        <i class="bi bi-arrow-down-circle d-sm-none"></i>
                        <span class="d-none d-sm-inline">Stock Bajo</span>
                    </button>
                    <button id="bst-cero" class="btn btn-outline-warning"
                            onclick="setStock('cero',this)">
                        <i class="bi bi-slash-circle d-sm-none"></i>
                        <span class="d-none d-sm-inline">Sin Stock</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Barra 2: filtros de sección (scroll horizontal en móvil) -->
    <div class="card-header py-2 inv-sec-bar">
        <div class="d-flex align-items-center gap-2 sec-scroll-wrap">
            <small class="text-muted fw-semibold text-nowrap">
                <i class="bi bi-map me-1 text-primary"></i>Sección:
            </small>
            <div class="d-flex flex-wrap gap-1" id="secBtnsWrap">
                <button class="btn-sec active" onclick="setSec('',this)">
                    <i class="bi bi-grid-fill me-1"></i>Todas
                </button>
                <?php foreach ($letrasUsadas as $l): ?>
                <button class="btn-sec"
                        onclick="setSec('<?= strtolower(htmlspecialchars($l['seccion_letra'])) ?>',this)">
                    <i class="bi bi-bookmark-fill me-1"></i>
                    Secc.&nbsp;<?= htmlspecialchars($l['seccion_letra']) ?>
                </button>
                <?php endforeach; ?>
                <?php if (!empty($numerosUsados)): ?>
                <span class="vr mx-1 align-self-stretch"></span>
                <?php foreach ($numerosUsados as $n): ?>
                <button class="btn-sec btn-sec-num"
                        onclick="setSec('<?= strtolower(htmlspecialchars($n['seccion_numero'])) ?>',this)">
                    <i class="bi bi-hash me-1"></i><?= htmlspecialchars($n['seccion_numero']) ?>
                </button>
                <?php endforeach; ?>
                <?php endif; ?>
                <?php if (empty($letrasUsadas) && empty($numerosUsados)): ?>
                <small class="text-muted fst-italic">Sin secciones asignadas todavía</small>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tabla principal -->
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" style="min-width:900px">
                <thead class="table-dark">
                    <tr>
                        <th>Código</th>
                        <th>Producto</th>
                        <th class="d-none d-md-table-cell">Categoría</th>
                        <th class="text-center">Sección</th>
                        <th>Stock</th>
                        <th class="d-none d-lg-table-cell">Mín.</th>
                        <th class="d-none d-lg-table-cell">Máx.</th>
                        <th class="d-none d-md-table-cell">Unid.</th>
                        <th class="d-none d-xl-table-cell">P. Costo</th>
                        <th class="d-none d-xl-table-cell">P. Venta</th>
                        <th class="d-none d-xl-table-cell">Valor Inv.</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody id="tbodyInv">
                <?php foreach ($productos as $p):
                    $st  = $p['stock_actual'] <= 0
                        ? 'cero'
                        : ($p['stock_minimo'] > 0 && $p['stock_actual'] <= $p['stock_minimo'] ? 'bajo' : 'ok');
                    $pct = $p['stock_maximo'] > 0
                        ? min(100, ($p['stock_actual'] / $p['stock_maximo']) * 100)
                        : 50;
                    $bar = $st === 'ok' ? '#16a34a' : ($st === 'bajo' ? '#d97706' : '#dc2626');
                    $sl  = trim($p['seccion_letra']  ?? '');
                    $sn  = trim($p['seccion_numero'] ?? '');
                    $slb = $sl . ($sl && $sn ? '-' : '') . $sn;
                    $sd  = strtolower($slb);
                ?>
                <tr data-st="<?= $st ?>"
                    data-sec="<?= htmlspecialchars($sd, ENT_QUOTES) ?>"
                    data-nom="<?= htmlspecialchars(strtolower($p['nombre']), ENT_QUOTES) ?>"
                    data-cod="<?= htmlspecialchars(strtolower($p['codigo']), ENT_QUOTES) ?>"
                    data-cat="<?= htmlspecialchars(strtolower($p['categoria'] ?? ''), ENT_QUOTES) ?>">

                    <td class="text-nowrap">
                        <code><?= htmlspecialchars($p['codigo']) ?></code>
                    </td>

                    <td>
                        <div class="fw-semibold"><?= htmlspecialchars($p['nombre']) ?></div>
                        <?php if ($sl || $sn): ?>
                        <div class="mt-1">
                            <?php if ($sl): ?>
                            <span class="badge bg-primary badge-sec">
                                <i class="bi bi-bookmark-fill me-1"></i>Secc.&nbsp;<?= htmlspecialchars($sl) ?>
                            </span>
                            <?php endif; ?>
                            <?php if ($sn): ?>
                            <span class="badge bg-warning text-dark badge-sec">
                                <i class="bi bi-hash me-1"></i>Pos.&nbsp;<?= htmlspecialchars($sn) ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <!-- Categoría visible solo en móvil (debajo del nombre) -->
                        <div class="d-md-none text-muted small mt-1">
                            <?= htmlspecialchars($p['categoria'] ?? '—') ?>
                        </div>
                    </td>

                    <td class="d-none d-md-table-cell text-muted">
                        <?= htmlspecialchars($p['categoria'] ?? '—') ?>
                    </td>

                    <td class="text-center text-nowrap">
                        <?php if ($slb): ?>
                        <span class="badge bg-dark border border-secondary badge-sec">
                            <i class="bi bi-geo-alt-fill me-1 text-info"></i><?= htmlspecialchars($slb) ?>
                        </span>
                        <?php else: ?>
                        <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>

                    <td style="min-width:100px">
                        <span class="fw-bold <?= $st === 'ok' ? 'stock-ok' : 'stock-low' ?>">
                            <?= number_format($p['stock_actual'], 2) ?>
                        </span>
                        <small class="text-muted ms-1 d-md-none"><?= htmlspecialchars($p['unidad_medida']) ?></small>
                        <div class="stock-bar mt-1">
                            <div class="stock-bar-fill" style="width:<?= $pct ?>%;background:<?= $bar ?>"></div>
                        </div>
                    </td>

                    <td class="d-none d-lg-table-cell"><?= number_format($p['stock_minimo'], 2) ?></td>
                    <td class="d-none d-lg-table-cell"><?= number_format($p['stock_maximo'], 2) ?></td>
                    <td class="d-none d-md-table-cell"><?= htmlspecialchars($p['unidad_medida']) ?></td>
                    <td class="d-none d-xl-table-cell text-nowrap">Q <?= number_format($p['precio_costo'], 2) ?></td>
                    <td class="d-none d-xl-table-cell text-nowrap">Q <?= number_format($p['precio_venta'], 2) ?></td>
                    <td class="d-none d-xl-table-cell fw-bold text-nowrap">
                        Q <?= number_format($p['stock_actual'] * $p['precio_costo'], 2) ?>
                    </td>

                    <td class="text-nowrap">
                        <?php if ($st === 'cero'): ?>
                        <span class="badge-cancelada">Sin Stock</span>
                        <?php elseif ($st === 'bajo'): ?>
                        <span class="badge-pendiente">Stock Bajo</span>
                        <?php else: ?>
                        <span class="badge-activo">Normal</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Sin resultados -->
        <div id="sinRes" class="text-center text-muted py-5" style="display:none">
            <i class="bi bi-search fs-1 d-block mb-2 opacity-25"></i>
            <strong>Sin resultados</strong><br>
            <small>Intenta con otros términos o limpia los filtros.</small>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════
     MOVIMIENTOS RECIENTES
════════════════════════════════════════════════════ -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-clock-history me-2"></i>Últimos Movimientos</span>
        <small class="text-muted">Últimos 50</small>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm align-middle mb-0" id="tblMovimientos" style="min-width:650px">
                <thead class="table-light">
                    <tr>
                        <th>Fecha</th>
                        <th>Producto</th>
                        <th>Tipo</th>
                        <th class="text-end">Cantidad</th>
                        <th class="text-end d-none d-md-table-cell">Stock Ant.</th>
                        <th class="text-end">Stock Nuevo</th>
                        <th class="d-none d-lg-table-cell">Usuario</th>
                        <th class="d-none d-lg-table-cell">Notas</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($movimientos as $m): ?>
                <tr>
                    <td class="text-nowrap text-muted" style="font-size:.8rem">
                        <?= date('d/m/y H:i', strtotime($m['created_at'])) ?>
                    </td>
                    <td>
                        <div class="fw-semibold" style="font-size:.85rem"><?= htmlspecialchars($m['producto']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($m['codigo']) ?></small>
                    </td>
                    <td>
                        <span class="badge bg-<?= $m['tipo'] === 'entrada' ? 'success' : ($m['tipo'] === 'salida' ? 'danger' : 'warning') ?> text-white">
                            <?= ucfirst($m['tipo']) ?>
                        </span>
                    </td>
                    <td class="text-end"><?= number_format($m['cantidad'], 2) ?></td>
                    <td class="text-end d-none d-md-table-cell text-muted">
                        <?= number_format($m['stock_anterior'], 2) ?>
                    </td>
                    <td class="text-end fw-bold"><?= number_format($m['stock_nuevo'], 2) ?></td>
                    <td class="d-none d-lg-table-cell text-muted" style="font-size:.8rem">
                        <?= htmlspecialchars($m['usuario']) ?>
                    </td>
                    <td class="d-none d-lg-table-cell text-muted" style="font-size:.8rem">
                        <?= htmlspecialchars($m['notas'] ?? '') ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════
     MODAL AJUSTE DE INVENTARIO
════════════════════════════════════════════════════ -->
<div class="modal fade" id="modalAjuste" tabindex="-1" aria-labelledby="modalAjusteLabel">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <form method="POST">
            <input type="hidden" name="ajuste" value="1">

            <div class="modal-header">
                <h5 class="modal-title" id="modalAjusteLabel">
                    <i class="bi bi-arrow-left-right me-2"></i>Ajuste de Inventario
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <!-- Producto -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Producto</label>
                    <select name="producto_id" id="selAjuste" class="form-select"
                            required onchange="verSeccion(this)">
                        <option value="">— Seleccionar producto —</option>
                        <?php foreach ($productos as $p):
                            $sl2 = trim($p['seccion_letra']  ?? '');
                            $sn2 = trim($p['seccion_numero'] ?? '');
                            $sx  = $sl2 . ($sl2 && $sn2 ? '-' : '') . $sn2;
                        ?>
                        <option value="<?= $p['id'] ?>"
                                data-sl="<?= htmlspecialchars($sl2) ?>"
                                data-sn="<?= htmlspecialchars($sn2) ?>">
                            <?= htmlspecialchars($p['codigo'] . ' — ' . $p['nombre']) ?>
                            <?= $sx ? ' [' . $sx . ']' : '' ?>
                            (Stock: <?= number_format($p['stock_actual'], 2) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <!-- BUG CORREGIDO: un solo atributo style, usando id único para show/hide por JS -->
                    <div id="ajusteSecInfo" class="alert alert-info py-2 px-3 mt-2 mb-0
                                                    d-flex gap-2 align-items-center"
                         style="display:none!important;font-size:.83rem">
                        <i class="bi bi-geo-alt-fill flex-shrink-0"></i>
                        <span>Ubicación:</span>
                        <span id="ajusteSecL"></span>
                        <span id="ajusteSecN"></span>
                    </div>
                </div>

                <!-- Tipo -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Tipo de Movimiento</label>
                    <select name="tipo" class="form-select" required>
                        <option value="entrada">Entrada — Agregar stock (+)</option>
                        <option value="salida">Salida — Restar stock (−)</option>
                        <option value="ajuste">Ajuste Directo — Establecer cantidad exacta</option>
                    </select>
                </div>

                <!-- Cantidad -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Cantidad</label>
                    <input type="number" name="cantidad" class="form-control"
                           min="0.01" step="0.01" required placeholder="0.00">
                </div>

                <!-- Notas -->
                <div class="mb-1">
                    <label class="form-label fw-semibold">Notas / Motivo</label>
                    <textarea name="notas" class="form-control" rows="2"
                              placeholder="Motivo del ajuste…"></textarea>
                </div>

            </div><!-- /modal-body -->

            <div class="modal-footer flex-column flex-sm-row gap-2">
                <button type="button" class="btn btn-outline-secondary w-100 w-sm-auto"
                        data-bs-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary w-100 w-sm-auto">
                    <i class="bi bi-check-lg me-1"></i>Aplicar Ajuste
                </button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════════════════
     ESTILOS LOCALES
════════════════════════════════════════════════════ -->
<style>
/* Botones de sección */
.btn-sec {
    display: inline-flex;
    align-items: center;
    padding: 3px 10px;
    border-radius: 999px;
    border: 1.5px solid #adb5bd;
    background: #fff;
    color: #495057;
    font-size: .73rem;
    font-weight: 500;
    cursor: pointer;
    transition: background .15s, color .15s, border-color .15s;
    white-space: nowrap;
    line-height: 1.7;
}
.btn-sec:hover   { border-color:#0d6efd; color:#0d6efd; background:#f0f5ff; }
.btn-sec.active  { background:#0d6efd; border-color:#0d6efd; color:#fff; font-weight:700; }
.btn-sec-num             { border-color:#ffc107; color:#856404; }
.btn-sec-num:hover       { background:#fff8e1; border-color:#f59e0b; }
.btn-sec-num.active      { background:#ffc107; border-color:#ffc107; color:#212529; font-weight:700; }

/* Badge de sección dentro de la tabla */
.badge-sec { font-size:.68rem; }

/* Scroll horizontal en barra de secciones en móvil */
.inv-sec-bar { overflow-x: auto; }
.sec-scroll-wrap { flex-wrap: nowrap; min-width: max-content; }
@media (min-width: 768px) {
    .sec-scroll-wrap { flex-wrap: wrap; min-width: 0; }
    #secBtnsWrap     { flex-wrap: wrap; }
}

/* Modal footer responsive */
.w-sm-auto { width: auto !important; }
@media (max-width: 575px) {
    .w-sm-auto { width: 100% !important; }
    .modal-footer { gap: .5rem; }
}

/* Botón principal full-width en móvil */
@media (max-width: 575px) {
    .btn-sm-full { width: 100%; }
    .page-header { flex-direction: column; align-items: stretch; }
}
</style>

<!-- ═══════════════════════════════════════════════════
     JAVASCRIPT
════════════════════════════════════════════════════ -->
<script>
(function() {
    /* ── Estado de filtros ── */
    var F = { stock: 'todos', sec: '', busq: '' };

    /* ── Utilidades ── */
    function decodeHtml(s) {
        var d = document.createElement('div');
        d.innerHTML = s || '';
        return d.textContent || d.innerText || '';
    }
    function norm(s) {
        return decodeHtml(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    }

    /* ── Motor de filtrado ── */
    function filtrar() {
        var rows = document.querySelectorAll('#tbodyInv tr');
        var vis  = 0;
        var q    = norm(F.busq);

        rows.forEach(function(tr) {
            var nom = norm(tr.dataset.nom || '');
            var cod = norm(tr.dataset.cod || '');
            var cat = norm(tr.dataset.cat || '');
            var st  = tr.dataset.st  || '';
            var sec = tr.dataset.sec || '';

            var okB = !q || nom.includes(q) || cod.includes(q) || cat.includes(q);
            var okS = F.stock === 'todos' || st === F.stock;
            var okC = !F.sec  || sec.includes(F.sec);

            tr.style.display = (okB && okS && okC) ? '' : 'none';
            if (okB && okS && okC) vis++;
        });

        var cnt = document.getElementById('filtroCount');
        if (cnt) cnt.textContent = '— ' + vis + ' producto(s)';
        var sr = document.getElementById('sinRes');
        if (sr) sr.style.display = vis === 0 ? 'block' : 'none';
    }

    /* ── Stock buttons ── */
    function resetStockBtns(activeId) {
        var map = {
            'bst-todos': ['btn-secondary',  'btn-outline-secondary'],
            'bst-bajo':  ['btn-danger',     'btn-outline-danger'],
            'bst-cero':  ['btn-warning',    'btn-outline-warning']
        };
        Object.keys(map).forEach(function(id) {
            var el = document.getElementById(id);
            if (!el) return;
            el.classList.remove(map[id][0], map[id][1]);
            el.classList.add(id === activeId ? map[id][0] : map[id][1]);
        });
    }

    /* ── Sección buttons ── */
    function resetSecBtns(activeBtn) {
        document.querySelectorAll('.btn-sec').forEach(function(b) { b.classList.remove('active'); });
        if (activeBtn) activeBtn.classList.add('active');
    }

    /* ── Exponer funciones globales para onclick en HTML ── */
    window.setStock = function(val, btn) {
        F.stock = val;
        resetStockBtns(btn.id);
        filtrar();
    };
    window.setSec = function(val, btn) {
        F.sec = val;
        resetSecBtns(btn);
        filtrar();
    };
    window.verSeccion = function(sel) {
        var opt = sel.options[sel.selectedIndex];
        var sl  = opt ? (opt.getAttribute('data-sl') || '') : '';
        var sn  = opt ? (opt.getAttribute('data-sn') || '') : '';
        var inf = document.getElementById('ajusteSecInfo');
        if (sel.value && (sl || sn)) {
            document.getElementById('ajusteSecL').innerHTML = sl
                ? '<span class="badge bg-primary"><i class="bi bi-bookmark-fill me-1"></i>Sección ' + sl + '</span> ' : '';
            document.getElementById('ajusteSecN').innerHTML = sn
                ? '<span class="badge bg-warning text-dark"><i class="bi bi-hash me-1"></i>Pos. ' + sn + '</span>' : '';
            inf.style.removeProperty('display');
            inf.style.display = 'flex';
        } else {
            inf.style.removeProperty('display');
            inf.style.display = 'none';
        }
    };

    /* ── Inicializar cuando el DOM esté listo ── */
    document.addEventListener('DOMContentLoaded', function() {

        /* Buscador */
        var inp = document.getElementById('buscarProducto');
        if (inp) {
            inp.addEventListener('input', function() {
                F.busq = this.value.trim();
                filtrar();
            });
            inp.addEventListener('keyup', function() {
                F.busq = this.value.trim();
                filtrar();
            });
        }

        /* Limpiar */
        var btnLimpiar = document.getElementById('btnLimpiar');
        if (btnLimpiar) {
            btnLimpiar.addEventListener('click', function() {
                var inp2 = document.getElementById('buscarProducto');
                if (inp2) inp2.value = '';
                F = { stock: 'todos', sec: '', busq: '' };
                resetStockBtns('bst-todos');
                resetSecBtns(document.querySelector('.btn-sec'));
                filtrar();
            });
        }

        /* DataTables solo en movimientos */
        if (typeof $.fn !== 'undefined' && $.fn.DataTable) {
            $('#tblMovimientos').DataTable({
                order: [[0, 'desc']], pageLength: 10, responsive: true,
                language: {
                    search: 'Buscar:', lengthMenu: 'Mostrar _MENU_',
                    info: '_START_-_END_ de _TOTAL_', infoEmpty: '0 registros',
                    zeroRecords: 'Sin resultados',
                    paginate: { first:'«', last:'»', next:'›', previous:'‹' }
                }
            });
        }

        /* Conteo inicial */
        filtrar();
    });
})();
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
$pageTitle = 'Configuración';
require_once __DIR__ . '/../../includes/header.php';

if (!Auth::isAdmin()) {
    echo '<div class="alert alert-danger">Acceso denegado.</div>';
    require_once __DIR__ . '/../../includes/footer.php';
    exit;
}

$db      = Database::getInstance();
$success = '';
$error   = '';

// Ruta absoluta real de la raíz del proyecto (ferreteria/)
// __DIR__ aquí es: C:\xampp\htdocs\ferreteria\modules\configuracion
$rootPath = realpath(__DIR__ . '/../../');   // → C:\xampp\htdocs\ferreteria

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Subida de logo
    if (isset($_FILES['logo_empresa']) && $_FILES['logo_empresa']['error'] === UPLOAD_ERR_OK) {
        $file    = $_FILES['logo_empresa'];
        $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $extOk   = ['png','jpg','jpeg','gif','webp','svg'];
        $maxSize = 2 * 1024 * 1024; // 2 MB

        if (!in_array($ext, $extOk)) {
            $error = 'Formato no permitido. Use PNG, JPG, GIF, WEBP o SVG.';
        } elseif ($file['size'] > $maxSize) {
            $error = 'El archivo es demasiado grande. Máximo 2 MB.';
        } else {
            $uploadDir = $rootPath . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'logos' . DIRECTORY_SEPARATOR;
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Borrar logo anterior del disco
            $prev = $db->fetchOne("SELECT valor FROM configuracion WHERE clave='logo_empresa'");
            if ($prev && !empty($prev['valor'])) {
                $old = $rootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $prev['valor']);
                if (file_exists($old)) @unlink($old);
            }

            $nombre  = 'logo_' . time() . '.' . $ext;
            $destino = $uploadDir . $nombre;

            if (move_uploaded_file($file['tmp_name'], $destino)) {
                $ruta = 'uploads/logos/' . $nombre; // siempre con /
                // INSERT si no existe, UPDATE si ya existe
                $db->query(
                    "INSERT INTO configuracion (clave, valor, descripcion)
                     VALUES ('logo_empresa', ?, 'Ruta del logo de la empresa')
                     ON DUPLICATE KEY UPDATE valor = VALUES(valor)",
                    [$ruta]
                );
                $success = 'Logo guardado correctamente.';
            } else {
                $error = 'No se pudo mover el archivo.'
                       . ' | Destino: ' . $destino
                       . ' | Carpeta existe: ' . (is_dir($uploadDir) ? 'Sí' : 'No')
                       . ' | Escribible: ' . (is_writable($uploadDir) ? 'Sí' : 'No');
            }
        }
    }

    // Eliminar logo
    if (isset($_POST['eliminar_logo'])) {
        $prev = $db->fetchOne("SELECT valor FROM configuracion WHERE clave='logo_empresa'");
        if ($prev && !empty($prev['valor'])) {
            $old = $rootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $prev['valor']);
            if (file_exists($old)) @unlink($old);
        }
        $db->query(
            "INSERT INTO configuracion (clave, valor, descripcion)
             VALUES ('logo_empresa', '', 'Ruta del logo de la empresa')
             ON DUPLICATE KEY UPDATE valor = ''"
        );
        $success = 'Logo eliminado.';
    }

    // Campos de texto
    if (!$error) {
        $keys = ['empresa_nombre','empresa_rfc','empresa_direccion','empresa_telefono','empresa_email'];
        foreach ($keys as $key) {
            if (isset($_POST[$key])) {
                $db->query("UPDATE configuracion SET valor=? WHERE clave=?", [trim($_POST[$key]), $key]);
            }
        }
        if (!$success) $success = 'Configuración guardada exitosamente.';
    }
}

// Leer config fresca
$config = [];
$rows = $db->fetchAll("SELECT clave, valor FROM configuracion");
foreach ($rows as $r) $config[$r['clave']] = $r['valor'];

function cfg($key) { global $config; return htmlspecialchars($config[$key] ?? ''); }

$logoGuardado = $config['logo_empresa'] ?? '';
$logoAbsoluto = $logoGuardado ? ($rootPath . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $logoGuardado)) : '';
$logoValido   = $logoGuardado && $logoAbsoluto && file_exists($logoAbsoluto);

// URL pública del logo: APP_URL ya trae la base correcta
$logoUrl = $logoValido ? (APP_URL . '/' . $logoGuardado . '?v=' . filemtime($logoAbsoluto)) : '';
?>

<?php if ($success): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error):   ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i><?= $error ?></div><?php endif; ?>

<div class="page-header">
    <div><h1><i class="bi bi-gear me-2 text-primary"></i>Configuración del Sistema</h1></div>
</div>

<form method="POST" enctype="multipart/form-data">
<div class="row g-4">
    <div class="col-lg-8">

        <!-- DATOS DE LA EMPRESA -->
        <div class="card mb-4">
            <div class="card-header"><i class="bi bi-building me-2"></i>Datos de la Empresa</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label">Nombre de la Empresa</label>
                        <input type="text" name="empresa_nombre" class="form-control" value="<?= cfg('empresa_nombre') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">NIT / RFC</label>
                        <input type="text" name="empresa_rfc" class="form-control" value="<?= cfg('empresa_rfc') ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Dirección Fiscal</label>
                        <input type="text" name="empresa_direccion" class="form-control" value="<?= cfg('empresa_direccion') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Teléfono</label>
                        <input type="text" name="empresa_telefono" class="form-control" value="<?= cfg('empresa_telefono') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Email</label>
                        <input type="email" name="empresa_email" class="form-control" value="<?= cfg('empresa_email') ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- LOGO DEL SISTEMA -->
        <div class="card mb-4">
            <div class="card-header"><i class="bi bi-image me-2"></i>Logo del Sistema</div>
            <div class="card-body">
                <div class="row g-3 align-items-start">

                    <!-- Vista previa -->
                    <div class="col-md-4 text-center">
                        <p class="small text-muted mb-2">Logo actual</p>
                        <div class="border rounded-3 d-flex align-items-center justify-content-center mx-auto"
                             style="width:160px;height:100px;background:#f8f9fa;overflow:hidden;">
                            <?php if ($logoValido): ?>
                                <img id="logoPreview"
                                     src="<?= htmlspecialchars($logoUrl) ?>"
                                     alt="Logo"
                                     style="max-width:150px;max-height:90px;object-fit:contain;">
                            <?php else: ?>
                                <span id="logoPlaceholder" class="text-muted" style="font-size:.8rem">Sin logo</span>
                                <img id="logoPreview" src="" alt="" style="max-width:150px;max-height:90px;object-fit:contain;display:none;">
                            <?php endif; ?>
                        </div>
                        <?php if ($logoValido): ?>
                        <button type="submit" name="eliminar_logo" value="1"
                                class="btn btn-outline-danger btn-sm mt-2"
                                onclick="return confirm('¿Eliminar el logo actual?')">
                            <i class="bi bi-trash me-1"></i>Eliminar logo
                        </button>
                        <?php endif; ?>
                    </div>

                    <!-- Input subida -->
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Subir nuevo logo</label>
                        <input type="file" name="logo_empresa" id="inputLogo"
                               class="form-control" accept=".png,.jpg,.jpeg,.gif,.webp,.svg">
                        <div class="form-text mt-2">
                            Formatos: <strong>PNG, JPG, GIF, WEBP, SVG</strong> — Máximo <strong>2 MB</strong><br>
                            Recomendado: fondo transparente (PNG), aprox. 300×100 px.
                        </div>
                        <div class="alert alert-info mt-3 p-2 small mb-0">
                            <i class="bi bi-info-circle me-1"></i>
                            El logo aparecerá en la pantalla de <strong>inicio de sesión</strong>.
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- SIDEBAR: solo botón guardar -->
    <div class="col-lg-4">
        <div class="d-grid">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-save me-2"></i>Guardar Configuración
            </button>
        </div>
    </div>
</div>
</form>

<script>
document.getElementById('inputLogo').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const preview     = document.getElementById('logoPreview');
    const placeholder = document.getElementById('logoPlaceholder');
    const reader      = new FileReader();
    reader.onload = function (e) {
        preview.src           = e.target.result;
        preview.style.display = 'block';
        if (placeholder) placeholder.style.display = 'none';
    };
    reader.readAsDataURL(file);
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

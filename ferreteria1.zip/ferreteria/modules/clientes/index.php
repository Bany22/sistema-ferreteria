<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db = Database::getInstance();
$error = '';

if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
    $id = (int)$_GET['id'];
    $r = $db->fetchOne("SELECT activo FROM clientes WHERE id=?", [$id]);
    if ($r) $db->query("UPDATE clientes SET activo=? WHERE id=?", [$r['activo'] ? 0 : 1, $id]);
    header('Location: index.php?ok=1'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = array(
        'nombre'        => trim($_POST['nombre'] ?? ''),
        'apellido'      => trim($_POST['apellido'] ?? ''),
        'empresa'       => trim($_POST['empresa'] ?? ''),
        'rfc'           => trim($_POST['rfc'] ?? ''),
        'email'         => trim($_POST['email'] ?? ''),
        'telefono'      => trim($_POST['telefono'] ?? ''),
        'direccion'     => trim($_POST['direccion'] ?? ''),
        'ciudad'        => trim($_POST['ciudad'] ?? ''),
        'estado'        => trim($_POST['estado_dir'] ?? ''),
        'cp'            => trim($_POST['cp'] ?? ''),
        'limite_credito'=> (float)($_POST['limite_credito'] ?? 0),
        'notas'         => trim($_POST['notas'] ?? ''),
        'activo'        => isset($_POST['activo']) ? 1 : 0,
    );
    $id = (int)($_POST['id'] ?? 0);

    if (empty($data['nombre'])) {
        $error = 'El nombre es obligatorio.';
    } else {
        if ($id) {
            $db->query(
                "UPDATE clientes SET nombre=?,apellido=?,empresa=?,rfc=?,email=?,telefono=?,direccion=?,ciudad=?,estado=?,cp=?,limite_credito=?,notas=?,activo=? WHERE id=?",
                array($data['nombre'],$data['apellido'],$data['empresa'],$data['rfc'],$data['email'],
                      $data['telefono'],$data['direccion'],$data['ciudad'],$data['estado'],$data['cp'],
                      $data['limite_credito'],$data['notas'],$data['activo'],$id)
            );
        } else {
            $db->query(
                "INSERT INTO clientes (nombre,apellido,empresa,rfc,email,telefono,direccion,ciudad,estado,cp,limite_credito,notas,activo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                array($data['nombre'],$data['apellido'],$data['empresa'],$data['rfc'],$data['email'],
                      $data['telefono'],$data['direccion'],$data['ciudad'],$data['estado'],$data['cp'],
                      $data['limite_credito'],$data['notas'],$data['activo'])
            );
        }
        header('Location: index.php?ok=1'); exit;
    }
    $formData = $data;
}

$pageTitle = 'Clientes';
require_once __DIR__ . '/../../includes/header.php';
$clientes = $db->fetchAll("SELECT * FROM clientes ORDER BY id DESC");
$formData = isset($formData) ? $formData : array('nombre'=>'','apellido'=>'','empresa'=>'','rfc'=>'','email'=>'','telefono'=>'','direccion'=>'','ciudad'=>'','estado_dir'=>'','cp'=>'','limite_credito'=>0,'notas'=>'','activo'=>1);
?>
<?php if (isset($_GET['ok'])): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle me-2"></i>Cliente guardado correctamente.</div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="page-header">
    <div><h1><i class="bi bi-people me-2 text-primary"></i>Clientes</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Clientes</li>
        </ol></nav>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCliente" onclick="resetForm()">
        <i class="bi bi-plus-circle me-1"></i>Nuevo Cliente
    </button>
</div>

<div class="card"><div class="card-body"><div class="table-responsive">
    <table class="table table-hover" id="tblClientes">
        <thead><tr><th>#</th><th>Nombre</th><th>Empresa</th><th>Email</th><th>Telefono</th><th>Credito</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
            <?php foreach ($clientes as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><strong><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></strong></td>
                <td><?= htmlspecialchars($c['empresa'] ?? '') ?></td>
                <td><?= htmlspecialchars($c['email'] ?? '') ?></td>
                <td><?= htmlspecialchars($c['telefono'] ?? '') ?></td>
                <td>Q <?= number_format($c['limite_credito'], 2) ?></td>
                <td><span class="badge-<?= $c['activo'] ? 'activo' : 'inactivo' ?>"><?= $c['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-outline-warning" onclick="editCliente(<?= htmlspecialchars(json_encode($c)) ?>)"><i class="bi bi-pencil"></i></button>
                    <a href="?action=toggle&id=<?= $c['id'] ?>" class="btn btn-sm <?= $c['activo'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-delete"
                       data-msg="<?= $c['activo'] ? 'Desactivar cliente?' : 'Activar cliente?' ?>">
                        <i class="bi bi-<?= $c['activo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="modalCliente" tabindex="-1">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="POST">
        <input type="hidden" name="id" id="fId">
        <div class="modal-header"><h5 class="modal-title" id="mTitle">Nuevo Cliente</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="row g-3">
            <div class="col-md-6"><label class="form-label">Nombre *</label><input type="text" name="nombre" id="fNombre" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Apellido</label><input type="text" name="apellido" id="fApellido" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Empresa</label><input type="text" name="empresa" id="fEmpresa" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">NIT/RFC</label><input type="text" name="rfc" id="fRfc" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" id="fEmail" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Telefono</label><input type="text" name="telefono" id="fTel" class="form-control"></div>
            <div class="col-12"><label class="form-label">Direccion</label><input type="text" name="direccion" id="fDir" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Ciudad</label><input type="text" name="ciudad" id="fCiudad" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Departamento</label><input type="text" name="estado_dir" id="fEstado" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Cod. Postal</label><input type="text" name="cp" id="fCp" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Limite de Credito (Q)</label><input type="number" name="limite_credito" id="fCredito" class="form-control" value="0" min="0" step="0.01"></div>
            <div class="col-12"><label class="form-label">Notas</label><textarea name="notas" id="fNotas" class="form-control" rows="2"></textarea></div>
            <div class="col-12"><div class="form-check form-switch"><input type="checkbox" name="activo" id="fActivo" class="form-check-input" value="1" checked><label class="form-check-label" for="fActivo">Cliente Activo</label></div></div>
        </div></div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar</button>
        </div>
        </form>
    </div></div>
</div>
<script>
const APP_URL = '<?= APP_URL ?>';
$(document).ready(function() { $('#tblClientes').DataTable({ order: [[0,'desc']] }); });
function resetForm() {
    document.getElementById('fId').value='';
    document.getElementById('mTitle').textContent='Nuevo Cliente';
    ['fNombre','fApellido','fEmpresa','fRfc','fEmail','fTel','fDir','fCiudad','fEstado','fCp','fNotas'].forEach(function(id){ document.getElementById(id).value=''; });
    document.getElementById('fCredito').value='0';
    document.getElementById('fActivo').checked=true;
}
function editCliente(c) {
    document.getElementById('fId').value=c.id;
    document.getElementById('mTitle').textContent='Editar Cliente';
    document.getElementById('fNombre').value=c.nombre||'';
    document.getElementById('fApellido').value=c.apellido||'';
    document.getElementById('fEmpresa').value=c.empresa||'';
    document.getElementById('fRfc').value=c.rfc||'';
    document.getElementById('fEmail').value=c.email||'';
    document.getElementById('fTel').value=c.telefono||'';
    document.getElementById('fDir').value=c.direccion||'';
    document.getElementById('fCiudad').value=c.ciudad||'';
    document.getElementById('fEstado').value=c.estado||'';
    document.getElementById('fCp').value=c.cp||'';
    document.getElementById('fCredito').value=c.limite_credito||'0';
    document.getElementById('fNotas').value=c.notas||'';
    document.getElementById('fActivo').checked=c.activo==1;
    new bootstrap.Modal(document.getElementById('modalCliente')).show();
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

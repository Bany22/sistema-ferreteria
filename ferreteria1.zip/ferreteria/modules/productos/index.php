<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$pageTitle = 'Productos';
require_once __DIR__ . '/../../includes/header.php';

$db = Database::getInstance();

// Handle actions
$msg = $err = '';
if (isset($_GET['action'])) {
    $id = (int)($_GET['id'] ?? 0);
    if ($_GET['action'] === 'toggle' && $id) {
        $p = $db->fetchOne("SELECT activo FROM productos WHERE id=?", [$id]);
        if ($p) {
            $nuevoEstado = $p['activo'] ? 0 : 1;
            $db->query("UPDATE productos SET activo=? WHERE id=?", [$nuevoEstado, $id]);
            $msg = $nuevoEstado ? 'Producto activado.' : 'Producto desactivado.';
        }
    }
}

$productos = $db->fetchAll(
    "SELECT p.*, c.nombre as categoria, pr.nombre as proveedor
     FROM productos p
     LEFT JOIN categorias c ON p.categoria_id = c.id
     LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
     ORDER BY p.id DESC"
);
?>

<?php if ($msg): ?>
<div class="alert alert-success alert-auto-close alert-dismissible">
    <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($msg) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-box-seam me-2 text-primary"></i>Productos</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
                <li class="breadcrumb-item active">Productos</li>
            </ol>
        </nav>
    </div>
    <a href="crear.php" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>Nuevo Producto
    </a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="tblProductos">
                <thead>
                    <tr>
                        <th>#</th><th>Código</th><th>Nombre</th><th>Categoría</th>
                        <th>Precio Costo</th><th>Precio Venta</th><th>Stock</th>
                        <th>Sección</th><th>Estado</th><th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($productos as $p): ?>
                    <tr>
                        <td><?= $p['id'] ?></td>
                        <td><code><?= htmlspecialchars($p['codigo']) ?></code></td>
                        <td>
                            <strong><?= htmlspecialchars($p['nombre']) ?></strong>
                            <?php if ($p['descripcion']): ?>
                            <br><small class="text-muted"><?= htmlspecialchars(substr($p['descripcion'],0,60)) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($p['categoria'] ?? 'Sin categoría') ?></td>
                        <td class="text-money">Q <?= number_format($p['precio_costo'],2) ?></td>
                        <td class="text-money fw-bold text-success">Q <?= number_format($p['precio_venta'],2) ?></td>
                        <td>
                            <?php
                            $stockColor = $p['stock_actual'] <= $p['stock_minimo'] && $p['stock_minimo'] > 0 
                                ? 'stock-low' : 'stock-ok';
                            ?>
                            <span class="<?= $stockColor ?>"><?= number_format($p['stock_actual'],2) ?></span>
                            <small class="text-muted"> <?= htmlspecialchars($p['unidad_medida']) ?></small>
                            <?php if ($p['stock_minimo'] > 0 && $p['stock_actual'] <= $p['stock_minimo']): ?>
                            <br><small class="text-danger"><i class="bi bi-exclamation-triangle"></i> Stock bajo</small>
                            <?php endif; ?>
                        </td>
                        <!-- Columna Sección -->
                        <td class="text-center" style="min-width:90px">
                            <?php if (!empty($p['seccion_letra']) || !empty($p['seccion_numero'])): ?>
                            <div class="d-flex flex-column align-items-center gap-1">
                                <?php if (!empty($p['seccion_letra'])): ?>
                                <span class="badge bg-primary" title="Sección / Letra">
                                    <i class="bi bi-fonts me-1"></i><?= htmlspecialchars($p['seccion_letra']) ?>
                                </span>
                                <?php endif; ?>
                                <?php if (!empty($p['seccion_numero'])): ?>
                                <span class="badge bg-warning text-dark" title="Número / Posición">
                                    <i class="bi bi-hash me-1"></i><?= htmlspecialchars($p['seccion_numero']) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge-<?= $p['activo'] ? 'activo' : 'inactivo' ?>">
                                <?= $p['activo'] ? 'Activo' : 'Inactivo' ?>
                            </span>
                        </td>
                        <td class="table-actions">
                            <a href="editar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="?action=toggle&id=<?= $p['id'] ?>" 
                               class="btn btn-sm <?= $p['activo'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-delete"
                               data-msg="<?= $p['activo'] ? '¿Desactivar este producto?' : '¿Activar este producto?' ?>">
                                <i class="bi bi-<?= $p['activo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const APP_URL = '<?= APP_URL ?>';
$(document).ready(function() {
    $('#tblProductos').DataTable({ order: [[0,'desc']] });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

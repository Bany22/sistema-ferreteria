<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db = Database::getInstance();

$editMode = isset($_GET['id']);
$id = $editMode ? (int)$_GET['id'] : 0;

$producto = array('id'=>'','codigo'=>'','nombre'=>'','descripcion'=>'',
    'tipo_producto'=>'producto','es_kit'=>0,
    'categoria_id'=>'','proveedor_id'=>'',
    'precio_costo'=>'0','precio_venta'=>'0','precio_mayoreo'=>'0',
    'precio1'=>'0','precio2'=>'0','iva_porcentaje'=>5,
    'unidad_medida'=>'PZA','stock_actual'=>0,
    'stock_minimo'=>0,'stock_maximo'=>0,'activo'=>1);

$specs = array('marca_id'=>'','resolucion'=>'','tipo_camara_id'=>'',
    'tiene_audio'=>0,'tiene_altavoz'=>0,'full_color'=>0,'wiz_color'=>0,
    'ir_metros'=>'','tecnologia'=>'','lente_mm'=>'','angulo_vision'=>'',
    'ip_rating'=>'','alimentacion'=>'','compresion'=>'','fps'=>'','extras'=>'');

$kitComponentes = array();

if ($editMode) {
    $found = $db->fetchOne("SELECT * FROM productos WHERE id=?", array($id));
    if ($found) {
        $producto = $found;
        $specRow = $db->fetchOne("SELECT * FROM productos_camara_specs WHERE producto_id=?", array($id));
        if ($specRow) $specs = array_merge($specs, $specRow);
        $kitComponentes = $db->fetchAll(
            "SELECT kc.*, p.nombre AS comp_nombre, p.codigo AS comp_codigo
             FROM kit_componentes kc JOIN productos p ON kc.componente_id = p.id
             WHERE kc.kit_id = ? ORDER BY kc.id", array($id)
        );
    } else { header('Location: index.php'); exit; }
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = array(
        'codigo'        => trim($_POST['codigo'] ?? ''),
        'nombre'        => trim($_POST['nombre'] ?? ''),
        'descripcion'   => trim($_POST['descripcion'] ?? ''),
        'tipo_producto' => $_POST['tipo_producto'] ?? 'producto',
        'es_kit'        => ($_POST['tipo_producto'] ?? '' === 'kit_combo') ? 1 : 0,
        'categoria_id'  => (int)($_POST['categoria_id'] ?? 0) ?: null,
        'proveedor_id'  => (int)($_POST['proveedor_id'] ?? 0) ?: null,
        'precio_costo'  => (float)($_POST['precio_costo'] ?? 0),
        'precio_venta'  => (float)($_POST['precio_venta'] ?? 0),
        'precio_mayoreo'=> (float)($_POST['precio_mayoreo'] ?? 0),
        'precio1'       => (float)($_POST['precio1'] ?? 0),
        'precio2'       => (float)($_POST['precio2'] ?? 0),
        'iva_porcentaje'=> (float)($_POST['iva_porcentaje'] ?? 5),
        'unidad_medida' => trim($_POST['unidad_medida'] ?? 'PZA'),
        'stock_minimo'  => (float)($_POST['stock_minimo'] ?? 0),
        'stock_maximo'  => (float)($_POST['stock_maximo'] ?? 0),
        'activo'         => isset($_POST['activo']) ? 1 : 0,
        'seccion_letra'  => strtoupper(trim($_POST['seccion_letra']  ?? '')),
        'seccion_numero' => strtoupper(trim($_POST['seccion_numero'] ?? '')),
    );
    $data['es_kit'] = ($data['tipo_producto'] === 'kit_combo') ? 1 : 0;
    $stockInicial = $editMode ? 0 : (float)($_POST['stock_inicial'] ?? 0);

    $specData = array(
        'marca_id'      => (int)($_POST['cam_marca_id'] ?? 0) ?: null,
        'resolucion'    => trim($_POST['cam_resolucion'] ?? ''),
        'tipo_camara_id'=> (int)($_POST['cam_tipo_id'] ?? 0) ?: null,
        'tiene_audio'   => isset($_POST['cam_audio']) ? 1 : 0,
        'tiene_altavoz' => isset($_POST['cam_altavoz']) ? 1 : 0,
        'full_color'    => isset($_POST['cam_full_color']) ? 1 : 0,
        'wiz_color'     => isset($_POST['cam_wiz_color']) ? 1 : 0,
        'ir_metros'     => (int)($_POST['cam_ir_metros'] ?? 0) ?: null,
        'tecnologia'    => trim($_POST['cam_tecnologia'] ?? ''),
        'lente_mm'      => (float)($_POST['cam_lente'] ?? 0) ?: null,
        'angulo_vision' => trim($_POST['cam_angulo'] ?? ''),
        'ip_rating'     => trim($_POST['cam_ip_rating'] ?? ''),
        'alimentacion'  => trim($_POST['cam_alimentacion'] ?? ''),
        'compresion'    => trim($_POST['cam_compresion'] ?? ''),
        'fps'           => trim($_POST['cam_fps'] ?? ''),
        'extras'        => trim($_POST['cam_extras'] ?? ''),
    );

    $compIds  = $_POST['comp_id']   ?? array();
    $compCant = $_POST['comp_cant'] ?? array();
    $compNota = $_POST['comp_nota'] ?? array();

    if (empty($data['codigo']) || empty($data['nombre'])) {
        $error = 'Código y nombre son obligatorios.';
    } elseif ($data['precio_venta'] <= 0) {
        $error = 'El precio de venta debe ser mayor a 0.';
    } else {
        $isCamType = in_array($data['tipo_producto'], array('camara','kit_combo','accesorio'));
        if ($editMode) {
            $dup = $db->fetchOne("SELECT id FROM productos WHERE codigo=? AND id!=?", array($data['codigo'], $id));
            if ($dup) { $error = 'Ya existe un producto con ese código.'; }
            else {
                $db->query("UPDATE productos SET codigo=?,nombre=?,descripcion=?,tipo_producto=?,es_kit=?,
                     categoria_id=?,proveedor_id=?,precio_costo=?,precio_venta=?,precio_mayoreo=?,
                     precio1=?,precio2=?,iva_porcentaje=?,unidad_medida=?,stock_minimo=?,stock_maximo=?,
                     seccion_letra=?,seccion_numero=?,activo=?
                     WHERE id=?",
                    array($data['codigo'],$data['nombre'],$data['descripcion'],$data['tipo_producto'],$data['es_kit'],
                          $data['categoria_id'],$data['proveedor_id'],$data['precio_costo'],$data['precio_venta'],
                          $data['precio_mayoreo'],$data['precio1'],$data['precio2'],$data['iva_porcentaje'],
                          $data['unidad_medida'],$data['stock_minimo'],$data['stock_maximo'],
                          $data['seccion_letra'],$data['seccion_numero'],$data['activo'],$id));
                if ($isCamType) {
                    $ex = $db->fetchOne("SELECT id FROM productos_camara_specs WHERE producto_id=?", array($id));
                    if ($ex) {
                        $db->query("UPDATE productos_camara_specs SET marca_id=?,resolucion=?,tipo_camara_id=?,
                            tiene_audio=?,tiene_altavoz=?,full_color=?,wiz_color=?,ir_metros=?,tecnologia=?,
                            lente_mm=?,angulo_vision=?,ip_rating=?,alimentacion=?,compresion=?,fps=?,extras=?
                            WHERE producto_id=?",
                            array($specData['marca_id'],$specData['resolucion'],$specData['tipo_camara_id'],
                                  $specData['tiene_audio'],$specData['tiene_altavoz'],$specData['full_color'],
                                  $specData['wiz_color'],$specData['ir_metros'],$specData['tecnologia'],
                                  $specData['lente_mm'],$specData['angulo_vision'],$specData['ip_rating'],
                                  $specData['alimentacion'],$specData['compresion'],$specData['fps'],
                                  $specData['extras'],$id));
                    } else {
                        $db->query("INSERT INTO productos_camara_specs (producto_id,marca_id,resolucion,tipo_camara_id,
                            tiene_audio,tiene_altavoz,full_color,wiz_color,ir_metros,tecnologia,
                            lente_mm,angulo_vision,ip_rating,alimentacion,compresion,fps,extras)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            array($id,$specData['marca_id'],$specData['resolucion'],$specData['tipo_camara_id'],
                                  $specData['tiene_audio'],$specData['tiene_altavoz'],$specData['full_color'],
                                  $specData['wiz_color'],$specData['ir_metros'],$specData['tecnologia'],
                                  $specData['lente_mm'],$specData['angulo_vision'],$specData['ip_rating'],
                                  $specData['alimentacion'],$specData['compresion'],$specData['fps'],$specData['extras']));
                    }
                }
                if ($data['tipo_producto'] === 'kit_combo') {
                    $db->query("DELETE FROM kit_componentes WHERE kit_id=?", array($id));
                    for ($i=0; $i<count($compIds); $i++) {
                        $cid=(int)$compIds[$i];
                        if ($cid) $db->query("INSERT INTO kit_componentes (kit_id,componente_id,cantidad,notas) VALUES (?,?,?,?)",
                            array($id,$cid,max(1,(int)($compCant[$i]??1)),$compNota[$i]??''));
                    }
                }
                header('Location: index.php?msg=updated'); exit;
            }
        } else {
            $dup = $db->fetchOne("SELECT id FROM productos WHERE codigo=?", array($data['codigo']));
            if ($dup) { $error = 'Ya existe un producto con ese código.'; }
            else {
                $db->query("INSERT INTO productos (codigo,nombre,descripcion,tipo_producto,es_kit,categoria_id,proveedor_id,
                     precio_costo,precio_venta,precio_mayoreo,precio1,precio2,iva_porcentaje,
                     unidad_medida,stock_actual,stock_minimo,stock_maximo,activo)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    array($data['codigo'],$data['nombre'],$data['descripcion'],$data['tipo_producto'],$data['es_kit'],
                          $data['categoria_id'],$data['proveedor_id'],$data['precio_costo'],$data['precio_venta'],
                          $data['precio_mayoreo'],$data['precio1'],$data['precio2'],$data['iva_porcentaje'],
                          $data['unidad_medida'],$stockInicial,$data['stock_minimo'],$data['stock_maximo'],$data['activo']));
                $newId = $db->lastInsertId();
                if ($isCamType) {
                    $db->query("INSERT INTO productos_camara_specs (producto_id,marca_id,resolucion,tipo_camara_id,
                        tiene_audio,tiene_altavoz,full_color,wiz_color,ir_metros,tecnologia,
                        lente_mm,angulo_vision,ip_rating,alimentacion,compresion,fps,extras)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        array($newId,$specData['marca_id'],$specData['resolucion'],$specData['tipo_camara_id'],
                              $specData['tiene_audio'],$specData['tiene_altavoz'],$specData['full_color'],
                              $specData['wiz_color'],$specData['ir_metros'],$specData['tecnologia'],
                              $specData['lente_mm'],$specData['angulo_vision'],$specData['ip_rating'],
                              $specData['alimentacion'],$specData['compresion'],$specData['fps'],$specData['extras']));
                }
                if ($data['tipo_producto'] === 'kit_combo') {
                    for ($i=0; $i<count($compIds); $i++) {
                        $cid=(int)$compIds[$i];
                        if ($cid) $db->query("INSERT INTO kit_componentes (kit_id,componente_id,cantidad,notas) VALUES (?,?,?,?)",
                            array($newId,$cid,max(1,(int)($compCant[$i]??1)),$compNota[$i]??''));
                    }
                }
                header('Location: index.php?msg=created'); exit;
            }
        }
        $producto = array_merge($producto, $data);
    }
}

$pageTitle = $editMode ? 'Editar Producto' : 'Nuevo Producto';
require_once __DIR__ . '/../../includes/header.php';
$categorias   = $db->fetchAll("SELECT id, nombre FROM categorias WHERE activo=1 ORDER BY nombre");
$proveedores  = $db->fetchAll("SELECT id, nombre FROM proveedores WHERE activo=1 ORDER BY nombre");
$marcasCam    = $db->fetchAll("SELECT * FROM camaras_marcas WHERE activo=1 ORDER BY nombre");
$tiposCam     = $db->fetchAll("SELECT * FROM camaras_tipos WHERE activo=1 ORDER BY nombre");
$tecnologias  = $db->fetchAll("SELECT * FROM camaras_tecnologias ORDER BY nombre");
$resoluciones = $db->fetchAll("SELECT * FROM camaras_resoluciones ORDER BY id");
$productosAll = $db->fetchAll("SELECT id, codigo, nombre, tipo_producto FROM productos WHERE activo=1 AND id != ? ORDER BY nombre", array($id));
?>

<?php if ($error): ?>
<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-box-seam me-2 text-primary"></i><?= $pageTitle ?></h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Productos</a></li>
            <li class="breadcrumb-item active"><?= $pageTitle ?></li>
        </ol></nav>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<form method="POST">
<div class="row g-4">
    <div class="col-lg-8">

        <!-- Info General -->
        <div class="card mb-4">
            <div class="card-header">Información del Producto</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Tipo</label>
                        <select name="tipo_producto" id="tipoProd" class="form-select" required>
                            <option value="producto"  <?= $producto['tipo_producto']==='producto' ?'selected':'' ?>>Producto General</option>
                            <option value="camara"    <?= $producto['tipo_producto']==='camara'   ?'selected':'' ?>>📷 Cámara</option>
                            <option value="kit_combo" <?= $producto['tipo_producto']==='kit_combo'?'selected':'' ?>>📦 Kit / Combo</option>
                            <option value="accesorio" <?= $producto['tipo_producto']==='accesorio'?'selected':'' ?>>🔧 Accesorio CCTV</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Código *</label>
                        <input type="text" name="codigo" class="form-control" value="<?= htmlspecialchars($producto['codigo']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Nombre *</label>
                        <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($producto['nombre']) ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Descripción</label>
                        <textarea name="descripcion" class="form-control" rows="2"><?= htmlspecialchars($producto['descripcion']) ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Categoría</label>
                        <select name="categoria_id" class="form-select">
                            <option value="">-- Sin categoría --</option>
                            <?php foreach ($categorias as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= $producto['categoria_id'] == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Proveedor</label>
                        <select name="proveedor_id" class="form-select">
                            <option value="">-- Sin proveedor --</option>
                            <?php foreach ($proveedores as $prov): ?>
                            <option value="<?= $prov['id'] ?>" <?= $producto['proveedor_id'] == $prov['id'] ? 'selected' : '' ?>><?= htmlspecialchars($prov['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- SPECS CÁMARA -->
        <div class="card mb-4" id="cardCamSpecs" style="display:none">
            <div class="card-header bg-primary bg-opacity-10 fw-semibold"><i class="bi bi-camera me-1"></i>Especificaciones Técnicas</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Marca</label>
                        <select name="cam_marca_id" class="form-select">
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($marcasCam as $m): ?>
                            <option value="<?= $m['id'] ?>" <?= $specs['marca_id']==$m['id']?'selected':'' ?>><?= htmlspecialchars($m['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Resolución</label>
                        <select name="cam_resolucion" class="form-select">
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($resoluciones as $r): ?>
                            <option value="<?= htmlspecialchars($r['nombre']) ?>" <?= $specs['resolucion']==$r['nombre']?'selected':'' ?>><?= htmlspecialchars($r['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Tipo</label>
                        <select name="cam_tipo_id" class="form-select">
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($tiposCam as $t): ?>
                            <option value="<?= $t['id'] ?>" <?= $specs['tipo_camara_id']==$t['id']?'selected':'' ?>><?= htmlspecialchars($t['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Tecnología</label>
                        <select name="cam_tecnologia" class="form-select">
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($tecnologias as $t): ?>
                            <option value="<?= htmlspecialchars($t['nombre']) ?>" <?= $specs['tecnologia']==$t['nombre']?'selected':'' ?>><?= htmlspecialchars($t['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Alimentación</label>
                        <select name="cam_alimentacion" class="form-select">
                            <option value="">— N/A —</option>
                            <?php foreach (array('PoE','12VDC','PoE+','24VAC','Batería','USB') as $al): ?>
                            <option value="<?= $al ?>" <?= $specs['alimentacion']==$al?'selected':'' ?>><?= $al ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Compresión</label>
                        <select name="cam_compresion" class="form-select">
                            <option value="">— N/A —</option>
                            <?php foreach (array('H.265+','H.265','H.264+','H.264','MJPEG') as $co): ?>
                            <option value="<?= $co ?>" <?= $specs['compresion']==$co?'selected':'' ?>><?= $co ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">IR (metros)</label>
                        <input type="number" name="cam_ir_metros" class="form-control" value="<?= htmlspecialchars($specs['ir_metros']??'') ?>" min="0" placeholder="ej. 30">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Lente (mm)</label>
                        <input type="number" name="cam_lente" class="form-control" value="<?= htmlspecialchars($specs['lente_mm']??'') ?>" step="0.1" placeholder="ej. 2.8">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Ángulo visión</label>
                        <input type="text" name="cam_angulo" class="form-control" value="<?= htmlspecialchars($specs['angulo_vision']??'') ?>" placeholder="ej. 107°">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Rating IP</label>
                        <select name="cam_ip_rating" class="form-select">
                            <option value="">— N/A —</option>
                            <?php foreach (array('IP67','IP66','IP65','IP68','IK10') as $ip): ?>
                            <option value="<?= $ip ?>" <?= $specs['ip_rating']==$ip?'selected':'' ?>><?= $ip ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">FPS</label>
                        <select name="cam_fps" class="form-select">
                            <option value="">— N/A —</option>
                            <?php foreach (array('15fps','25fps','30fps','60fps') as $f): ?>
                            <option value="<?= $f ?>" <?= $specs['fps']==$f?'selected':'' ?>><?= $f ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label d-block mb-2">Características</label>
                        <div class="d-flex flex-wrap gap-3">
                            <div class="form-check"><input type="checkbox" name="cam_audio" class="form-check-input" id="chkAudio" value="1" <?= $specs['tiene_audio']?'checked':'' ?>><label class="form-check-label" for="chkAudio"><i class="bi bi-mic-fill text-primary me-1"></i>Con Audio</label></div>
                            <div class="form-check"><input type="checkbox" name="cam_altavoz" class="form-check-input" id="chkAltavoz" value="1" <?= $specs['tiene_altavoz']?'checked':'' ?>><label class="form-check-label" for="chkAltavoz"><i class="bi bi-speaker-fill text-primary me-1"></i>Altavoz</label></div>
                            <div class="form-check"><input type="checkbox" name="cam_full_color" class="form-check-input" id="chkFullColor" value="1" <?= $specs['full_color']?'checked':'' ?>><label class="form-check-label" for="chkFullColor"><i class="bi bi-palette-fill text-warning me-1"></i>Full Color</label></div>
                            <div class="form-check"><input type="checkbox" name="cam_wiz_color" class="form-check-input" id="chkWizColor" value="1" <?= $specs['wiz_color']?'checked':'' ?>><label class="form-check-label" for="chkWizColor"><i class="bi bi-stars text-warning me-1"></i>Wiz Color</label></div>
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Extras / Otras características</label>
                        <input type="text" name="cam_extras" class="form-control" value="<?= htmlspecialchars($specs['extras']??'') ?>" placeholder="Detección IA, Alarma sonora, Strobo, Slot SD, PTZ...">
                    </div>
                </div>
            </div>
        </div>

        <!-- KIT COMPONENTES -->
        <div class="card mb-4" id="cardKitComps" style="display:none">
            <div class="card-header d-flex justify-content-between align-items-center bg-warning bg-opacity-10 fw-semibold">
                <span><i class="bi bi-boxes me-1"></i>Contenido del Kit / Combo</span>
                <button type="button" class="btn btn-sm btn-warning" id="btnAddComp"><i class="bi bi-plus-circle me-1"></i>Agregar</button>
            </div>
            <div class="card-body p-0">
                <table class="table table-sm align-middle mb-0">
                    <thead class="table-light"><tr><th>Producto</th><th style="width:80px">Cant.</th><th style="width:160px">Nota</th><th style="width:40px"></th></tr></thead>
                    <tbody id="tbodyKitComps">
                    <?php foreach ($kitComponentes as $kc): ?>
                    <tr class="compRow">
                        <td><select name="comp_id[]" class="form-select form-select-sm" required>
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($productosAll as $pa): ?>
                            <option value="<?= $pa['id'] ?>" <?= $kc['componente_id']==$pa['id']?'selected':'' ?>><?= htmlspecialchars($pa['codigo'].' — '.$pa['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select></td>
                        <td><input type="number" name="comp_cant[]" class="form-control form-control-sm" value="<?= $kc['cantidad'] ?>" min="1"></td>
                        <td><input type="text" name="comp_nota[]" class="form-control form-control-sm" value="<?= htmlspecialchars($kc['notas']??'') ?>"></td>
                        <td><button type="button" class="btn btn-sm btn-outline-danger btnDelComp"><i class="bi bi-trash"></i></button></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- PRECIOS -->
        <div class="card mb-4">
            <div class="card-header"><i class="bi bi-currency-dollar me-2"></i>Precios (Q)</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4"><label class="form-label">Precio Costo</label>
                        <div class="input-group"><span class="input-group-text">Q</span>
                        <input type="number" name="precio_costo" id="pCosto" class="form-control" value="<?= $producto['precio_costo'] ?>" min="0" step="0.01"></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">Precio Venta *</label>
                        <div class="input-group"><span class="input-group-text">Q</span>
                        <input type="number" name="precio_venta" id="pVenta" class="form-control" value="<?= $producto['precio_venta'] ?>" min="0.01" step="0.01" required></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">Precio Mayoreo</label>
                        <div class="input-group"><span class="input-group-text">Q</span>
                        <input type="number" name="precio_mayoreo" class="form-control" value="<?= $producto['precio_mayoreo'] ?>" min="0" step="0.01"></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">Precio Especial 1</label>
                        <div class="input-group"><span class="input-group-text">Q</span>
                        <input type="number" name="precio1" class="form-control" value="<?= $producto['precio1']??0 ?>" min="0" step="0.01"></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">Precio Especial 2</label>
                        <div class="input-group"><span class="input-group-text">Q</span>
                        <input type="number" name="precio2" class="form-control" value="<?= $producto['precio2']??0 ?>" min="0" step="0.01"></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">IVA (%)</label>
                        <div class="input-group">
                        <input type="number" name="iva_porcentaje" class="form-control" value="<?= $producto['iva_porcentaje'] ?>" min="0" max="100" step="0.01">
                        <span class="input-group-text">%</span></div>
                    </div>
                    <div class="col-md-4"><label class="form-label">Utilidad</label>
                        <div class="input-group">
                        <input type="text" id="utilidadDisplay" class="form-control" readonly style="background:#f8fafc">
                        <span class="input-group-text" id="utilidadPct">0%</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Columna derecha -->
    <div class="col-lg-4">
        <div class="card mb-4">
            <div class="card-header">Inventario</div>
            <div class="card-body">
                <div class="mb-3"><label class="form-label">Unidad de Medida</label>
                    <select name="unidad_medida" class="form-select">
                        <?php foreach (array('PZA','KIT','UND','KG','LT','MT','CM','PAQ','CAJA','ROLLO') as $u): ?>
                        <option value="<?= $u ?>" <?= $producto['unidad_medida']==$u?'selected':'' ?>><?= $u ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if (!$editMode): ?>
                <div class="mb-3"><label class="form-label">Stock Inicial</label>
                    <input type="number" name="stock_inicial" class="form-control" value="0" min="0" step="1">
                    <small class="text-muted">Cantidad inicial en inventario</small>
                </div>
                <?php endif; ?>
                <div class="mb-3"><label class="form-label">Stock Mínimo</label>
                    <input type="number" name="stock_minimo" class="form-control" value="<?= $producto['stock_minimo'] ?>" min="0">
                </div>
                <div class="mb-3"><label class="form-label">Stock Máximo</label>
                    <input type="number" name="stock_maximo" class="form-control" value="<?= $producto['stock_maximo'] ?>" min="0">
                </div>
                <!-- SECCIÓN / UBICACIÓN -->
                <div class="card mb-3 border">
                    <div class="card-header py-2 small fw-semibold"><i class="bi bi-geo-alt me-1 text-info"></i>Sección / Ubicación</div>
                    <div class="card-body pb-2">
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <label class="form-label small fw-semibold text-uppercase text-muted" style="font-size:.7rem;letter-spacing:.05em">
                                    <i class="bi bi-fonts text-info"></i> Letra
                                </label>
                                <select name="seccion_letra" class="form-select form-select-sm">
                                    <option value="">— Sin asignar —</option>
                                    <?php foreach (range('A','Z') as $letra): ?>
                                    <option value="<?= $letra ?>" <?= ($producto['seccion_letra'] ?? '') === $letra ? 'selected' : '' ?>>
                                        Sección <?= $letra ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted">Pasillo / zona</small>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-semibold text-uppercase text-muted" style="font-size:.7rem;letter-spacing:.05em">
                                    <i class="bi bi-sort-numeric-up text-warning"></i> Número
                                </label>
                                <input type="text"
                                       name="seccion_numero"
                                       class="form-control form-control-sm text-uppercase"
                                       value="<?= htmlspecialchars($producto['seccion_numero'] ?? '') ?>"
                                       placeholder="Ej: 1, E3, B-2"
                                       maxlength="10"
                                       style="letter-spacing:.05em">
                                <small class="text-muted">Estante / posición</small>
                            </div>
                        </div>
                        <?php if (!empty($producto['seccion_letra']) || !empty($producto['seccion_numero'])): ?>
                        <div class="d-flex gap-1 flex-wrap mb-1">
                            <?php if (!empty($producto['seccion_letra'])): ?>
                            <span class="badge bg-primary">Sección <?= htmlspecialchars($producto['seccion_letra']) ?></span>
                            <?php endif; ?>
                            <?php if (!empty($producto['seccion_numero'])): ?>
                            <span class="badge bg-warning text-dark">Pos. <?= htmlspecialchars($producto['seccion_numero']) ?></span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-check form-switch mb-3">
                    <input type="checkbox" name="activo" class="form-check-input" id="chkActivo" <?= $producto['activo']?'checked':'' ?> value="1" role="switch">
                    <label class="form-check-label" for="chkActivo">Producto Activo</label>
                </div>
            </div>
        </div>
        <!-- Badge preview -->
        <div class="card mb-4" id="cardBadgePreview" style="display:none">
            <div class="card-header fw-semibold small">Vista Previa de Etiquetas</div>
            <div class="card-body"><div id="badgePreview" class="text-muted small">—</div></div>
        </div>
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg"><i class="bi bi-save me-2"></i><?= $editMode ? 'Guardar Cambios' : 'Crear Producto' ?></button>
            <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </div>
</div>
</form>

<template id="tplComp">
<tr class="compRow">
    <td><select name="comp_id[]" class="form-select form-select-sm" required>
        <option value="">— Seleccionar producto —</option>
        <?php foreach ($productosAll as $pa): ?>
        <option value="<?= $pa['id'] ?>"><?= htmlspecialchars($pa['codigo'].' — '.$pa['nombre']) ?></option>
        <?php endforeach; ?>
    </select></td>
    <td><input type="number" name="comp_cant[]" class="form-control form-control-sm" value="1" min="1"></td>
    <td><input type="text" name="comp_nota[]" class="form-control form-control-sm" placeholder="Nota..."></td>
    <td><button type="button" class="btn btn-sm btn-outline-danger btnDelComp"><i class="bi bi-trash"></i></button></td>
</tr>
</template>

<script>
$(document).ready(function(){
    function toggleSections(){
        const tipo = document.getElementById('tipoProd').value;
        const isCam = ['camara','kit_combo','accesorio'].includes(tipo);
        const isKit = tipo==='kit_combo';
        document.getElementById('cardCamSpecs').style.display    = isCam?'':'none';
        document.getElementById('cardBadgePreview').style.display= isCam?'':'none';
        document.getElementById('cardKitComps').style.display    = isKit?'':'none';
    }
    document.getElementById('tipoProd').addEventListener('change', toggleSections);
    toggleSections();

    function calcUtilidad(){
        var c=parseFloat(document.getElementById('pCosto').value)||0;
        var v=parseFloat(document.getElementById('pVenta').value)||0;
        var u=v-c, p=c>0?(u/c*100).toFixed(1):'0.0';
        document.getElementById('utilidadDisplay').value='Q '+u.toFixed(2);
        document.getElementById('utilidadPct').textContent=p+'%';
        document.getElementById('utilidadPct').style.color=u>=0?'#16a34a':'#dc2626';
    }
    document.getElementById('pCosto').addEventListener('input',calcUtilidad);
    document.getElementById('pVenta').addEventListener('input',calcUtilidad);
    calcUtilidad();

    document.getElementById('btnAddComp').addEventListener('click',function(){
        document.getElementById('tbodyKitComps').appendChild(document.getElementById('tplComp').content.cloneNode(true));
    });
    $(document).on('click','.btnDelComp',function(){ $(this).closest('tr').remove(); });

    function updateBadges(){
        const marca  = $('[name=cam_marca_id] option:selected').text().trim();
        const resol  = $('[name=cam_resolucion]').val();
        const tec    = $('[name=cam_tecnologia]').val();
        const alim   = $('[name=cam_alimentacion]').val();
        const audio  = $('#chkAudio').is(':checked');
        const alt    = $('#chkAltavoz').is(':checked');
        const fc     = $('#chkFullColor').is(':checked');
        const wc     = $('#chkWizColor').is(':checked');
        const ir     = $('[name=cam_ir_metros]').val();
        let h='';
        if(marca&&marca!=='— Seleccionar —') h+=`<span class="badge bg-primary me-1 mb-1">${marca}</span>`;
        if(resol) h+=`<span class="badge bg-info text-dark me-1 mb-1">${resol}</span>`;
        if(tec)   h+=`<span class="badge bg-secondary me-1 mb-1">${tec}</span>`;
        if(alim)  h+=`<span class="badge bg-dark me-1 mb-1">${alim}</span>`;
        if(audio) h+=`<span class="badge bg-success me-1 mb-1">🎤 Audio</span>`;
        if(alt)   h+=`<span class="badge bg-success me-1 mb-1">🔊 Altavoz</span>`;
        if(fc)    h+=`<span class="badge bg-warning text-dark me-1 mb-1">Full Color</span>`;
        if(wc)    h+=`<span class="badge bg-warning text-dark me-1 mb-1">Wiz Color</span>`;
        if(ir)    h+=`<span class="badge bg-dark me-1 mb-1">IR ${ir}m</span>`;
        document.getElementById('badgePreview').innerHTML=h||'<span class="text-muted small">Complete las especificaciones...</span>';
    }
    $('select[name^="cam_"],input[name^="cam_"]').on('change input',updateBadges);
    $('[id^="chk"]').on('change',updateBadges);
    updateBadges();
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

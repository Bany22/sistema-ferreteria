<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// Cancelar venta y revertir stock
if (isset($_GET['action']) && $_GET['action'] === 'cancelar') {
    $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    $v  = $db->fetchOne('SELECT * FROM ventas WHERE id = ? AND activo = 1', array($id));
    if ($v && $v['estado'] !== 'cancelada') {
        try {
            $db->query("UPDATE ventas SET estado = 'cancelada' WHERE id = ?", array($id));
            $dets = $db->fetchAll('SELECT * FROM ventas_detalle WHERE venta_id = ? AND activo = 1', array($id));
            foreach ($dets as $d) {
                $prod  = $db->fetchOne('SELECT stock_actual FROM productos WHERE id = ?', array($d['producto_id']));
                $antes = (float)$prod['stock_actual'];
                $nuevo = $antes + (float)$d['cantidad'];
                $db->query('UPDATE productos SET stock_actual = ? WHERE id = ?', array($nuevo, $d['producto_id']));
                $db->query(
                    'INSERT INTO inventario_movimientos
                     (producto_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, usuario_id, notas)
                     VALUES (?,?,?,?,?,?,?,?,?)',
                    array($d['producto_id'], 'devolucion', $d['cantidad'], $antes, $nuevo,
                          'venta', $id, $_SESSION['user_id'], 'Cancelación venta '.$v['folio'])
                );
            }
            $msg = 'Venta cancelada y stock revertido.';
        } catch (Exception $e) { $err = $e->getMessage(); }
    }
}

$pageTitle = 'Historial de Ventas';
require_once __DIR__ . '/../../includes/header.php';

$ventas = $db->fetchAll(
    'SELECT v.*, CONCAT(c.nombre," ",c.apellido) AS cliente,
            CONCAT(u.nombre," ",u.apellido) AS vendedor,
            (v.total - COALESCE(v.monto_pagado,0)) AS saldo_pendiente
     FROM ventas v
     JOIN clientes c ON v.cliente_id = c.id
     JOIN usuarios u ON v.usuario_id = u.id
     WHERE v.activo = 1
     ORDER BY v.id DESC'
);
?>

<?php if ($msg): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-cart3 me-2 text-primary"></i>Historial de Ventas</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Ventas</li>
        </ol></nav>
    </div>
    <a href="crear.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Nueva Venta</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="tblVentas">
                <thead class="table-dark">
                    <tr>
                        <th>#</th><th>Folio</th><th>Cliente</th><th>Vendedor</th><th>Fecha</th>
                        <th class="text-end">Subtotal</th><th class="text-end">IVA 5%</th>
                        <th class="text-end">Total Q</th><th class="text-end">Saldo Q</th><th>Pago</th><th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ventas as $v): ?>
                    <tr>
                        <td><?= $v['id'] ?></td>
                        <td><code class="fw-bold"><?= htmlspecialchars($v['folio']) ?></code></td>
                        <td><?= htmlspecialchars($v['cliente']) ?></td>
                        <td><?= htmlspecialchars($v['vendedor']) ?></td>
                        <td><?= date('d/m/Y', strtotime($v['fecha'])) ?></td>
                        <td class="text-end">Q <?= number_format($v['subtotal'],2) ?></td>
                        <td class="text-end">Q <?= number_format($v['iva'],2) ?></td>
                        <td class="text-end fw-bold text-success">Q <?= number_format($v['total'],2) ?></td>
                        <td class="text-end">
                            <?php if ($v['estado'] === 'pagada'): ?>
                                <span class="text-success small">—</span>
                            <?php else: ?>
                                <strong class="text-danger">Q <?= number_format($v['saldo_pendiente'],2) ?></strong>
                            <?php endif; ?>
                        </td>
                        <td><span class="text-capitalize"><?= htmlspecialchars($v['tipo_pago']) ?></span></td>
                        <td><span class="badge-<?= $v['estado'] ?>"><?= ucfirst($v['estado']) ?></span></td>
                        <td class="text-center table-actions">
                            <a href="pdf.php?id=<?= $v['id'] ?>" target="_blank"
                               class="btn btn-sm btn-danger" title="Ver / Imprimir PDF">
                                <i class="bi bi-file-pdf-fill"></i>
                            </a>
                            <?php if (in_array($v['estado'], ['pendiente','parcial'])): ?>
                            <a href="<?= APP_URL ?>/modules/pagos/index.php"
                               class="btn btn-sm btn-success" title="Registrar Pago">
                                <i class="bi bi-cash"></i>
                            </a>
                            <?php endif; ?>
                            <?php if ($v['estado'] !== 'cancelada'): ?>
                            <a href="?action=cancelar&id=<?= $v['id'] ?>"
                               class="btn btn-sm btn-outline-warning btn-delete"
                               data-msg="¿Cancelar esta venta? El stock será revertido.">
                                <i class="bi bi-x-circle"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
var APP_URL = '<?= APP_URL ?>';
$(document).ready(function () { $('#tblVentas').DataTable({ order: [[0,'desc']] }); });
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

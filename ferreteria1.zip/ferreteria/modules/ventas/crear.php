<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db      = Database::getInstance();
$IVA_PCT = 0.0;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clienteId  = (int)(isset($_POST['cliente_id'])  ? $_POST['cliente_id']  : 0);
    $fecha      = isset($_POST['fecha'])     ? $_POST['fecha']     : date('Y-m-d');
    $tipoPago   = isset($_POST['tipo_pago']) ? $_POST['tipo_pago'] : 'contado';
    $estado     = isset($_POST['estado'])    ? $_POST['estado']    : 'pagada';
    $notas      = trim(isset($_POST['notas']) ? $_POST['notas'] : '');
    $descGlobal = (float)(isset($_POST['descuento']) ? $_POST['descuento'] : 0);
    $productos  = isset($_POST['productos'])  ? $_POST['productos']  : array();
    $cantidades = isset($_POST['cantidades']) ? $_POST['cantidades'] : array();
    $precios    = isset($_POST['precios'])    ? $_POST['precios']    : array();
    $descuentos = isset($_POST['descuentos']) ? $_POST['descuentos'] : array();
    $subtotales = isset($_POST['subtotales']) ? $_POST['subtotales'] : array();

    if (!$clienteId || empty($productos)) {
        $error = 'Debe seleccionar un cliente y agregar al menos un producto.';
    } else {
        $errStock = '';
        foreach ($productos as $i => $prodId) {
            $qty = (float)(isset($cantidades[$i]) ? $cantidades[$i] : 0);
            if ($qty <= 0) continue;
            $prod = $db->fetchOne('SELECT nombre, stock_actual FROM productos WHERE id=? AND activo=1', array((int)$prodId));
            if (!$prod) { $errStock = 'Producto ID '.(int)$prodId.' no encontrado.'; break; }
            if ((float)$prod['stock_actual'] < $qty) {
                $errStock = 'Stock insuficiente para "'.$prod['nombre'].'" — disponible: '.number_format($prod['stock_actual'],2).', solicitado: '.number_format($qty,2);
                break;
            }
        }
        if ($errStock) {
            $error = $errStock;
        } else {
            $subtotal = 0;
            foreach ($subtotales as $s) $subtotal += (float)$s;
            $base  = max(0, $subtotal - $descGlobal);
            $iva   = round($base * $IVA_PCT / 100, 2);
            $total = $base + $iva;
            $folio = generarFolio(getSetting('folio_venta_prefijo') ?: 'VTA', 'venta');
            $db->beginTransaction();
            try {
                $db->query(
                    'INSERT INTO ventas (folio,cliente_id,usuario_id,fecha,subtotal,descuento,iva,total,tipo_pago,estado,notas) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                    array($folio,$clienteId,$_SESSION['user_id'],$fecha,$subtotal,$descGlobal,$iva,$total,$tipoPago,$estado,$notas)
                );
                $ventaId = $db->lastInsertId();
                foreach ($productos as $i => $prodId) {
                    $prodId = (int)$prodId;
                    $qty    = (float)(isset($cantidades[$i]) ? $cantidades[$i] : 0);
                    $precio = (float)(isset($precios[$i])    ? $precios[$i]    : 0);
                    $desc   = (float)(isset($descuentos[$i]) ? $descuentos[$i] : 0);
                    $sub    = (float)(isset($subtotales[$i]) ? $subtotales[$i] : 0);
                    if ($qty <= 0 || !$prodId) continue;
                    $db->query('INSERT INTO ventas_detalle (venta_id,producto_id,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?)',
                        array($ventaId,$prodId,$qty,$precio,$desc,$sub));
                    $prod     = $db->fetchOne('SELECT stock_actual FROM productos WHERE id=?', array($prodId));
                    $anterior = (float)$prod['stock_actual'];
                    $nuevo    = $anterior - $qty;
                    $db->query('UPDATE productos SET stock_actual=? WHERE id=?', array($nuevo,$prodId));
                    $db->query('INSERT INTO inventario_movimientos (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,referencia_id,usuario_id,notas) VALUES (?,?,?,?,?,?,?,?,?)',
                        array($prodId,'salida',$qty,$anterior,$nuevo,'venta',$ventaId,$_SESSION['user_id'],'Venta '.$folio));
                }
                $db->commit();
                header('Location: pdf.php?id='.$ventaId.'&new=1');
                exit;
            } catch (Exception $e) {
                $db->rollback();
                $error = 'Error al guardar la venta: '.$e->getMessage();
            }
        }
    }
}

$pageTitle = 'Nueva Venta';
// El JS de búsqueda se inyecta DESPUÉS de app.js via $extraJs
$APP_URL_JS = APP_URL;
$IVA_JS     = $IVA_PCT / 100;
ob_start();
?>
<script>
/* ── Nueva Venta: búsqueda y gestión de productos ── */
(function($){
    var APP_URL  = '<?= $APP_URL_JS ?>';
    var TAX_RATE = <?= $IVA_JS ?>;
    var cache    = {};   // almacén de objetos producto por id

    $(document).ready(function(){
        SalesForm.init(TAX_RATE);
        if ($.fn.select2) $('.select2').select2({ width:'100%', placeholder:'— Seleccionar —' });

        /* Buscador */
        var timer;
        $('#buscarProducto').on('input', function(){
            clearTimeout(timer);
            var q = $(this).val().trim();
            $('#resultadosBusqueda').empty();
            if (q.length < 2) return;
            timer = setTimeout(function(){
                $.ajax({
                    url:      APP_URL + '/api/productos.php',
                    data:     { q: q },
                    dataType: 'json',
                    success:  function(res){ renderResultados(res, q); },
                    error:    function(){ $('#resultadosBusqueda').html('<div class="alert alert-danger py-2 mt-1">Error al conectar con el servidor.</div>'); }
                });
            }, 300);
        });

        /* Clic en resultado */
        $(document).on('click', '.btn-agregar-venta', function(){
            var pid = parseInt($(this).data('pid'));
            var p   = cache[pid];
            if (!p) return;
            agregarProductoVenta(p);
            $('#buscarProducto').val('').focus();
            $('#resultadosBusqueda').empty();
        });

        /* Cambio de selector de precio */
        $(document).on('change', '.price-selector', function(){
            var row = $(this).closest('tr');
            var val = parseFloat($(this).val()) || 0;
            row.find('.item-precio').val(val.toFixed(2));
            recalcRow(row);
            SalesForm.updateTotals();
        });

        /* Cambio en cantidad/precio/descuento */
        $(document).on('input change', '.item-cantidad, .item-precio, .item-descuento', function(){
            recalcRow($(this).closest('tr'));
            SalesForm.updateTotals();
        });

        /* Quitar producto */
        $(document).on('click', '.remove-item', function(){
            $(this).closest('tr').remove();
            renumber();
            SalesForm.updateTotals();
            if ($('#items-tbody tr:not(#empty-row)').length === 0) $('#empty-row').show();
            refreshUI();
        });

        $('#desc-global').on('input', function(){ SalesForm.updateTotals(); });
    });

    function renderResultados(res, q) {
        if (!res || !res.length) {
            $('#resultadosBusqueda').html(
                '<div class="list-group mt-1"><div class="list-group-item text-muted">' +
                'Sin resultados para: <strong>' + esc(q) + '</strong></div></div>'
            );
            return;
        }
        var html = '<div class="list-group shadow-sm mt-1">';
        $.each(res, function(i, p){
            cache[p.id] = p;
            var sinStock = parseFloat(p.stock_actual) <= 0;
            var scol     = sinStock ? 'text-danger' : 'text-success';
            html +=
                '<div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2' +
                (sinStock ? ' list-group-item-warning' : '') + '">' +
                '<div>' +
                '<strong>' + esc(p.nombre) + '</strong>' +
                (sinStock ? ' <span class="badge bg-warning text-dark">Sin stock</span>' : '') +
                '<br><code class="text-muted small">' + esc(p.codigo) + '</code>' +
                '</div>' +
                '<div class="text-end ms-3">' +
                '<div class="fw-bold text-success">Q ' + flt(p.precio_venta) + '</div>' +
                '<div class="' + scol + ' small">Stock: ' + p.stock_actual + '</div>' +
                '<button type="button" class="btn btn-sm btn-primary mt-1 btn-agregar-venta" data-pid="' + p.id + '">' +
                '<i class="bi bi-plus-lg me-1"></i>Agregar</button>' +
                '</div></div>';
        });
        html += '</div>';
        $('#resultadosBusqueda').html(html);
    }

    function agregarProductoVenta(p) {
        var pid = parseInt(p.id);
        if ($('tr[data-pid="' + pid + '"]').length) {
            var qi = $('tr[data-pid="' + pid + '"] .item-cantidad');
            qi.val((parseFloat(qi.val())||0) + 1).trigger('input');
            return;
        }
        var num = $('#items-tbody tr:not(#empty-row)').length + 1;
        var pv  = parseFloat(p.precio_venta)   || 0;
        var pm  = parseFloat(p.precio_mayoreo) || 0;
        var p1  = parseFloat(p.precio1)        || 0;
        var p2  = parseFloat(p.precio2)        || 0;
        var stk = parseFloat(p.stock_actual)   || 0;

        var opts = '<option value="' + pv.toFixed(2) + '">Precio Venta — Q ' + flt(p.precio_venta) + '</option>';
        if (pm > 0) opts += '<option value="' + pm.toFixed(2) + '">Mayoreo — Q ' + flt(p.precio_mayoreo) + '</option>';
        if (p1 > 0) opts += '<option value="' + p1.toFixed(2) + '">Precio 1 — Q ' + flt(p.precio1) + '</option>';
        if (p2 > 0) opts += '<option value="' + p2.toFixed(2) + '">Precio 2 — Q ' + flt(p.precio2) + '</option>';

        var sc  = stk > 0 ? 'text-success' : 'text-danger';
        var row =
            '<tr data-pid="' + pid + '">' +
            '<td class="text-center">' + num + '</td>' +
            '<td><input type="hidden" name="productos[]" value="' + pid + '">' +
            '<strong>' + esc(p.nombre) + '</strong>' +
            '<br><small class="text-muted">' + esc(p.codigo) + '</small>' +
            ' <small class="' + sc + '">Stock: ' + stk + '</small></td>' +
            '<td><input type="number" name="cantidades[]" class="form-control form-control-sm item-cantidad" value="1" min="0.01" step="0.01" style="width:80px"></td>' +
            '<td>' +
            '<select class="form-select form-select-sm price-selector mb-1">' + opts + '</select>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="precios[]" class="form-control item-precio" value="' + pv.toFixed(2) + '" min="0" step="0.01"></div>' +
            '</td>' +
            '<td><div class="input-group input-group-sm" style="width:110px"><span class="input-group-text">Q</span>' +
            '<input type="number" name="descuentos[]" class="form-control item-descuento" value="0" min="0" step="0.01"></div></td>' +
            '<td class="text-end"><strong class="item-subtotal-display">' + moneda(pv) + '</strong>' +
            '<input type="hidden" name="subtotales[]" class="item-subtotal" value="' + pv.toFixed(2) + '"></td>' +
            '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger remove-item"><i class="bi bi-trash"></i></button></td>' +
            '</tr>';

        $('#items-tbody').append(row);
        $('#empty-row').hide();
        SalesForm.updateTotals();
        refreshUI();
    }

    function recalcRow(row) {
        var qty  = parseFloat(row.find('.item-cantidad').val())  || 0;
        var prc  = parseFloat(row.find('.item-precio').val())    || 0;
        var disc = parseFloat(row.find('.item-descuento').val()) || 0;
        var sub  = Math.max(0, qty * prc - disc);
        row.find('.item-subtotal').val(sub.toFixed(2));
        row.find('.item-subtotal-display').text(moneda(sub));
    }

    function refreshUI() {
        var n = $('#items-tbody tr:not(#empty-row)').length;
        $('#badge-items').text(n);
        $('#btnGuardar').prop('disabled', n === 0);
    }

    function renumber() {
        $('#items-tbody tr:not(#empty-row)').each(function(i){ $(this).find('td:first').text(i+1); });
    }

    function moneda(v) {
        var n = parseFloat(v) || 0;
        return 'Q ' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    function flt(v) { return (parseFloat(v)||0).toFixed(2); }

    function esc(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                        .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    }

})(jQuery);
</script>
<?php
$extraJs = ob_get_clean();
require_once __DIR__ . '/../../includes/header.php';
$clientes = $db->fetchAll(
    "SELECT id, CONCAT(nombre,' ',apellido, IF(empresa IS NOT NULL AND empresa != '',CONCAT(' — ',empresa),'')) AS nombre
     FROM clientes WHERE activo=1 ORDER BY nombre"
);
?>

<?php if ($error): ?>
<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-cart-plus me-2 text-primary"></i>Nueva Venta</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Ventas</a></li>
            <li class="breadcrumb-item active">Nueva</li>
        </ol></nav>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<form method="POST" id="ventaForm">
<div class="row g-4">

    <div class="col-xl-8">

        <div class="card mb-3">
            <div class="card-header fw-semibold"><i class="bi bi-person me-2 text-primary"></i>Datos de la Venta</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Cliente <span class="text-danger">*</span></label>
                        <select name="cliente_id" class="form-select select2" required>
                            <option value="">— Seleccionar Cliente —</option>
                            <?php foreach ($clientes as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Fecha</label>
                        <input type="date" name="fecha" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Estado</label>
                        <select name="estado" class="form-select">
                            <option value="pagada">Pagada</option>
                            <option value="pendiente">Pendiente</option>
                            <option value="parcial">Pago Parcial</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Forma de Pago</label>
                        <select name="tipo_pago" class="form-select">
                            <option value="contado">Contado</option>
                            <option value="credito">Crédito</option>
                            <option value="transferencia">Transferencia</option>
                            <option value="tarjeta">Tarjeta</option>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Notas</label>
                        <input type="text" name="notas" class="form-control" placeholder="Observaciones opcionales...">
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold"><i class="bi bi-search me-2 text-primary"></i>Buscar Producto</div>
            <div class="card-body">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" id="buscarProducto" class="form-control"
                           placeholder="Escriba nombre o código del producto...">
                </div>
                <div id="resultadosBusqueda"></div>
                <small class="text-muted d-block mt-1">
                    <i class="bi bi-lightbulb text-warning me-1"></i>
                    Puede elegir entre <strong>Precio Venta, Mayoreo, Precio 1</strong> o <strong>Precio 2</strong> por producto.
                </small>
            </div>
        </div>

        <div class="card">
            <div class="card-header fw-semibold d-flex align-items-center">
                <i class="bi bi-cart3 me-2 text-primary"></i>Productos en la Venta
                <span class="badge bg-secondary ms-auto" id="badge-items">0</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="text-center" style="width:34px">#</th>
                                <th>Producto</th>
                                <th style="width:88px">Cant.</th>
                                <th style="width:230px">Precio Q</th>
                                <th style="width:118px">Descuento</th>
                                <th class="text-end" style="width:115px">Subtotal</th>
                                <th style="width:38px"></th>
                            </tr>
                        </thead>
                        <tbody id="items-tbody">
                            <tr id="empty-row">
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-cart3 d-block fs-1 mb-2 opacity-25"></i>
                                    Busque productos arriba para agregarlos
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="col-xl-4">
        <div class="card position-sticky" style="top:70px">
            <div class="card-header fw-semibold"><i class="bi bi-receipt me-2 text-primary"></i>Resumen de Venta</div>
            <div class="card-body">
                <div class="totals-section">
                    <div class="totals-row"><span>Subtotal</span><span id="display-subtotal">Q 0.00</span></div>
                    <div class="totals-row">
                        <span>Descuento Global</span>
                        <div class="input-group input-group-sm" style="width:130px">
                            <span class="input-group-text">Q</span>
                            <input type="number" id="desc-global" name="descuento" class="form-control text-end" value="0" min="0" step="0.01">
                        </div>
                    </div>
                    <div class="totals-row" style="display:none"><span>IVA (<?= $IVA_PCT ?>%)</span><span id="display-iva">Q 0.00</span></div>
                    <div class="totals-row total"><span class="fw-bold">TOTAL</span><span id="display-total" class="fw-bold text-success">Q 0.00</span></div>
                </div>
                <input type="hidden" id="input-subtotal"  name="subtotal_calc" value="0">
                <input type="hidden" id="input-iva"       name="iva_calc"      value="0">
                <input type="hidden" id="input-total"     name="total_calc"    value="0">
                <input type="hidden" id="input-descuento" name="desc_calc"     value="0">
                <div class="d-grid gap-2 mt-3">
                    <button type="submit" id="btnGuardar" class="btn btn-success btn-lg" disabled>
                        <i class="bi bi-printer me-2"></i>Guardar y Generar Comprobante
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
                </div>
                <div class="alert alert-info mt-3 mb-0 p-2 small">
                    <i class="bi bi-file-pdf me-1"></i>
                    El comprobante PDF se genera automáticamente y queda en el historial.
                </div>
            </div>
        </div>
    </div>

</div>
</form>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

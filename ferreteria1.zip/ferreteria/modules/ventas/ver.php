<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db  = Database::getInstance();
$id  = (int)($_GET['id'] ?? 0);

$venta = $db->fetchOne(
    "SELECT v.*, CONCAT(c.nombre,' ',c.apellido) as cliente_nombre, c.empresa, c.rfc as cliente_rfc,
            c.email as cliente_email, c.telefono as cliente_tel, c.direccion as cliente_dir,
            CONCAT(u.nombre,' ',u.apellido) as vendedor
     FROM ventas v
     JOIN clientes c ON v.cliente_id=c.id
     JOIN usuarios u ON v.usuario_id=u.id
     WHERE v.id=? AND v.activo=1", array($id)
);
if (!$venta) { header('Location: index.php'); exit; }

$pageTitle = 'Venta '.$venta['folio'];
require_once __DIR__ . '/../../includes/header.php';
$detalles = $db->fetchAll(
    "SELECT vd.*, p.nombre as producto, p.codigo, p.unidad_medida
     FROM ventas_detalle vd JOIN productos p ON vd.producto_id=p.id
     WHERE vd.venta_id=? AND vd.activo=1", array($id)
);
?>
<div class="page-header">
    <div><h1><i class="bi bi-receipt me-2 text-primary"></i>Venta <?= htmlspecialchars($venta['folio']) ?></h1></div>
    <div class="d-flex gap-2">
        <a href="pdf.php?id=<?= $id ?>" target="_blank" class="btn btn-danger"><i class="bi bi-file-pdf me-1"></i>Ver PDF</a>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
    </div>
</div>
<div class="card">
    <div class="card-body p-4">
        <div class="row mb-3">
            <div class="col-6">
                <h5 class="fw-bold text-primary"><?= htmlspecialchars(getSetting('empresa_nombre') ?? 'Ferretería La Curva') ?></h5>
                <p class="small text-muted mb-0"><?= htmlspecialchars(getSetting('empresa_direccion') ?? '') ?></p>
            </div>
            <div class="col-6 text-end">
                <div class="p-3 border rounded d-inline-block">
                    <div class="fs-5 fw-bold text-primary">FACTURA</div>
                    <div class="fw-bold"><?= htmlspecialchars($venta['folio']) ?></div>
                    <div class="text-muted small"><?= date('d/m/Y', strtotime($venta['fecha'])) ?></div>
                    <div class="mt-1"><span class="badge-<?= $venta['estado'] ?>"><?= ucfirst($venta['estado']) ?></span></div>
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <h6 class="text-muted text-uppercase small mb-1">Cliente</h6>
                <p class="fw-bold mb-1"><?= htmlspecialchars($venta['cliente_nombre']) ?></p>
                <?php if ($venta['empresa']): ?><p class="small mb-1"><?= htmlspecialchars($venta['empresa']) ?></p><?php endif; ?>
                <?php if ($venta['cliente_tel']): ?><p class="small mb-0">Tel: <?= htmlspecialchars($venta['cliente_tel']) ?></p><?php endif; ?>
            </div>
            <div class="col-md-6">
                <h6 class="text-muted text-uppercase small mb-1">Vendedor / Pago</h6>
                <p class="mb-1"><?= htmlspecialchars($venta['vendedor']) ?></p>
                <p class="mb-0"><span class="badge bg-secondary"><?= ucfirst($venta['tipo_pago']) ?></span></p>
            </div>
        </div>
        <table class="table table-bordered table-sm" style="font-size:.88rem">
            <thead class="table-dark"><tr><th>#</th><th>Código</th><th>Producto</th><th class="text-center">Cant.</th><th class="text-end">Precio</th><th class="text-end">Desc.</th><th class="text-end">Subtotal</th></tr></thead>
            <tbody>
                <?php foreach ($detalles as $i => $d): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><code><?= htmlspecialchars($d['codigo']) ?></code></td>
                    <td><?= htmlspecialchars($d['producto']) ?></td>
                    <td class="text-center"><?= number_format($d['cantidad'],2) ?> <?= $d['unidad_medida'] ?></td>
                    <td class="text-end">Q <?= number_format($d['precio_unitario'],2) ?></td>
                    <td class="text-end"><?= $d['descuento'] > 0 ? 'Q '.number_format($d['descuento'],2) : '-' ?></td>
                    <td class="text-end fw-bold">Q <?= number_format($d['subtotal'],2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="row justify-content-end">
            <div class="col-md-4">
                <table class="table table-borderless table-sm mb-0">
                    <tr><td class="text-muted">Subtotal:</td><td class="text-end">Q <?= number_format($venta['subtotal'],2) ?></td></tr>
                    <?php if ($venta['descuento'] > 0): ?><tr><td class="text-muted">Descuento:</td><td class="text-end text-danger">-Q <?= number_format($venta['descuento'],2) ?></td></tr><?php endif; ?>
                    <tr style="display:none"><td class="text-muted">IVA (5%):</td><td class="text-end">Q <?= number_format($venta['iva'],2) ?></td></tr>
                    <tr class="border-top"><td class="fw-bold fs-5">TOTAL:</td><td class="text-end fw-bold fs-5 text-success">Q <?= number_format($venta['total'],2) ?></td></tr>
                </table>
            </div>
        </div>
        <?php if ($venta['notas']): ?><div class="mt-3 p-2 bg-light rounded small"><strong>Notas:</strong> <?= htmlspecialchars($venta['notas']) ?></div><?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$id  = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
$new = isset($_GET['new']);

if (!$id) { header('Location: index.php'); exit; }

$venta = $db->fetchOne(
    'SELECT v.*,
            CONCAT(c.nombre," ",c.apellido) AS cliente_nombre,
            c.empresa AS cliente_empresa, c.rfc AS cliente_nit,
            c.telefono AS cliente_tel, c.direccion AS cliente_dir,
            c.email AS cliente_email,
            CONCAT(u.nombre," ",u.apellido) AS vendedor
     FROM ventas v
     JOIN clientes c ON v.cliente_id = c.id
     JOIN usuarios u ON v.usuario_id = u.id
     WHERE v.id = ? AND v.activo = 1',
    array($id)
);
if (!$venta) { header('Location: index.php'); exit; }

$detalle = $db->fetchAll(
    'SELECT vd.*, p.nombre AS prod_nombre, p.codigo AS prod_codigo, p.unidad_medida
     FROM ventas_detalle vd
     JOIN productos p ON vd.producto_id = p.id
     WHERE vd.venta_id = ? AND vd.activo = 1',
    array($id)
);

$pagos = $db->fetchAll(
    'SELECT vp.*, CONCAT(u.nombre," ",u.apellido) AS registrado_por
     FROM ventas_pagos vp
     JOIN usuarios u ON vp.usuario_id = u.id
     WHERE vp.venta_id = ? AND vp.activo = 1
     ORDER BY vp.fecha ASC, vp.id ASC',
    array($id)
);
$saldo   = (float)$venta['total'] - (float)($venta['monto_pagado'] ?? 0);
$pctPago = $venta['total'] > 0 ? min(100, (($venta['monto_pagado'] ?? 0) / $venta['total']) * 100) : 0;

$empresa = array(
    'nombre'    => getSetting('empresa_nombre')    ?: 'Ferretería La Curva',
    'nit'       => getSetting('empresa_rfc')       ?: 'CF',
    'direccion' => getSetting('empresa_direccion') ?: 'Guatemala',
    'telefono'  => getSetting('empresa_telefono')  ?: '',
    'email'     => getSetting('empresa_email')     ?: '',
);

// Ruta del logo
$logoPath = APP_PATH . '/uploads/logos/logo_1774730587.jpeg';
$logoB64  = '';
if (file_exists($logoPath)) {
    $logoB64 = 'data:image/jpeg;base64,' . base64_encode(file_get_contents($logoPath));
}
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Factura <?= htmlspecialchars($venta['folio']) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,sans-serif;font-size:10.5pt;background:#d1d5db;color:#1a1a1a}

/* ── Toolbar ── */
.toolbar{background:#1c1917;padding:10px 18px;display:flex;gap:10px;align-items:center;
         position:fixed;top:0;width:100%;z-index:100;box-shadow:0 2px 6px rgba(0,0,0,.5)}
.toolbar button,.toolbar a{padding:8px 18px;border:none;border-radius:5px;cursor:pointer;
    font-size:13px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:5px}
.btn-pdf {background:#dc2626;color:#fff}
.btn-new {background:#16a34a;color:#fff}
.btn-hist{background:#d97706;color:#fff}
.btn-back{background:#57534e;color:#fff}
.tip{color:#a8a29e;font-size:11px;margin-left:8px}

.wrap{margin-top:58px;padding:24px;display:flex;justify-content:center}
.page{width:210mm;background:#fff;border-radius:4px;box-shadow:0 4px 28px rgba(0,0,0,.25);overflow:hidden}

/* ── Banda superior naranja ferretería ── */
.top-band{background:linear-gradient(90deg,#b45309 0%,#f59e0b 60%,#b45309 100%);height:7px}

/* ── Cabecera de factura ── */
.factura-header{display:flex;justify-content:space-between;align-items:stretch;padding:0}

/* Lado empresa: fondo oscuro tipo acero */
.company-side{
    background:linear-gradient(135deg,#1c1917 70%,#292524 100%);
    color:#fff;padding:16px 22px 16px 20px;width:58%;min-height:115px;
    display:flex;flex-direction:column;justify-content:center
}
.logo-area{display:flex;align-items:center;gap:14px;margin-bottom:8px}
.logo-area img{height:52px;width:52px;object-fit:contain;border-radius:6px;
               background:#fff;padding:4px;box-shadow:0 2px 6px rgba(0,0,0,.4)}
.logo-icon{font-size:38px;line-height:1}
.company-name{font-size:22pt;font-weight:900;letter-spacing:1px;line-height:1;color:#fff}
.company-name span{color:#f59e0b}
.company-tagline{font-size:8pt;color:#d6d3d1;margin-top:2px;font-style:italic}
.company-data{font-size:8pt;color:#a8a29e;margin-top:7px;line-height:1.75}

/* Lado folio: borde naranja */
.factura-side{
    background:#fffbeb;border-left:5px solid #f59e0b;
    padding:18px 20px;width:42%;display:flex;flex-direction:column;
    justify-content:center;align-items:flex-end;text-align:right
}
.factura-label{font-size:20pt;font-weight:900;letter-spacing:4px;color:#92400e;line-height:1}
.factura-folio{font-size:13pt;font-weight:700;color:#78350f;margin-top:4px;
               background:#fde68a;display:inline-block;padding:3px 13px;border-radius:4px}
.factura-fecha{font-size:8.5pt;color:#78350f;margin-top:5px}
.factura-estado{margin-top:6px}
.badge-pagada  {display:inline-block;padding:3px 14px;border-radius:20px;background:#dcfce7;color:#166534;font-size:8pt;font-weight:700}
.badge-pendiente{display:inline-block;padding:3px 14px;border-radius:20px;background:#fef9c3;color:#92400e;font-size:8pt;font-weight:700}
.badge-cancelada{display:inline-block;padding:3px 14px;border-radius:20px;background:#fee2e2;color:#991b1b;font-size:8pt;font-weight:700}
.badge-parcial {display:inline-block;padding:3px 14px;border-radius:20px;background:#ffedd5;color:#9a3412;font-size:8pt;font-weight:700}

/* ── Separador naranja ── */
.sep-bar{height:4px;background:linear-gradient(90deg,#b45309 0%,#f59e0b 50%,#b45309 100%)}

/* ── Cuerpo ── */
.body-pad{padding:16px 20px}

/* ── Grid info cliente/doc ── */
.igrid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px}
.ibox{border:1px solid #e7e5e4;border-radius:6px;padding:11px 14px;background:#fafaf9}
.ibox-title{font-size:7pt;text-transform:uppercase;letter-spacing:1.5px;color:#92400e;
            margin-bottom:6px;font-weight:700;border-bottom:2px solid #f59e0b;
            padding-bottom:4px;display:inline-block}
.ibox .mn{font-size:11pt;font-weight:700;margin-bottom:2px}
.ibox p{font-size:9pt;color:#57534e;margin-bottom:2px}

/* ── Tabla de productos ── */
table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:9.5pt}
thead tr{background:#1c1917;color:#fff}
th{padding:8px 9px;font-size:8.5pt;text-align:left;letter-spacing:.3px}
td{padding:7px 9px;border-bottom:1px solid #f5f5f4}
tbody tr:nth-child(even) td{background:#fafaf9}
tbody tr:last-child td{border-bottom:2px solid #f59e0b}
.r{text-align:right}.c{text-align:center}

/* Icono de herramienta en columna prod */
.prod-icon{color:#b45309;font-size:10pt;margin-right:4px}

/* ── Totales ── */
.tot-area{display:flex;justify-content:flex-end;margin-bottom:16px}
.tot-box{width:270px;border:1px solid #e7e5e4;border-radius:6px;overflow:hidden}
.tot-row{display:flex;justify-content:space-between;padding:6px 12px;font-size:10pt;border-bottom:1px solid #f5f5f4}
.tot-row:last-child{border-bottom:none}
.tot-row .lbl{color:#78716c}
.tot-grand{font-size:13pt;font-weight:900;background:#1c1917;color:#f59e0b;
           padding:10px 14px;display:flex;justify-content:space-between}

/* ── Pie de info ── */
.bot-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px}

/* ── Footer factura ── */
.fact-foot{
    background:linear-gradient(90deg,#1c1917,#292524);
    color:#a8a29e;text-align:center;font-size:8pt;padding:11px 14px;line-height:1.9
}
.fact-foot strong{color:#f59e0b}
.fact-foot .slogan{font-size:9pt;color:#d6d3d1;font-style:italic;margin-bottom:2px}

/* ── Banner nuevo ── */
.new-banner{background:#ecfdf5;border:1px solid #86efac;border-radius:6px;padding:10px 14px;
            margin-bottom:14px;display:flex;align-items:center;gap:10px;color:#166534}
.new-banner .ico{font-size:22px;flex-shrink:0}

/* ── Tabla abonos ── */
.abonos-table th{background:#f5f5f4;color:#1c1917}

@media print{
  .toolbar{display:none!important}
  .wrap{margin:0;padding:0}
  body{background:#fff}
  .page{box-shadow:none;border-radius:0;width:100%}
  .new-banner{display:none}
}
</style>
</head>
<body>

<div class="toolbar">
    <button class="btn-pdf" onclick="window.print()">🖨 Imprimir / Guardar PDF</button>
    <a href="crear.php" class="btn-new">➕ Nueva Venta</a>
    <a href="index.php" class="btn-hist">📋 Historial</a>
    <a href="<?= APP_URL ?>/index.php" class="btn-back">🏠 Inicio</a>
    <span class="tip">Selecciona <strong>"Guardar como PDF"</strong> en el diálogo de impresión.</span>
</div>

<div class="wrap"><div class="page">

<?php if ($new): ?>
<div class="new-banner" style="margin:14px 20px 0">
    <div class="ico">✅</div>
    <div>
        <strong>¡Factura generada! — Folio: <?= htmlspecialchars($venta['folio']) ?></strong>
        <br><small>El stock fue descontado del inventario. Guarda o imprime esta factura.</small>
    </div>
</div>
<?php endif; ?>

<!-- BANDA SUPERIOR -->
<div class="top-band"></div>

<!-- ENCABEZADO FACTURA -->
<div class="factura-header">
    <div class="company-side">
        <div class="logo-area">
            <?php if ($logoB64): ?>
                <img src="<?= $logoB64 ?>" alt="Logo">
            <?php else: ?>
                <div class="logo-icon">🔧</div>
            <?php endif; ?>
            <div>
                <div class="company-name"><?= htmlspecialchars($empresa['nombre']) ?></div>
                <div class="company-tagline">Tu ferretería de confianza &mdash; Guatemala</div>
            </div>
        </div>
        <div class="company-data">
            <?php if ($empresa['nit']): ?><div>🪪 NIT: <?= htmlspecialchars($empresa['nit']) ?></div><?php endif; ?>
            <?php if ($empresa['direccion']): ?><div>📍 <?= htmlspecialchars($empresa['direccion']) ?></div><?php endif; ?>
            <?php if ($empresa['telefono']): ?><div>📞 <?= htmlspecialchars($empresa['telefono']) ?></div><?php endif; ?>
            <?php if ($empresa['email']): ?><div>✉ <?= htmlspecialchars($empresa['email']) ?></div><?php endif; ?>
        </div>
    </div>
    <div class="factura-side">
        <div class="factura-label">FACTURA</div>
        <div class="factura-folio"><?= htmlspecialchars($venta['folio']) ?></div>
        <div class="factura-fecha">📅 Fecha: <?= date('d/m/Y', strtotime($venta['fecha'])) ?></div>
        <div class="factura-estado">
            <span class="badge-<?= $venta['estado'] ?>"><?= strtoupper($venta['estado']) ?></span>
        </div>
    </div>
</div>
<div class="sep-bar"></div>

<!-- CUERPO -->
<div class="body-pad">

<!-- CLIENTE / DATOS FACTURA -->
<div class="igrid">
    <div class="ibox">
        <div class="ibox-title">Facturar a</div>
        <div class="mn"><?= htmlspecialchars($venta['cliente_nombre']) ?></div>
        <?php if ($venta['cliente_empresa']): ?><p><?= htmlspecialchars($venta['cliente_empresa']) ?></p><?php endif; ?>
        <?php if ($venta['cliente_nit']): ?>
            <p><strong>NIT:</strong> <?= htmlspecialchars($venta['cliente_nit']) ?></p>
        <?php endif; ?>
        <?php if ($venta['cliente_tel']): ?><p><strong>Tel:</strong> <?= htmlspecialchars($venta['cliente_tel']) ?></p><?php endif; ?>
        <?php if ($venta['cliente_dir']): ?><p><?= htmlspecialchars($venta['cliente_dir']) ?></p><?php endif; ?>
        <?php if ($venta['cliente_email']): ?><p><?= htmlspecialchars($venta['cliente_email']) ?></p><?php endif; ?>
    </div>
    <div class="ibox">
        <div class="ibox-title">Datos de la Factura</div>
        <p><strong>No. Factura:</strong> <?= htmlspecialchars($venta['folio']) ?></p>
        <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($venta['fecha'])) ?></p>
        <p><strong>Vendedor:</strong> <?= htmlspecialchars($venta['vendedor']) ?></p>
        <p><strong>Forma de pago:</strong> <?= ucfirst($venta['tipo_pago']) ?></p>
        <p><strong>Estado:</strong> <?= ucfirst($venta['estado']) ?></p>
    </div>
</div>

<!-- DETALLE DE PRODUCTOS -->
<table>
    <thead>
        <tr>
            <th class="c" style="width:28px">#</th>
            <th style="width:65px">Código</th>
            <th>Descripción del Producto / Servicio</th>
            <th class="c" style="width:44px">U/M</th>
            <th class="c" style="width:52px">Cant.</th>
            <th class="r" style="width:90px">Precio Unit.</th>
            <th class="r" style="width:76px">Desc.</th>
            <th class="r" style="width:90px">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($detalle as $i => $d): ?>
        <tr>
            <td class="c"><?= $i+1 ?></td>
            <td><code style="font-size:8pt"><?= htmlspecialchars($d['prod_codigo']) ?></code></td>
            <td><span class="prod-icon">🔩</span><?= htmlspecialchars($d['prod_nombre']) ?></td>
            <td class="c"><?= htmlspecialchars($d['unidad_medida']) ?></td>
            <td class="c"><?= number_format($d['cantidad'],2) ?></td>
            <td class="r">Q <?= number_format($d['precio_unitario'],2) ?></td>
            <td class="r"><?= $d['descuento']>0 ? 'Q '.number_format($d['descuento'],2) : '—' ?></td>
            <td class="r"><strong>Q <?= number_format($d['subtotal'],2) ?></strong></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- TOTALES -->
<div class="tot-area"><div class="tot-box">
    <div class="tot-row"><span class="lbl">Subtotal:</span><span>Q <?= number_format($venta['subtotal'],2) ?></span></div>
    <?php if ($venta['descuento'] > 0): ?>
    <div class="tot-row"><span class="lbl">Descuento:</span><span style="color:#dc2626">— Q <?= number_format($venta['descuento'],2) ?></span></div>
    <?php endif; ?>
    <div class="tot-grand"><span>TOTAL A PAGAR:</span><span>Q <?= number_format($venta['total'],2) ?></span></div>
</div></div>

<!-- PAGO / NOTAS -->
<div class="bot-grid">
    <div class="ibox">
        <div class="ibox-title">Información de Pago</div>
        <p><strong>Forma:</strong> <?= ucfirst($venta['tipo_pago']) ?></p>
        <p><strong>Estado:</strong> <span class="badge-<?= $venta['estado'] ?>"><?= strtoupper($venta['estado']) ?></span></p>
        <?php if ($venta['estado'] !== 'pagada'): ?>
        <p><strong>Total:</strong> Q <?= number_format($venta['total'], 2) ?></p>
        <p><strong>Pagado:</strong> <span style="color:#16a34a;font-weight:700">Q <?= number_format($venta['monto_pagado'] ?? 0, 2) ?></span></p>
        <p><strong>Saldo Pendiente:</strong> <span style="color:#dc2626;font-weight:700">Q <?= number_format($saldo, 2) ?></span></p>
        <div style="background:#e5e7eb;border-radius:4px;height:8px;margin-top:5px;overflow:hidden">
            <div style="background:#f59e0b;height:100%;width:<?= $pctPago ?>%"></div>
        </div>
        <p style="font-size:8pt;color:#78716c;margin-top:3px"><?= number_format($pctPago, 0) ?>% pagado</p>
        <?php endif; ?>
    </div>
    <div class="ibox">
        <div class="ibox-title">Notas / Observaciones</div>
        <p><?= $venta['notas'] ? htmlspecialchars($venta['notas']) : 'Sin notas adicionales.' ?></p>
        <div style="margin-top:10px;padding-top:8px;border-top:1px dashed #d6d3d1;font-size:8pt;color:#78716c">
            🔧 Gracias por su compra. ¡Vuelva pronto!
        </div>
    </div>
</div>

<?php if (!empty($pagos)): ?>
<!-- HISTORIAL DE ABONOS -->
<div class="ibox" style="margin-bottom:16px">
    <div class="ibox-title">Historial de Abonos Registrados</div>
    <table class="abonos-table" style="width:100%;border-collapse:collapse;font-size:8.5pt;margin-top:6px">
        <thead>
            <tr>
                <th style="padding:5px 8px;text-align:left;border-bottom:1px solid #e7e5e4">#</th>
                <th style="padding:5px 8px;text-align:left;border-bottom:1px solid #e7e5e4">Fecha</th>
                <th style="padding:5px 8px;text-align:left;border-bottom:1px solid #e7e5e4">Forma</th>
                <th style="padding:5px 8px;text-align:left;border-bottom:1px solid #e7e5e4">Referencia</th>
                <th style="padding:5px 8px;text-align:right;border-bottom:1px solid #e7e5e4">Monto</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pagos as $i => $p): ?>
            <tr>
                <td style="padding:4px 8px;border-bottom:1px solid #f5f5f4"><?= $i+1 ?></td>
                <td style="padding:4px 8px;border-bottom:1px solid #f5f5f4"><?= date('d/m/Y', strtotime($p['fecha'])) ?></td>
                <td style="padding:4px 8px;border-bottom:1px solid #f5f5f4"><?= ucfirst($p['tipo_pago']) ?></td>
                <td style="padding:4px 8px;border-bottom:1px solid #f5f5f4"><?= htmlspecialchars($p['referencia'] ?? '—') ?></td>
                <td style="padding:4px 8px;border-bottom:1px solid #f5f5f4;text-align:right;color:#b45309;font-weight:700">Q <?= number_format($p['monto'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

</div><!-- /body-pad -->

<!-- PIE FACTURA -->
<div class="fact-foot">
    <div class="slogan">🔧 Herramientas, materiales y soluciones para tu proyecto</div>
    <strong><?= htmlspecialchars($empresa['nombre']) ?></strong>
    <?php if ($empresa['direccion']): ?> &nbsp;|&nbsp; 📍 <?= htmlspecialchars($empresa['direccion']) ?><?php endif; ?>
    <?php if ($empresa['telefono']): ?> &nbsp;|&nbsp; 📞 <?= htmlspecialchars($empresa['telefono']) ?><?php endif; ?>
    <br>Factura emitida el <?= date('d/m/Y') ?> a las <?= date('H:i:s') ?> &nbsp;|&nbsp; No. Factura: <strong><?= htmlspecialchars($venta['folio']) ?></strong>
</div>

</div></div>

<?php if ($new): ?>
<script>
window.addEventListener('load', function () {
    setTimeout(function () { window.print(); }, 900);
});
</script>
<?php endif; ?>
</body>
</html>

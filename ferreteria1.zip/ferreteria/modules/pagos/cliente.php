<?php
/**
 * FERRETERÍA LA CURVA --- Detalle de deudas de un cliente específico
 */
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db         = Database::getInstance();
$clienteId  = (int)($_GET['cliente_id'] ?? 0);

$cliente = $db->fetchOne(
    "SELECT * FROM clientes WHERE id = ? AND activo = 1",
    [$clienteId]
);
if (!$cliente) { header('Location: index.php'); exit; }

$ventas = $db->fetchAll(
    "SELECT v.*,
            (v.total - COALESCE(v.monto_pagado,0)) AS saldo_pendiente,
            CONCAT(u.nombre,' ',u.apellido) AS vendedor
     FROM ventas v
     JOIN usuarios u ON v.usuario_id = u.id
     WHERE v.cliente_id = ? AND v.activo = 1
       AND v.estado IN ('pendiente','parcial')
     ORDER BY v.fecha ASC",
    [$clienteId]
);

$totales = $db->fetchOne(
    "SELECT SUM(total) AS total_deuda,
            SUM(COALESCE(monto_pagado,0)) AS total_pagado,
            SUM(total - COALESCE(monto_pagado,0)) AS saldo_total,
            COUNT(*) AS num_ventas
     FROM ventas
     WHERE cliente_id = ? AND activo = 1 AND estado IN ('pendiente','parcial')",
    [$clienteId]
);

$pageTitle = 'Deudas — ' . $cliente['nombre'] . ' ' . $cliente['apellido'];
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-person-exclamation me-2 text-warning"></i>
            <?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?>
        </h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Pagos Pendientes</a></li>
            <li class="breadcrumb-item active">Detalle Cliente</li>
        </ol></nav>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<!-- Info del cliente -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <div class="small text-muted">Empresa</div>
                <strong><?= htmlspecialchars($cliente['empresa'] ?? '—') ?></strong>
            </div>
            <div class="col-md-3">
                <div class="small text-muted">Teléfono</div>
                <strong><?= htmlspecialchars($cliente['telefono'] ?? '—') ?></strong>
            </div>
            <div class="col-md-3">
                <div class="small text-muted">Email</div>
                <strong><?= htmlspecialchars($cliente['email'] ?? '—') ?></strong>
            </div>
            <div class="col-md-3">
                <div class="small text-muted">Límite de Crédito</div>
                <strong>Q <?= number_format($cliente['limite_credito'], 2) ?></strong>
            </div>
        </div>
    </div>
</div>

<!-- Resumen -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-warning"><?= $totales['num_ventas'] ?></div>
            <div class="text-muted small">Ventas Pendientes</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-4 fw-bold text-primary">Q <?= number_format($totales['total_deuda'] ?? 0, 2) ?></div>
            <div class="text-muted small">Total Facturado</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-4 fw-bold text-success">Q <?= number_format($totales['total_pagado'] ?? 0, 2) ?></div>
            <div class="text-muted small">Total Abonado</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3 bg-danger bg-opacity-10">
            <div class="fs-4 fw-bold text-danger">Q <?= number_format($totales['saldo_total'] ?? 0, 2) ?></div>
            <div class="text-muted small">Saldo por Cobrar</div>
        </div>
    </div>
</div>

<!-- Lista de ventas con deuda -->
<div class="card shadow-sm">
    <div class="card-header"><i class="bi bi-list-ul me-2"></i>Ventas con Saldo Pendiente</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Folio</th>
                        <th>Fecha</th>
                        <th>Vendedor</th>
                        <th class="text-end">Total</th>
                        <th class="text-end">Pagado</th>
                        <th class="text-end">Saldo</th>
                        <th>Progreso</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ventas as $v):
                        $pct = $v['total'] > 0 ? ($v['monto_pagado'] / $v['total']) * 100 : 0;
                    ?>
                    <tr>
                        <td>
                            <a href="<?= APP_URL ?>/modules/ventas/pdf.php?id=<?= $v['id'] ?>" target="_blank">
                                <code class="fw-bold"><?= htmlspecialchars($v['folio']) ?></code>
                            </a>
                        </td>
                        <td><?= date('d/m/Y', strtotime($v['fecha'])) ?></td>
                        <td><small><?= htmlspecialchars($v['vendedor']) ?></small></td>
                        <td class="text-end">Q <?= number_format($v['total'], 2) ?></td>
                        <td class="text-end text-success">Q <?= number_format($v['monto_pagado'], 2) ?></td>
                        <td class="text-end fw-bold text-danger">Q <?= number_format($v['saldo_pendiente'], 2) ?></td>
                        <td style="min-width:100px">
                            <div class="progress" style="height:8px">
                                <div class="progress-bar bg-success" style="width:<?= min(100,$pct) ?>%"></div>
                            </div>
                            <small class="text-muted"><?= number_format($pct, 0) ?>%</small>
                        </td>
                        <td><span class="badge-<?= $v['estado'] ?>"><?= ucfirst($v['estado']) ?></span></td>
                        <td class="text-center text-nowrap">
                            <a href="historial.php?venta_id=<?= $v['id'] ?>"
                               class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-clock-history me-1"></i>Pagos
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
/**
 * FERRETERÍA LA CURVA --- Historial de pagos de una venta específica
 */
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db       = Database::getInstance();
$ventaId  = (int)($_GET['venta_id'] ?? 0);

$venta = $db->fetchOne(
    "SELECT v.*, CONCAT(c.nombre,' ',c.apellido) AS cliente, c.empresa, c.telefono,
            CONCAT(u.nombre,' ',u.apellido) AS vendedor
     FROM ventas v
     JOIN clientes c ON v.cliente_id = c.id
     JOIN usuarios u ON v.usuario_id = u.id
     WHERE v.id = ? AND v.activo = 1",
    [$ventaId]
);
if (!$venta) { header('Location: index.php'); exit; }

$pagos = $db->fetchAll(
    "SELECT vp.*, CONCAT(u.nombre,' ',u.apellido) AS registrado_por
     FROM ventas_pagos vp
     JOIN usuarios u ON vp.usuario_id = u.id
     WHERE vp.venta_id = ? AND vp.activo = 1
     ORDER BY vp.fecha ASC, vp.id ASC",
    [$ventaId]
);

$saldo     = (float)$venta['total'] - (float)$venta['monto_pagado'];
$pct       = $venta['total'] > 0 ? ($venta['monto_pagado'] / $venta['total']) * 100 : 0;
$pageTitle = 'Pagos — ' . $venta['folio'];
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-clock-history me-2 text-primary"></i>Historial de Pagos</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Pagos Pendientes</a></li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($venta['folio']) ?></li>
        </ol></nav>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= APP_URL ?>/modules/ventas/pdf.php?id=<?= $ventaId ?>" target="_blank"
           class="btn btn-danger"><i class="bi bi-file-pdf me-1"></i>Ver Comprobante</a>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
    </div>
</div>

<!-- Resumen de la venta -->
<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="text-muted text-uppercase small mb-3">Datos de la Venta</h6>
                <div class="row g-2">
                    <div class="col-6"><span class="text-muted small">Folio:</span><br>
                        <strong class="text-primary"><?= htmlspecialchars($venta['folio']) ?></strong></div>
                    <div class="col-6"><span class="text-muted small">Fecha:</span><br>
                        <strong><?= date('d/m/Y', strtotime($venta['fecha'])) ?></strong></div>
                    <div class="col-6"><span class="text-muted small">Cliente:</span><br>
                        <strong><?= htmlspecialchars($venta['cliente']) ?></strong></div>
                    <div class="col-6"><span class="text-muted small">Vendedor:</span><br>
                        <strong><?= htmlspecialchars($venta['vendedor']) ?></strong></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="text-muted text-uppercase small mb-3">Estado del Pago</h6>
                <div class="row g-2 mb-3">
                    <div class="col-4 text-center">
                        <div class="small text-muted">Total</div>
                        <div class="fw-bold fs-5">Q <?= number_format($venta['total'], 2) ?></div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="small text-muted">Pagado</div>
                        <div class="fw-bold fs-5 text-success">Q <?= number_format($venta['monto_pagado'], 2) ?></div>
                    </div>
                    <div class="col-4 text-center">
                        <div class="small text-muted">Saldo</div>
                        <div class="fw-bold fs-5 text-danger">Q <?= number_format($saldo, 2) ?></div>
                    </div>
                </div>
                <div class="progress" style="height:12px">
                    <div class="progress-bar bg-success" style="width:<?= min(100,$pct) ?>%">
                        <?= number_format($pct, 0) ?>%
                    </div>
                </div>
                <div class="mt-2 text-center">
                    <span class="badge-<?= $venta['estado'] ?> fs-6"><?= ucfirst($venta['estado']) ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Línea de tiempo de pagos -->
<div class="card shadow-sm">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-check me-2"></i>Abonos Registrados</span>
        <span class="badge bg-secondary"><?= count($pagos) ?> abono(s)</span>
    </div>
    <div class="card-body">
        <?php if (empty($pagos)): ?>
        <div class="text-center text-muted py-4">
            <i class="bi bi-cash-coin fs-1 d-block mb-2 opacity-25"></i>
            No hay abonos registrados para esta venta.
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Fecha</th>
                        <th>Monto Abonado</th>
                        <th>Forma de Pago</th>
                        <th>Referencia</th>
                        <th>Registrado por</th>
                        <th>Notas</th>
                        <th>Saldo Después</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $acumulado = 0;
                    foreach ($pagos as $i => $p):
                        $acumulado += $p['monto'];
                        $saldoDespues = (float)$venta['total'] - $acumulado;
                    ?>
                    <tr>
                        <td><span class="badge bg-primary"><?= $i + 1 ?></span></td>
                        <td><?= date('d/m/Y', strtotime($p['fecha'])) ?></td>
                        <td><strong class="text-success">Q <?= number_format($p['monto'], 2) ?></strong></td>
                        <td><span class="badge bg-secondary"><?= ucfirst($p['tipo_pago']) ?></span></td>
                        <td><?= htmlspecialchars($p['referencia'] ?? '—') ?></td>
                        <td><small><?= htmlspecialchars($p['registrado_por']) ?></small></td>
                        <td><small class="text-muted"><?= htmlspecialchars($p['notas'] ?? '—') ?></small></td>
                        <td>
                            <?php if ($saldoDespues <= 0): ?>
                                <span class="badge bg-success">✅ PAGADO</span>
                            <?php else: ?>
                                <span class="text-danger">Q <?= number_format($saldoDespues, 2) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-light fw-bold">
                    <tr>
                        <td colspan="2">TOTAL ABONADO</td>
                        <td class="text-success">Q <?= number_format($venta['monto_pagado'], 2) ?></td>
                        <td colspan="5"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>

        <?php if ($venta['estado'] !== 'pagada'): ?>
        <div class="text-end mt-3">
            <a href="index.php" class="btn btn-success">
                <i class="bi bi-cash me-1"></i>Registrar Nuevo Abono
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
/**
 * FERRETERÍA LA CURVA --- Módulo de Pagos y Cuentas por Cobrar
 */
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// ── Registrar un abono / pago total ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'abonar') {
    $ventaId    = (int)($_POST['venta_id']   ?? 0);
    $monto      = (float)($_POST['monto']    ?? 0);
    $tipoPago   = $_POST['tipo_pago']        ?? 'contado';
    $referencia = trim($_POST['referencia']  ?? '');
    $fecha      = $_POST['fecha']            ?? date('Y-m-d');
    $notas      = trim($_POST['notas']       ?? '');

    if ($ventaId > 0 && $monto > 0) {
        $db->beginTransaction();
        try {
            $venta = $db->fetchOne(
                'SELECT id, total, monto_pagado, estado FROM ventas WHERE id = ? AND activo = 1 FOR UPDATE',
                [$ventaId]
            );

            if (!$venta) {
                throw new Exception('Venta no encontrada.');
            }

            $totalVenta  = (float)$venta['total'];
            $yaPagado    = (float)$venta['monto_pagado'];
            $saldo       = $totalVenta - $yaPagado;

            // Ajustar monto si supera el saldo
            if ($monto > $saldo) {
                $monto = $saldo;
            }

            if ($monto <= 0) {
                throw new Exception('Esta venta ya está completamente pagada.');
            }

            $nuevoMontoPagado = $yaPagado + $monto;

            // Estado: pagada si cubre el total (con margen de 0.01 por redondeo), parcial si no
            $nuevoEstado = ($nuevoMontoPagado >= ($totalVenta - 0.01)) ? 'pagada' : 'parcial';

            // Insertar registro de pago
            $db->query(
                'INSERT INTO ventas_pagos (venta_id, usuario_id, fecha, monto, tipo_pago, referencia, notas)
                 VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$ventaId, $_SESSION['user_id'], $fecha, $monto, $tipoPago,
                 $referencia ?: null, $notas ?: null]
            );

            // Actualizar venta
            $db->query(
                'UPDATE ventas SET monto_pagado = ?, estado = ? WHERE id = ?',
                [$nuevoMontoPagado, $nuevoEstado, $ventaId]
            );

            $db->commit();

            if ($nuevoEstado === 'pagada') {
                $msg = '✅ ¡Pago completo! La venta ' . htmlspecialchars($venta['id']) . ' quedó marcada como PAGADA.';
            } else {
                $saldoRestante = $totalVenta - $nuevoMontoPagado;
                $msg = '💰 Abono de Q ' . number_format($monto, 2) . ' registrado. '
                     . 'Saldo pendiente: Q ' . number_format($saldoRestante, 2) . '.';
            }

        } catch (Exception $e) {
            $db->rollback();
            $err = 'Error: ' . $e->getMessage();
        }
    } else {
        $err = 'Datos inválidos. Verifique el monto ingresado.';
    }

    // Redirigir para evitar reenvío del formulario
    $param = $err ? ('err=' . urlencode($err)) : ('ok=' . urlencode($msg));
    header('Location: index.php?' . $param);
    exit;
}

if (isset($_GET['ok']))  $msg = $_GET['ok'];
if (isset($_GET['err'])) $err = $_GET['err'];

$pageTitle = 'Pagos y Cuentas por Cobrar';
require_once __DIR__ . '/../../includes/header.php';

// ── Ventas pendientes / parciales ────────────────────────────
$ventas = $db->fetchAll(
    "SELECT v.*,
            CONCAT(c.nombre,' ',c.apellido)  AS cliente,
            c.empresa, c.telefono            AS cliente_tel,
            CONCAT(u.nombre,' ',u.apellido)  AS vendedor,
            (v.total - COALESCE(v.monto_pagado,0)) AS saldo_pendiente
     FROM ventas v
     JOIN clientes c ON v.cliente_id = c.id
     JOIN usuarios u ON v.usuario_id = u.id
     WHERE v.activo = 1
       AND v.estado IN ('pendiente','parcial')
     ORDER BY v.fecha ASC, v.id ASC"
);

// ── Resumen por cliente ───────────────────────────────────────
$resumenClientes = $db->fetchAll(
    "SELECT c.id, CONCAT(c.nombre,' ',c.apellido) AS cliente,
            c.empresa, c.telefono,
            COUNT(v.id)                                     AS num_ventas,
            SUM(v.total)                                    AS total_deuda,
            SUM(COALESCE(v.monto_pagado,0))                 AS total_pagado,
            SUM(v.total - COALESCE(v.monto_pagado,0))       AS saldo_total,
            MIN(v.fecha) AS primera_venta
     FROM ventas v
     JOIN clientes c ON v.cliente_id = c.id
     WHERE v.activo = 1 AND v.estado IN ('pendiente','parcial')
     GROUP BY c.id, c.nombre, c.apellido, c.empresa, c.telefono
     ORDER BY saldo_total DESC"
);

// ── Totales generales ─────────────────────────────────────────
$totales = $db->fetchOne(
    "SELECT COUNT(*)                                  AS total_ventas,
            COALESCE(SUM(total),0)                    AS total_facturado,
            COALESCE(SUM(monto_pagado),0)             AS total_cobrado,
            COALESCE(SUM(total-monto_pagado),0)       AS total_pendiente
     FROM ventas
     WHERE activo = 1 AND estado IN ('pendiente','parcial')"
);
?>

<?php if ($msg): ?>
<div class="alert alert-success alert-dismissible fade show shadow-sm">
    <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($err): ?>
<div class="alert alert-danger alert-dismissible fade show shadow-sm">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-cash-coin me-2 text-warning"></i>Pagos y Cuentas por Cobrar</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Pagos Pendientes</li>
        </ol></nav>
    </div>
    <a href="<?= APP_URL ?>/modules/ventas/index.php" class="btn btn-outline-secondary">
        <i class="bi bi-cart3 me-1"></i>Ir a Ventas
    </a>
</div>

<!-- Tarjetas resumen -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-warning"><?= count($ventas) ?></div>
            <div class="text-muted small">Ventas Pendientes</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-4 fw-bold text-primary">Q <?= number_format($totales['total_facturado'] ?? 0, 2) ?></div>
            <div class="text-muted small">Total Facturado</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-4 fw-bold text-success">Q <?= number_format($totales['total_cobrado'] ?? 0, 2) ?></div>
            <div class="text-muted small">Total Cobrado</div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm text-center py-3 bg-danger bg-opacity-10">
            <div class="fs-4 fw-bold text-danger">Q <?= number_format($totales['total_pendiente'] ?? 0, 2) ?></div>
            <div class="text-muted small">Saldo por Cobrar</div>
        </div>
    </div>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3" id="tabPagos" role="tablist">
    <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tabVentas">
            <i class="bi bi-list-ul me-1"></i>Por Venta
            <span class="badge bg-danger ms-1"><?= count($ventas) ?></span>
        </button>
    </li>
    <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabClientes">
            <i class="bi bi-people me-1"></i>Por Cliente
            <span class="badge bg-secondary ms-1"><?= count($resumenClientes) ?></span>
        </button>
    </li>
</ul>

<div class="tab-content">

    <!-- TAB: Por Venta -->
    <div class="tab-pane fade show active" id="tabVentas">
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle" id="tblVentasPend">
                        <thead class="table-dark">
                            <tr>
                                <th>Folio</th>
                                <th>Fecha</th>
                                <th>Cliente</th>
                                <th>Vendedor</th>
                                <th class="text-end">Total Q</th>
                                <th class="text-end">Pagado Q</th>
                                <th class="text-end">Saldo Q</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ventas as $v): ?>
                            <?php $pct = $v['total'] > 0 ? ($v['monto_pagado'] / $v['total']) * 100 : 0; ?>
                            <tr>
                                <td>
                                    <a href="<?= APP_URL ?>/modules/ventas/pdf.php?id=<?= $v['id'] ?>" target="_blank">
                                        <code class="fw-bold"><?= htmlspecialchars($v['folio']) ?></code>
                                    </a>
                                </td>
                                <td><?= date('d/m/Y', strtotime($v['fecha'])) ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($v['cliente']) ?></strong>
                                    <?php if ($v['empresa']): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($v['empresa']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><small><?= htmlspecialchars($v['vendedor']) ?></small></td>
                                <td class="text-end fw-bold">Q <?= number_format($v['total'], 2) ?></td>
                                <td class="text-end text-success">Q <?= number_format($v['monto_pagado'], 2) ?></td>
                                <td class="text-end">
                                    <strong class="text-danger">Q <?= number_format($v['saldo_pendiente'], 2) ?></strong>
                                    <div class="progress mt-1" style="height:5px;width:80px;margin-left:auto">
                                        <div class="progress-bar bg-success" style="width:<?= min(100,$pct) ?>%"></div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <span class="badge-<?= $v['estado'] ?>"><?= ucfirst($v['estado']) ?></span>
                                </td>
                                <td class="text-center text-nowrap">
                                    <!-- Botón Abonar -->
                                    <button class="btn btn-sm btn-warning btnAbonar"
                                        data-id="<?= $v['id'] ?>"
                                        data-folio="<?= htmlspecialchars($v['folio']) ?>"
                                        data-total="<?= $v['total'] ?>"
                                        data-pagado="<?= $v['monto_pagado'] ?>"
                                        data-saldo="<?= $v['saldo_pendiente'] ?>"
                                        data-cliente="<?= htmlspecialchars($v['cliente']) ?>"
                                        title="Registrar abono parcial">
                                        <i class="bi bi-cash me-1"></i>Abonar
                                    </button>
                                    <!-- Botón Pagar Todo -->
                                    <button class="btn btn-sm btn-success btnPagarTodo"
                                        data-id="<?= $v['id'] ?>"
                                        data-folio="<?= htmlspecialchars($v['folio']) ?>"
                                        data-saldo="<?= $v['saldo_pendiente'] ?>"
                                        data-cliente="<?= htmlspecialchars($v['cliente']) ?>"
                                        title="Marcar como completamente pagada">
                                        <i class="bi bi-check-circle me-1"></i>Pagar Todo
                                    </button>
                                    <a href="historial.php?venta_id=<?= $v['id'] ?>"
                                       class="btn btn-sm btn-outline-secondary" title="Historial de pagos">
                                        <i class="bi bi-clock-history"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($ventas)): ?>
                            <tr><td colspan="9" class="text-center py-5 text-muted">
                                <i class="bi bi-check-circle fs-1 d-block mb-2 text-success opacity-50"></i>
                                ¡Sin cuentas pendientes! Todos los pagos están al día.
                            </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB: Por Cliente -->
    <div class="tab-pane fade" id="tabClientes">
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle" id="tblClientesPend">
                        <thead class="table-dark">
                            <tr>
                                <th>Cliente</th>
                                <th>Teléfono</th>
                                <th class="text-center">Ventas Pend.</th>
                                <th class="text-end">Total Deuda</th>
                                <th class="text-end">Total Pagado</th>
                                <th class="text-end">Saldo Total</th>
                                <th>Desde</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($resumenClientes as $c): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($c['cliente']) ?></strong>
                                    <?php if ($c['empresa']): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($c['empresa']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($c['telefono'] ?? '—') ?></td>
                                <td class="text-center">
                                    <span class="badge bg-warning text-dark"><?= $c['num_ventas'] ?></span>
                                </td>
                                <td class="text-end">Q <?= number_format($c['total_deuda'], 2) ?></td>
                                <td class="text-end text-success">Q <?= number_format($c['total_pagado'], 2) ?></td>
                                <td class="text-end fw-bold text-danger">Q <?= number_format($c['saldo_total'], 2) ?></td>
                                <td><small class="text-muted"><?= date('d/m/Y', strtotime($c['primera_venta'])) ?></small></td>
                                <td class="text-center">
                                    <a href="cliente.php?cliente_id=<?= $c['id'] ?>"
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye me-1"></i>Ver Detalle
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($resumenClientes)): ?>
                            <tr><td colspan="8" class="text-center py-5 text-muted">
                                <i class="bi bi-check-circle fs-1 d-block mb-2 text-success opacity-50"></i>
                                Sin clientes con deudas pendientes.
                            </td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ── Modal: Registrar Abono ───────────────────────────────── -->
<div class="modal fade" id="modalAbonar" tabindex="-1" aria-labelledby="modalAbonarLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="index.php" id="formAbonar">
                <input type="hidden" name="action"   value="abonar">
                <input type="hidden" name="venta_id" id="aVentaId">

                <div class="modal-header bg-warning">
                    <h5 class="modal-title fw-bold" id="modalAbonarLabel">
                        <i class="bi bi-cash me-2"></i>Registrar Abono
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <!-- Resumen -->
                    <div class="alert alert-light border mb-3 p-3">
                        <div class="row text-center g-0">
                            <div class="col-4">
                                <div class="small text-muted">Folio</div>
                                <strong id="aFolio" class="text-primary"></strong>
                            </div>
                            <div class="col-4">
                                <div class="small text-muted">Total</div>
                                <strong id="aTotal"></strong>
                            </div>
                            <div class="col-4">
                                <div class="small text-muted">Saldo</div>
                                <strong id="aSaldo" class="text-danger"></strong>
                            </div>
                        </div>
                        <div class="progress mt-2" style="height:8px">
                            <div class="progress-bar bg-success" id="aProgress" style="width:0%"></div>
                        </div>
                        <div class="small text-muted text-center mt-1" id="aProgressLabel"></div>
                    </div>

                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label fw-semibold">Monto del Abono <span class="text-danger">*</span></label>
                            <div class="input-group input-group-lg">
                                <span class="input-group-text fw-bold">Q</span>
                                <input type="number" name="monto" id="aMonto" class="form-control fw-bold text-end"
                                       min="0.01" step="0.01" required placeholder="0.00">
                            </div>
                            <div class="mt-2">
                                <button type="button" class="btn btn-sm btn-outline-success w-100" id="btnPagarSaldo">
                                    <i class="bi bi-check2-all me-1"></i>Pagar saldo completo (Q <span id="aSaldoBtn"></span>)
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Fecha del Pago</label>
                            <input type="date" name="fecha" id="aFecha" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Forma de Pago</label>
                            <select name="tipo_pago" class="form-select">
                                <option value="contado">Efectivo</option>
                                <option value="transferencia">Transferencia</option>
                                <option value="tarjeta">Tarjeta</option>
                                <option value="cheque">Cheque</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">No. Referencia</label>
                            <input type="text" name="referencia" class="form-control"
                                   placeholder="No. transferencia, cheque, etc. (opcional)">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Notas</label>
                            <textarea name="notas" class="form-control" rows="2"
                                      placeholder="Observaciones opcionales..."></textarea>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning btn-lg px-4 fw-bold">
                        <i class="bi bi-check-circle me-1"></i>Guardar Abono
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ── Modal: Pagar Todo ────────────────────────────────────── -->
<div class="modal fade" id="modalPagarTodo" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="index.php" id="formPagarTodo">
                <input type="hidden" name="action"   value="abonar">
                <input type="hidden" name="venta_id" id="ptVentaId">
                <input type="hidden" name="monto"    id="ptMonto">
                <input type="hidden" name="fecha"    id="ptFecha"  value="<?= date('Y-m-d') ?>">

                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title fw-bold">
                        <i class="bi bi-check-circle me-2"></i>Confirmar Pago Total
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body text-center py-4">
                    <i class="bi bi-cash-coin display-3 text-success mb-3 d-block"></i>
                    <p class="mb-1">¿Marcar la venta <strong id="ptFolio" class="text-primary"></strong> de</p>
                    <p class="mb-3"><strong id="ptCliente"></strong> como completamente pagada?</p>
                    <div class="alert alert-success py-2">
                        <strong>Saldo a saldar: Q <span id="ptSaldo"></span></strong>
                    </div>

                    <div class="row g-2 mt-2">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Forma de Pago</label>
                            <select name="tipo_pago" class="form-select form-select-sm">
                                <option value="contado">Efectivo</option>
                                <option value="transferencia">Transferencia</option>
                                <option value="tarjeta">Tarjeta</option>
                                <option value="cheque">Cheque</option>
                                <option value="otro">Otro</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">No. Referencia</label>
                            <input type="text" name="referencia" class="form-control form-control-sm"
                                   placeholder="Opcional">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success btn-lg px-4 fw-bold">
                        <i class="bi bi-check2-all me-1"></i>Confirmar Pago Total
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
// JS al final del body — después de que footer.php cargue jQuery y Bootstrap
$extraJs = <<<JS
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ── DataTables ────────────────────────────────────────────
    if (typeof $.fn !== 'undefined' && $.fn.DataTable) {
        $('#tblVentasPend').DataTable({
            language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' },
            order: [[1, 'asc']]
        });
        $('#tblClientesPend').DataTable({
            language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' },
            order: [[5, 'desc']]
        });
    }

    // ── Modal ABONAR ─────────────────────────────────────────
    var modalAbonar = new bootstrap.Modal(document.getElementById('modalAbonar'));

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.btnAbonar');
        if (!btn) return;

        var id      = btn.dataset.id;
        var folio   = btn.dataset.folio;
        var total   = parseFloat(btn.dataset.total);
        var pagado  = parseFloat(btn.dataset.pagado);
        var saldo   = parseFloat(btn.dataset.saldo);
        var pct     = total > 0 ? (pagado / total * 100) : 0;

        document.getElementById('aVentaId').value      = id;
        document.getElementById('aFolio').textContent  = folio;
        document.getElementById('aTotal').textContent  = 'Q ' + total.toFixed(2);
        document.getElementById('aSaldo').textContent  = 'Q ' + saldo.toFixed(2);
        document.getElementById('aSaldoBtn').textContent = saldo.toFixed(2);
        document.getElementById('aMonto').value        = '';
        document.getElementById('aMonto').max          = saldo;
        document.getElementById('aFecha').value        = new Date().toISOString().slice(0,10);
        document.getElementById('aProgress').style.width    = pct.toFixed(1) + '%';
        document.getElementById('aProgressLabel').textContent = pct.toFixed(1) + '% pagado — saldo Q ' + saldo.toFixed(2);

        modalAbonar.show();
        setTimeout(function () { document.getElementById('aMonto').focus(); }, 400);
    });

    // Botón "Pagar saldo completo" dentro del modal Abonar
    document.getElementById('btnPagarSaldo').addEventListener('click', function () {
        var saldoTexto = document.getElementById('aSaldoBtn').textContent;
        document.getElementById('aMonto').value = parseFloat(saldoTexto).toFixed(2);
    });

    // ── Modal PAGAR TODO ─────────────────────────────────────
    var modalPagarTodo = new bootstrap.Modal(document.getElementById('modalPagarTodo'));

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.btnPagarTodo');
        if (!btn) return;

        var id     = btn.dataset.id;
        var folio  = btn.dataset.folio;
        var saldo  = parseFloat(btn.dataset.saldo);
        var cliente = btn.dataset.cliente;

        document.getElementById('ptVentaId').value         = id;
        document.getElementById('ptMonto').value           = saldo.toFixed(2);
        document.getElementById('ptFolio').textContent     = folio;
        document.getElementById('ptCliente').textContent   = cliente;
        document.getElementById('ptSaldo').textContent     = saldo.toFixed(2);
        document.getElementById('ptFecha').value           = new Date().toISOString().slice(0,10);

        modalPagarTodo.show();
    });

    // Auto-cerrar alerts de éxito
    setTimeout(function () {
        document.querySelectorAll('.alert-success').forEach(function (el) {
            var bsAlert = bootstrap.Alert.getOrCreateInstance(el);
            bsAlert.close();
        });
    }, 5000);
});
</script>
JS;
?>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

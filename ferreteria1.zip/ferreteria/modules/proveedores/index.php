<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db = Database::getInstance();
$error = '';

if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
    $id = (int)$_GET['id'];
    $r = $db->fetchOne("SELECT activo FROM proveedores WHERE id=?", [$id]);
    if ($r) $db->query("UPDATE proveedores SET activo=? WHERE id=?", [$r['activo'] ? 0 : 1, $id]);
    header('Location: index.php?ok=1'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre   = trim($_POST['nombre'] ?? '');
    $empresa  = trim($_POST['empresa'] ?? '');
    $rfc      = trim($_POST['rfc'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion= trim($_POST['direccion'] ?? '');
    $ciudad   = trim($_POST['ciudad'] ?? '');
    $estado   = trim($_POST['estado_dir'] ?? '');
    $cp       = trim($_POST['cp'] ?? '');
    $contacto = trim($_POST['contacto'] ?? '');
    $notas    = trim($_POST['notas'] ?? '');
    $activo   = isset($_POST['activo']) ? 1 : 0;
    $id       = (int)($_POST['id'] ?? 0);

    if (empty($nombre)) {
        $error = 'El nombre es obligatorio.';
    } else {
        if ($id) {
            $db->query(
                "UPDATE proveedores SET nombre=?,empresa=?,rfc=?,email=?,telefono=?,direccion=?,ciudad=?,notas=?,activo=? WHERE id=?",
                array($nombre,$empresa,$rfc,$email,$telefono,$direccion,$ciudad,$notas,$activo,$id)
            );
        } else {
            $db->query(
                "INSERT INTO proveedores (nombre,empresa,rfc,email,telefono,direccion,ciudad,notas,activo) VALUES (?,?,?,?,?,?,?,?,?)",
                array($nombre,$empresa,$rfc,$email,$telefono,$direccion,$ciudad,$notas,$activo)
            );
        }
        header('Location: index.php?ok=1'); exit;
    }
}

$pageTitle = 'Proveedores';
require_once __DIR__ . '/../../includes/header.php';
$proveedores = $db->fetchAll("SELECT * FROM proveedores ORDER BY id DESC");
?>
<?php if (isset($_GET['ok'])): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle me-2"></i>Proveedor guardado.</div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="page-header">
    <div><h1><i class="bi bi-building me-2 text-primary"></i>Proveedores</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Proveedores</li>
        </ol></nav>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalProv" onclick="resetForm()">
        <i class="bi bi-plus-circle me-1"></i>Nuevo Proveedor
    </button>
</div>

<div class="card"><div class="card-body"><div class="table-responsive">
    <table class="table table-hover" id="tblProv">
        <thead><tr><th>#</th><th>Nombre</th><th>Empresa</th><th>Email</th><th>Telefono</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
            <?php foreach ($proveedores as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><strong><?= htmlspecialchars($p['nombre']) ?></strong></td>
                <td><?= htmlspecialchars($p['empresa'] ?? '') ?></td>
                <td><?= htmlspecialchars($p['email'] ?? '') ?></td>
                <td><?= htmlspecialchars($p['telefono'] ?? '') ?></td>
                <td><span class="badge-<?= $p['activo'] ? 'activo' : 'inactivo' ?>"><?= $p['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-outline-warning" onclick="editProv(<?= htmlspecialchars(json_encode($p)) ?>)"><i class="bi bi-pencil"></i></button>
                    <a href="?action=toggle&id=<?= $p['id'] ?>" class="btn btn-sm <?= $p['activo'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-delete"
                       data-msg="<?= $p['activo'] ? 'Desactivar proveedor?' : 'Activar proveedor?' ?>">
                        <i class="bi bi-<?= $p['activo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="modalProv" tabindex="-1">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <form method="POST">
        <input type="hidden" name="id" id="fId">
        <div class="modal-header"><h5 class="modal-title" id="mTitle">Nuevo Proveedor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Nombre *</label><input type="text" name="nombre" id="fNombre" class="form-control" required></div>
                <div class="col-md-6"><label class="form-label">Empresa</label><input type="text" name="empresa" id="fEmpresa" class="form-control"></div>
                <div class="col-md-4"><label class="form-label">NIT/RFC</label><input type="text" name="rfc" id="fRfc" class="form-control"></div>
                <div class="col-md-4"><label class="form-label">Email</label><input type="email" name="email" id="fEmail" class="form-control"></div>
                <div class="col-md-4"><label class="form-label">Telefono</label><input type="text" name="telefono" id="fTel" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Contacto</label><input type="text" name="contacto" id="fContacto" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Ciudad</label><input type="text" name="ciudad" id="fCiudad" class="form-control"></div>
                <div class="col-12"><label class="form-label">Direccion</label><input type="text" name="direccion" id="fDir" class="form-control"></div>
                <div class="col-12"><label class="form-label">Notas</label><textarea name="notas" id="fNotas" class="form-control" rows="2"></textarea></div>
                <div class="col-12"><div class="form-check form-switch">
                    <input type="checkbox" name="activo" id="fActivo" class="form-check-input" value="1" checked>
                    <label class="form-check-label" for="fActivo">Proveedor Activo</label>
                </div></div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar</button>
        </div>
        </form>
    </div></div>
</div>
<script>
const APP_URL = '<?= APP_URL ?>';
$(document).ready(function() { $('#tblProv').DataTable({ order: [[0,'desc']] }); });
function resetForm() {
    document.getElementById('fId').value='';
    document.getElementById('mTitle').textContent='Nuevo Proveedor';
    ['fNombre','fEmpresa','fRfc','fEmail','fTel','fContacto','fCiudad','fDir','fNotas'].forEach(function(id){ document.getElementById(id).value=''; });
    document.getElementById('fActivo').checked=true;
}
function editProv(p) {
    document.getElementById('fId').value=p.id;
    document.getElementById('mTitle').textContent='Editar Proveedor';
    document.getElementById('fNombre').value=p.nombre||'';
    document.getElementById('fEmpresa').value=p.empresa||'';
    document.getElementById('fRfc').value=p.rfc||'';
    document.getElementById('fEmail').value=p.email||'';
    document.getElementById('fTel').value=p.telefono||'';
    document.getElementById('fContacto').value=p.contacto||'';
    document.getElementById('fCiudad').value=p.ciudad||'';
    document.getElementById('fDir').value=p.direccion||'';
    document.getElementById('fNotas').value=p.notas||'';
    document.getElementById('fActivo').checked=p.activo==1;
    new bootstrap.Modal(document.getElementById('modalProv')).show();
}
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db      = Database::getInstance();
$IVA_PCT = 0.0;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $provId     = (int)(isset($_POST['proveedor_id']) ? $_POST['proveedor_id'] : 0);
    $fecha      = isset($_POST['fecha'])        ? $_POST['fecha']        : date('Y-m-d');
    $numFact    = trim(isset($_POST['num_factura']) ? $_POST['num_factura'] : '');
    $notas      = trim(isset($_POST['notas'])       ? $_POST['notas']       : '');
    $descGlobal = (float)(isset($_POST['descuento']) ? $_POST['descuento'] : 0);
    $productos  = isset($_POST['productos'])  ? $_POST['productos']  : array();
    $cantidades = isset($_POST['cantidades']) ? $_POST['cantidades'] : array();
    $precios    = isset($_POST['precios'])    ? $_POST['precios']    : array();
    $descuentos = isset($_POST['descuentos']) ? $_POST['descuentos'] : array();
    $subtotales = isset($_POST['subtotales']) ? $_POST['subtotales'] : array();
    $nPventa    = isset($_POST['pventa'])     ? $_POST['pventa']     : array();
    $nMayoreo   = isset($_POST['pmayoreo'])   ? $_POST['pmayoreo']   : array();
    $nP1        = isset($_POST['pp1'])        ? $_POST['pp1']        : array();
    $nP2        = isset($_POST['pp2'])        ? $_POST['pp2']        : array();

    if (!$provId || empty($productos)) {
        $error = 'Debe seleccionar un proveedor y agregar al menos un producto.';
    } else {
        $subtotal = 0;
        foreach ($subtotales as $s) $subtotal += (float)$s;
        $base     = max(0, $subtotal - $descGlobal);
        $iva      = round($base * $IVA_PCT / 100, 2);
        $total    = $base + $iva;
        $notaFull = $notas . ($numFact ? ' | Factura proveedor: '.$numFact : '');
        $folio    = generarFolio(getSetting('folio_compra_prefijo') ?: 'CMP', 'compra');
        $db->beginTransaction();
        try {
            $db->query(
                'INSERT INTO compras (folio,proveedor_id,usuario_id,fecha,subtotal,descuento,iva,total,estado,notas) VALUES (?,?,?,?,?,?,?,?,?,?)',
                array($folio,$provId,$_SESSION['user_id'],$fecha,$subtotal,$descGlobal,$iva,$total,'recibida',$notaFull)
            );
            $compraId = $db->lastInsertId();
            foreach ($productos as $i => $prodId) {
                $prodId = (int)$prodId;
                $qty    = (float)(isset($cantidades[$i]) ? $cantidades[$i] : 0);
                $pcosto = (float)(isset($precios[$i])    ? $precios[$i]    : 0);
                $desc   = (float)(isset($descuentos[$i]) ? $descuentos[$i] : 0);
                $sub    = (float)(isset($subtotales[$i]) ? $subtotales[$i] : 0);
                if ($qty <= 0 || !$prodId) continue;
                $db->query('INSERT INTO compras_detalle (compra_id,producto_id,cantidad,precio_unitario,descuento,subtotal) VALUES (?,?,?,?,?,?)',
                    array($compraId,$prodId,$qty,$pcosto,$desc,$sub));
                $prod     = $db->fetchOne('SELECT stock_actual FROM productos WHERE id=?', array($prodId));
                $anterior = $prod ? (float)$prod['stock_actual'] : 0;
                $nuevo    = $anterior + $qty;
                $sets = array('stock_actual=?','precio_costo=?');
                $vals = array($nuevo,$pcosto);
                $pv = (float)(isset($nPventa[$i])  ? $nPventa[$i]  : 0);
                $pm = (float)(isset($nMayoreo[$i]) ? $nMayoreo[$i] : 0);
                $p1 = (float)(isset($nP1[$i])      ? $nP1[$i]      : 0);
                $p2 = (float)(isset($nP2[$i])      ? $nP2[$i]      : 0);
                if ($pv > 0) { $sets[] = 'precio_venta=?';   $vals[] = $pv; }
                if ($pm > 0) { $sets[] = 'precio_mayoreo=?'; $vals[] = $pm; }
                if ($p1 > 0) { $sets[] = 'precio1=?';        $vals[] = $p1; }
                if ($p2 > 0) { $sets[] = 'precio2=?';        $vals[] = $p2; }
                $vals[] = $prodId;
                $db->query('UPDATE productos SET '.implode(',',$sets).' WHERE id=?', $vals);
                $db->query('INSERT INTO inventario_movimientos (producto_id,tipo,cantidad,stock_anterior,stock_nuevo,referencia_tipo,referencia_id,usuario_id,notas) VALUES (?,?,?,?,?,?,?,?,?)',
                    array($prodId,'entrada',$qty,$anterior,$nuevo,'compra',$compraId,$_SESSION['user_id'],'Ingreso compra '.$folio));
            }
            $db->commit();
            header('Location: pdf.php?id='.$compraId.'&new=1');
            exit;
        } catch (Exception $e) {
            $db->rollback();
            $error = 'Error al guardar la compra: '.$e->getMessage();
        }
    }
}

$pageTitle  = 'Nueva Compra';
$APP_URL_JS = APP_URL;
$IVA_JS     = $IVA_PCT / 100;
ob_start();
?>
<script>
/* ── Nueva Compra: búsqueda y gestión de productos ── */
(function($){
    var APP_URL  = '<?= $APP_URL_JS ?>';
    var TAX_RATE = <?= $IVA_JS ?>;
    var cache    = {};   // almacén de objetos producto por id

    $(document).ready(function(){
        SalesForm.init(TAX_RATE);
        if ($.fn.select2) $('.select2').select2({ width:'100%', placeholder:'— Seleccionar —' });

        /* Buscador */
        var timer;
        $('#buscarProducto').on('input', function(){
            clearTimeout(timer);
            var q = $(this).val().trim();
            $('#resultadosBusqueda').empty();
            if (q.length < 2) return;
            timer = setTimeout(function(){
                $.ajax({
                    url:      APP_URL + '/api/productos.php',
                    data:     { q: q },
                    dataType: 'json',
                    success:  function(res){ renderResultados(res, q); },
                    error:    function(){ $('#resultadosBusqueda').html('<div class="alert alert-danger py-2 mt-1">Error al conectar con el servidor.</div>'); }
                });
            }, 300);
        });

        /* Clic en agregar */
        $(document).on('click', '.btn-agregar-compra', function(){
            var pid = parseInt($(this).data('pid'));
            var p   = cache[pid];
            if (!p) return;
            agregarProductoCompra(p);
            $('#buscarProducto').val('').focus();
            $('#resultadosBusqueda').empty();
        });

        /* Cambio en cantidad/precio/descuento */
        $(document).on('input change', '.item-cantidad, .item-precio, .item-descuento', function(){
            recalcRow($(this).closest('tr'));
            SalesForm.updateTotals();
        });

        /* Quitar producto */
        $(document).on('click', '.remove-item', function(){
            $(this).closest('tr').remove();
            renumber();
            SalesForm.updateTotals();
            if ($('#items-tbody tr:not(#empty-row)').length === 0) $('#empty-row').show();
            refreshUI();
        });

        $('#desc-global').on('input', function(){ SalesForm.updateTotals(); });
    });

    function renderResultados(res, q) {
        if (!res || !res.length) {
            $('#resultadosBusqueda').html(
                '<div class="list-group mt-1"><div class="list-group-item text-muted">' +
                'Sin resultados para: <strong>' + esc(q) + '</strong></div></div>'
            );
            return;
        }
        var html = '<div class="list-group shadow-sm mt-1">';
        $.each(res, function(i, p){
            cache[p.id] = p;
            var sc = parseFloat(p.stock_actual) > 0 ? 'text-success' : 'text-warning';
            html +=
                '<div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2">' +
                '<div>' +
                '<strong>' + esc(p.nombre) + '</strong>' +
                ' <code class="text-muted small">' + esc(p.codigo) + '</code>' +
                '</div>' +
                '<div class="text-end ms-3">' +
                '<div class="fw-bold text-primary small">Costo: Q ' + flt(p.precio_costo) + '</div>' +
                '<div class="text-success small">Venta: Q ' + flt(p.precio_venta) + '</div>' +
                '<div class="' + sc + ' small">Stock: ' + p.stock_actual + '</div>' +
                '<button type="button" class="btn btn-sm btn-primary mt-1 btn-agregar-compra" data-pid="' + p.id + '">' +
                '<i class="bi bi-plus-lg me-1"></i>Agregar</button>' +
                '</div></div>';
        });
        html += '</div>';
        $('#resultadosBusqueda').html(html);
    }

    function agregarProductoCompra(p) {
        var pid = parseInt(p.id);
        if ($('tr[data-pid="' + pid + '"]').length) {
            var qi = $('tr[data-pid="' + pid + '"] .item-cantidad');
            qi.val((parseFloat(qi.val())||0) + 1).trigger('input');
            return;
        }
        var num    = $('#items-tbody tr:not(#empty-row)').length + 1;
        var pcosto = parseFloat(p.precio_costo)   || 0;
        var pventa = parseFloat(p.precio_venta)   || 0;
        var pmay   = parseFloat(p.precio_mayoreo) || 0;
        var pp1    = parseFloat(p.precio1)        || 0;
        var pp2    = parseFloat(p.precio2)        || 0;
        var stk    = parseFloat(p.stock_actual)   || 0;
        var sc     = stk > 0 ? 'text-success' : 'text-warning';

        var row =
            '<tr data-pid="' + pid + '">' +
            '<td class="text-center align-top pt-2">' + num + '</td>' +
            '<td>' +
            '<input type="hidden" name="productos[]" value="' + pid + '">' +
            '<div class="fw-semibold">' + esc(p.nombre) + '</div>' +
            '<small class="text-muted">' + esc(p.codigo) + '</small>' +
            ' <small class="' + sc + '">Stock: ' + stk + '</small>' +
            '<div class="mt-2 p-2 rounded border border-success-subtle bg-success-subtle">' +
            '<div class="small fw-bold text-success mb-1"><i class="bi bi-tags-fill me-1"></i>' +
            'Precios de Venta <small class="fw-normal text-muted">(0 = no cambiar)</small></div>' +
            '<div class="row g-1">' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio Venta</label>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="pventa[]" class="form-control" value="' + pventa.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Mayoreo</label>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="pmayoreo[]" class="form-control" value="' + pmay.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio 1</label>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="pp1[]" class="form-control" value="' + pp1.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio 2</label>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="pp2[]" class="form-control" value="' + pp2.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '</div></div>' +
            '</td>' +
            '<td class="align-top pt-2">' +
            '<input type="number" name="cantidades[]" class="form-control form-control-sm item-cantidad" value="1" min="0.01" step="0.01" style="width:80px">' +
            '</td>' +
            '<td class="align-top pt-2">' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="precios[]" class="form-control item-precio" value="' + pcosto.toFixed(2) + '" min="0" step="0.01"></div>' +
            '</td>' +
            '<td class="align-top pt-2">' +
            '<div class="input-group input-group-sm" style="width:110px"><span class="input-group-text">Q</span>' +
            '<input type="number" name="descuentos[]" class="form-control item-descuento" value="0" min="0" step="0.01"></div>' +
            '</td>' +
            '<td class="text-end align-top pt-2">' +
            '<strong class="item-subtotal-display">' + moneda(pcosto) + '</strong>' +
            '<input type="hidden" name="subtotales[]" class="item-subtotal" value="' + pcosto.toFixed(2) + '">' +
            '</td>' +
            '<td class="text-center align-top pt-2">' +
            '<button type="button" class="btn btn-sm btn-outline-danger remove-item"><i class="bi bi-trash"></i></button>' +
            '</td>' +
            '</tr>';

        $('#items-tbody').append(row);
        $('#empty-row').hide();
        SalesForm.updateTotals();
        refreshUI();
    }

    function recalcRow(row) {
        var qty  = parseFloat(row.find('.item-cantidad').val())  || 0;
        var prc  = parseFloat(row.find('.item-precio').val())    || 0;
        var disc = parseFloat(row.find('.item-descuento').val()) || 0;
        var sub  = Math.max(0, qty * prc - disc);
        row.find('.item-subtotal').val(sub.toFixed(2));
        row.find('.item-subtotal-display').text(moneda(sub));
    }

    function refreshUI() {
        var n = $('#items-tbody tr:not(#empty-row)').length;
        $('#badge-items').text(n + ' producto' + (n !== 1 ? 's' : ''));
        $('#btnGuardar').prop('disabled', n === 0);
    }

    function renumber() {
        $('#items-tbody tr:not(#empty-row)').each(function(i){ $(this).find('td:first').text(i+1); });
    }

    function moneda(v) {
        var n = parseFloat(v) || 0;
        return 'Q ' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    function flt(v) { return (parseFloat(v)||0).toFixed(2); }

    function esc(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
                        .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    }

})(jQuery);
</script>
<?php
$extraJs = ob_get_clean();
require_once __DIR__ . '/../../includes/header.php';
$proveedores = $db->fetchAll('SELECT id, nombre, empresa FROM proveedores WHERE activo=1 ORDER BY nombre');
?>

<?php if ($error): ?>
<div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-truck me-2 text-primary"></i>Nueva Compra — Ingreso de Mercadería</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item"><a href="index.php">Compras</a></li>
            <li class="breadcrumb-item active">Nueva</li>
        </ol></nav>
    </div>
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
</div>

<div class="alert alert-primary d-flex align-items-center gap-2 py-2 mb-3">
    <i class="bi bi-info-circle-fill fs-5"></i>
    <span>Al guardar: <strong>stock sube al instante</strong>, <strong>precio de costo se actualiza</strong>,
    puede editar los <strong>precios de venta</strong> y se genera el <strong>comprobante PDF</strong> automáticamente.</span>
</div>

<form method="POST" id="frmCompra">
<div class="row g-4">

    <div class="col-xl-8">

        <div class="card mb-3">
            <div class="card-header fw-semibold"><i class="bi bi-clipboard-data me-2 text-primary"></i>Datos de la Compra</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-5">
                        <label class="form-label">Proveedor <span class="text-danger">*</span></label>
                        <select name="proveedor_id" class="form-select select2" required>
                            <option value="">— Seleccionar —</option>
                            <?php foreach ($proveedores as $pv): ?>
                            <option value="<?= $pv['id'] ?>">
                                <?= htmlspecialchars($pv['nombre']) ?>
                                <?= $pv['empresa'] ? ' — '.htmlspecialchars($pv['empresa']) : '' ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Fecha</label>
                        <input type="date" name="fecha" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">No. Factura Proveedor</label>
                        <input type="text" name="num_factura" class="form-control" placeholder="Ej: A-001">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Notas</label>
                        <input type="text" name="notas" class="form-control" placeholder="Observaciones opcionales...">
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-semibold"><i class="bi bi-search me-2 text-primary"></i>Buscar Producto</div>
            <div class="card-body">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" id="buscarProducto" class="form-control"
                           placeholder="Escriba nombre o código del producto...">
                </div>
                <div id="resultadosBusqueda"></div>
                <small class="text-muted d-block mt-1">
                    <i class="bi bi-lightbulb text-warning me-1"></i>
                    Puede ajustar precio de costo y los 4 precios de venta al momento del ingreso.
                </small>
            </div>
        </div>

        <div class="card">
            <div class="card-header fw-semibold d-flex align-items-center">
                <i class="bi bi-box-seam me-2 text-primary"></i>Productos a Ingresar
                <span class="badge bg-primary ms-auto" id="badge-items">0 productos</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="text-center" style="width:36px">#</th>
                                <th>Producto / Precios de Venta</th>
                                <th style="width:88px">Cantidad</th>
                                <th style="width:145px">Precio Costo Q</th>
                                <th style="width:115px">Descuento</th>
                                <th class="text-end" style="width:110px">Subtotal</th>
                                <th style="width:40px"></th>
                            </tr>
                        </thead>
                        <tbody id="items-tbody">
                            <tr id="empty-row">
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-box-seam d-block fs-1 mb-2 opacity-25"></i>
                                    Busque productos arriba para agregarlos
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <div class="col-xl-4">
        <div class="card position-sticky" style="top:70px">
            <div class="card-header fw-semibold"><i class="bi bi-calculator me-2 text-primary"></i>Resumen de Compra</div>
            <div class="card-body">
                <div class="totals-section">
                    <div class="totals-row"><span>Subtotal</span><span id="display-subtotal">Q 0.00</span></div>
                    <div class="totals-row">
                        <span>Descuento Global</span>
                        <div class="input-group input-group-sm" style="width:130px">
                            <span class="input-group-text">Q</span>
                            <input type="number" id="desc-global" name="descuento" class="form-control text-end" value="0" min="0" step="0.01">
                        </div>
                    </div>
                    <div class="totals-row" style="display:none"><span>IVA (<?= $IVA_PCT ?>%)</span><span id="display-iva">Q 0.00</span></div>
                    <div class="totals-row total"><span class="fw-bold">TOTAL</span><span id="display-total" class="fw-bold text-primary">Q 0.00</span></div>
                </div>
                <input type="hidden" id="input-subtotal"  name="subtotal_calc" value="0">
                <input type="hidden" id="input-iva"       name="iva_calc"      value="0">
                <input type="hidden" id="input-total"     name="total_calc"    value="0">
                <input type="hidden" id="input-descuento" name="desc_calc"     value="0">
                <div class="d-grid gap-2 mt-3">
                    <button type="submit" id="btnGuardar" class="btn btn-success btn-lg" disabled>
                        <i class="bi bi-box-arrow-in-down me-2"></i>Registrar Ingreso al Inventario
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary">Cancelar</a>
                </div>
                <div class="rounded p-2 mt-3 small bg-success bg-opacity-10 border border-success border-opacity-25">
                    <div class="mb-1"><i class="bi bi-arrow-up-circle-fill text-success me-1"></i>Stock sube al instante</div>
                    <div class="mb-1"><i class="bi bi-tag-fill text-primary me-1"></i>Precios guardados en el producto</div>
                    <div><i class="bi bi-file-pdf-fill text-danger me-1"></i>PDF generado y archivado automáticamente</div>
                </div>
            </div>
        </div>
    </div>

</div>
</form>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

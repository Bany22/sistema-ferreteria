<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$id  = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
$new = isset($_GET['new']);

if (!$id) { header('Location: index.php'); exit; }

$compra = $db->fetchOne(
    'SELECT c.*, p.nombre AS proveedor_nombre, p.empresa AS prov_empresa,
            p.rfc AS prov_nit, p.telefono AS prov_tel,
            CONCAT(u.nombre," ",u.apellido) AS responsable
     FROM compras c
     JOIN proveedores p ON c.proveedor_id = p.id
     JOIN usuarios   u ON c.usuario_id   = u.id
     WHERE c.id = ? AND c.activo = 1',
    array($id)
);
if (!$compra) { header('Location: index.php'); exit; }

$detalle = $db->fetchAll(
    'SELECT cd.*, p.nombre AS prod_nombre, p.codigo AS prod_codigo, p.unidad_medida
     FROM compras_detalle cd
     JOIN productos p ON cd.producto_id = p.id
     WHERE cd.compra_id = ? AND cd.activo = 1',
    array($id)
);

$empresa = array(
    'nombre'    => getSetting('empresa_nombre')    ?: 'Ferretería La Curva',
    'nit'       => getSetting('empresa_rfc')       ?: 'CF',
    'direccion' => getSetting('empresa_direccion') ?: 'Guatemala',
    'telefono'  => getSetting('empresa_telefono')  ?: '',
    'email'     => getSetting('empresa_email')     ?: '',
);
?><!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Compra <?= htmlspecialchars($compra['folio']) ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,sans-serif;font-size:11pt;background:#dde3ec;color:#1a1a1a}
.toolbar{background:#0f172a;padding:10px 18px;display:flex;gap:10px;align-items:center;
         position:fixed;top:0;width:100%;z-index:100;box-shadow:0 2px 6px rgba(0,0,0,.4)}
.toolbar button,.toolbar a{padding:8px 18px;border:none;border-radius:5px;cursor:pointer;
    font-size:13px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:5px}
.btn-pdf{background:#ef4444;color:#fff}
.btn-back{background:#475569;color:#fff}
.tip{color:#94a3b8;font-size:11px;margin-left:8px}
.wrap{margin-top:58px;padding:20px;display:flex;justify-content:center}
.page{width:210mm;background:#fff;padding:14mm;border-radius:6px;box-shadow:0 4px 20px rgba(0,0,0,.18)}
.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #1e40af;padding-bottom:12px;margin-bottom:14px}
.logo-name{font-size:28pt;font-weight:900;color:#1e40af;line-height:1}
.logo-name span{color:#f59e0b}
.logo-sub{font-size:8.5pt;color:#64748b;margin-top:3px;font-style:italic}
.emp-info{font-size:8pt;color:#64748b;line-height:1.7;margin-top:4px}
.doc-box{text-align:right}
.doc-box h2{font-size:15pt;font-weight:900;letter-spacing:2px;color:#1e40af}
.folio{font-size:12pt;font-weight:700;margin-top:3px}
.fecha{font-size:9pt;color:#64748b;margin-top:2px}
.badge-ok{display:inline-block;padding:2px 12px;border-radius:20px;background:#dcfce7;color:#166534;font-size:8pt;font-weight:700;margin-top:4px}
.badge-x{display:inline-block;padding:2px 12px;border-radius:20px;background:#fee2e2;color:#991b1b;font-size:8pt;font-weight:700;margin-top:4px}
.igrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
.ibox{border:1px solid #e2e8f0;border-radius:6px;padding:10px 12px}
.ibox h4{font-size:7pt;text-transform:uppercase;letter-spacing:1.5px;color:#94a3b8;margin-bottom:5px;font-weight:700}
.ibox .mn{font-size:11pt;font-weight:700;margin-bottom:2px}
.ibox p{font-size:9pt;color:#475569;margin-bottom:1px}
table{width:100%;border-collapse:collapse;margin-bottom:14px;font-size:9.5pt}
thead tr{background:#1e40af;color:#fff}
th{padding:7px 8px;font-size:8.5pt;text-align:left}
td{padding:6px 8px;border-bottom:1px solid #f1f5f9}
tbody tr:nth-child(even) td{background:#f8fafc}
.r{text-align:right}.c{text-align:center}
.tot-wrap{display:flex;justify-content:flex-end;margin-bottom:14px}
.tot-box{width:240px}
.tot-row{display:flex;justify-content:space-between;padding:4px 0;font-size:10pt;border-bottom:1px solid #f1f5f9}
.tot-row .lbl{color:#64748b}
.tot-grand{font-size:13pt;font-weight:900;color:#1e40af;border-top:2px solid #1e40af;border-bottom:none;padding-top:7px;margin-top:3px}
.new-banner{background:#dcfce7;border:1px solid #86efac;border-radius:6px;padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;gap:10px;color:#166534}
.pgfoot{text-align:center;font-size:8pt;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:8px;margin-top:14px}
@media print{
  .toolbar{display:none!important}
  .wrap{margin:0;padding:0}
  body{background:#fff}
  .page{box-shadow:none;border-radius:0;width:100%;padding:10mm}
  .new-banner{display:none}
}
</style>
</head>
<body>

<div class="toolbar">
    <button class="btn-pdf" onclick="window.print()">🖨 Guardar PDF / Imprimir</button>
    <a href="index.php" class="btn-back">← Volver a Compras</a>
    <span class="tip">En el diálogo de impresión, selecciona <strong>"Guardar como PDF"</strong> para archivarlo.</span>
</div>

<div class="wrap"><div class="page">

<?php if ($new): ?>
<div class="new-banner">
    <span style="font-size:22px">✅</span>
    <div><strong>Compra registrada — Folio: <?= htmlspecialchars($compra['folio']) ?></strong>
    <br><small>Stock e inventario actualizados. Guarda este PDF para tus archivos.</small></div>
</div>
<?php endif; ?>

<div class="hdr">
    <div>
        <div class="logo-name">DIGI<span>COMP</span></div>
        <div class="logo-sub">Tecnología &amp; Soluciones Digitales</div>
        <div class="emp-info">
            <?php if ($empresa['nit']): ?><div>NIT: <?= htmlspecialchars($empresa['nit']) ?></div><?php endif; ?>
            <?php if ($empresa['direccion']): ?><div><?= htmlspecialchars($empresa['direccion']) ?></div><?php endif; ?>
            <?php if ($empresa['telefono']): ?><div>Tel: <?= htmlspecialchars($empresa['telefono']) ?></div><?php endif; ?>
            <?php if ($empresa['email']): ?><div><?= htmlspecialchars($empresa['email']) ?></div><?php endif; ?>
        </div>
    </div>
    <div class="doc-box">
        <h2>COMPRA</h2>
        <div class="folio"><?= htmlspecialchars($compra['folio']) ?></div>
        <div class="fecha">Fecha: <?= date('d/m/Y', strtotime($compra['fecha'])) ?></div>
        <div><?php if ($compra['estado'] === 'cancelada'): ?>
            <span class="badge-x">CANCELADA</span>
        <?php else: ?>
            <span class="badge-ok">✓ RECIBIDA</span>
        <?php endif; ?></div>
    </div>
</div>

<div class="igrid">
    <div class="ibox">
        <h4>Proveedor</h4>
        <div class="mn"><?= htmlspecialchars($compra['proveedor_nombre']) ?></div>
        <?php if ($compra['prov_empresa']): ?><p><?= htmlspecialchars($compra['prov_empresa']) ?></p><?php endif; ?>
        <?php if ($compra['prov_nit']): ?><p>NIT: <?= htmlspecialchars($compra['prov_nit']) ?></p><?php endif; ?>
        <?php if ($compra['prov_tel']): ?><p>Tel: <?= htmlspecialchars($compra['prov_tel']) ?></p><?php endif; ?>
    </div>
    <div class="ibox">
        <h4>Datos del Ingreso</h4>
        <p><strong>Folio:</strong> <?= htmlspecialchars($compra['folio']) ?></p>
        <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($compra['fecha'])) ?></p>
        <p><strong>Responsable:</strong> <?= htmlspecialchars($compra['responsable']) ?></p>
        <?php if ($compra['notas']): ?><p><strong>Ref:</strong> <?= htmlspecialchars($compra['notas']) ?></p><?php endif; ?>
    </div>
</div>

<table>
    <thead>
        <tr>
            <th class="c" style="width:28px">#</th>
            <th style="width:70px">Código</th>
            <th>Descripción</th>
            <th class="c" style="width:50px">U/M</th>
            <th class="c" style="width:60px">Cant.</th>
            <th class="r" style="width:90px">P. Costo</th>
            <th class="r" style="width:80px">Desc.</th>
            <th class="r" style="width:90px">Subtotal</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($detalle as $i => $d): ?>
        <tr>
            <td class="c"><?= $i+1 ?></td>
            <td><code style="font-size:8pt"><?= htmlspecialchars($d['prod_codigo']) ?></code></td>
            <td><?= htmlspecialchars($d['prod_nombre']) ?></td>
            <td class="c"><?= htmlspecialchars($d['unidad_medida']) ?></td>
            <td class="c"><?= number_format($d['cantidad'],2) ?></td>
            <td class="r">Q <?= number_format($d['precio_unitario'],2) ?></td>
            <td class="r"><?= $d['descuento']>0 ? 'Q '.number_format($d['descuento'],2) : '-' ?></td>
            <td class="r"><strong>Q <?= number_format($d['subtotal'],2) ?></strong></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="tot-wrap"><div class="tot-box">
    <div class="tot-row"><span class="lbl">Subtotal:</span><span>Q <?= number_format($compra['subtotal'],2) ?></span></div>
    <?php if ($compra['descuento']>0): ?>
    <div class="tot-row"><span class="lbl">Descuento:</span><span>-Q <?= number_format($compra['descuento'],2) ?></span></div>
    <?php endif; ?>
    <div class="tot-row tot-grand"><span>TOTAL:</span><span>Q <?= number_format($compra['total'],2) ?></span></div>
</div></div>

<div class="pgfoot">
    <?= htmlspecialchars($empresa['nombre']) ?> — <?= htmlspecialchars($empresa['direccion']) ?><br>
    Generado: <?= date('d/m/Y H:i:s') ?>
</div>

</div></div>

<?php if ($new): ?>
<script>window.addEventListener('load',function(){ setTimeout(function(){ window.print(); },800); });</script>
<?php endif; ?>
</body></html>

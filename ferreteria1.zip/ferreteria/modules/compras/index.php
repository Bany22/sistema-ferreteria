<?php
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db  = Database::getInstance();
$msg = $err = '';

// Cancelar compra y revertir stock
if (isset($_GET['action']) && $_GET['action'] === 'cancelar') {
    $id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);
    $c  = $db->fetchOne('SELECT * FROM compras WHERE id = ? AND activo = 1', array($id));
    if ($c && $c['estado'] !== 'cancelada') {
        try {
            $db->query("UPDATE compras SET estado = 'cancelada' WHERE id = ?", array($id));
            $dets = $db->fetchAll('SELECT * FROM compras_detalle WHERE compra_id = ? AND activo = 1', array($id));
            foreach ($dets as $d) {
                $prod  = $db->fetchOne('SELECT stock_actual FROM productos WHERE id = ?', array($d['producto_id']));
                $antes = (float)$prod['stock_actual'];
                $nuevo = max(0, $antes - (float)$d['cantidad']);
                $db->query('UPDATE productos SET stock_actual = ? WHERE id = ?', array($nuevo, $d['producto_id']));
                $db->query(
                    'INSERT INTO inventario_movimientos
                     (producto_id, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, usuario_id, notas)
                     VALUES (?,?,?,?,?,?,?,?,?)',
                    array($d['producto_id'], 'salida', $d['cantidad'], $antes, $nuevo,
                          'ajuste', $id, $_SESSION['user_id'], 'Cancelación compra '.$c['folio'])
                );
            }
            $msg = 'Compra cancelada y stock revertido.';
        } catch (Exception $e) { $err = $e->getMessage(); }
    }
}

$pageTitle = 'Historial de Compras';
require_once __DIR__ . '/../../includes/header.php';

$compras = $db->fetchAll(
    'SELECT c.*, p.nombre AS proveedor_nombre, CONCAT(u.nombre," ",u.apellido) AS responsable
     FROM compras c
     JOIN proveedores p ON c.proveedor_id = p.id
     JOIN usuarios   u ON c.usuario_id   = u.id
     WHERE c.activo = 1
     ORDER BY c.id DESC'
);
?>

<?php if ($msg): ?><div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($err) ?></div><?php endif; ?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-truck me-2 text-primary"></i>Historial de Compras</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Compras</li>
        </ol></nav>
    </div>
    <a href="crear.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Nueva Compra</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="tblCompras">
                <thead class="table-dark">
                    <tr>
                        <th>#</th><th>Folio</th><th>Proveedor</th><th>Fecha</th>
                        <th class="text-end">Subtotal</th><th class="text-end">IVA 12%</th>
                        <th class="text-end">Total Q</th><th>Estado</th><th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($compras as $c): ?>
                    <tr>
                        <td><?= $c['id'] ?></td>
                        <td><code class="fw-bold"><?= htmlspecialchars($c['folio']) ?></code></td>
                        <td><?= htmlspecialchars($c['proveedor_nombre']) ?></td>
                        <td><?= date('d/m/Y', strtotime($c['fecha'])) ?></td>
                        <td class="text-end">Q <?= number_format($c['subtotal'],2) ?></td>
                        <td class="text-end">Q <?= number_format($c['iva'],2) ?></td>
                        <td class="text-end fw-bold text-primary">Q <?= number_format($c['total'],2) ?></td>
                        <td>
                            <?php if ($c['estado'] === 'cancelada'): ?>
                                <span class="badge-cancelada">Cancelada</span>
                            <?php else: ?>
                                <span class="badge-activo">✓ Recibida</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center table-actions">
                            <a href="pdf.php?id=<?= $c['id'] ?>" target="_blank"
                               class="btn btn-sm btn-danger" title="Ver / Imprimir PDF">
                                <i class="bi bi-file-pdf-fill"></i>
                            </a>
                            <?php if ($c['estado'] !== 'cancelada'): ?>
                            <a href="?action=cancelar&id=<?= $c['id'] ?>"
                               class="btn btn-sm btn-outline-warning btn-delete"
                               data-msg="¿Cancelar esta compra? El stock ingresado será revertido.">
                                <i class="bi bi-x-circle"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
var APP_URL = '<?= APP_URL ?>';
$(document).ready(function () { $('#tblCompras').DataTable({ order: [[0,'desc']] }); });
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

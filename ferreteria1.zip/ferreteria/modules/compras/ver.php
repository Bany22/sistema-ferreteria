<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db  = Database::getInstance();
$id  = (int)($_GET['id'] ?? 0);

$compra = $db->fetchOne(
    "SELECT c.*, p.nombre as proveedor, p.empresa as prov_empresa, p.rfc as prov_rfc, p.telefono as prov_tel,
            CONCAT(u.nombre,' ',u.apellido) as usuario
     FROM compras c JOIN proveedores p ON c.proveedor_id=p.id
     JOIN usuarios u ON c.usuario_id=u.id
     WHERE c.id=? AND c.activo=1", array($id)
);
if (!$compra) { header('Location: index.php'); exit; }

$pageTitle = 'Compra '.$compra['folio'];
require_once __DIR__ . '/../../includes/header.php';
$detalles = $db->fetchAll(
    "SELECT cd.*, p.nombre as producto, p.codigo, p.unidad_medida
     FROM compras_detalle cd JOIN productos p ON cd.producto_id=p.id
     WHERE cd.compra_id=? AND cd.activo=1", array($id)
);
?>
<div class="page-header">
    <div><h1><i class="bi bi-truck me-2 text-primary"></i>Compra <?= htmlspecialchars($compra['folio']) ?></h1></div>
    <div class="d-flex gap-2">
        <a href="pdf.php?id=<?= $id ?>" target="_blank" class="btn btn-danger"><i class="bi bi-file-pdf me-1"></i>PDF</a>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Volver</a>
    </div>
</div>
<div class="card">
    <div class="card-body p-4">
        <div class="row mb-3">
            <div class="col-6">
                <h5 class="fw-bold text-primary"><?= htmlspecialchars(getSetting('empresa_nombre') ?? 'Ferretería La Curva') ?></h5>
                <p class="small text-muted mb-0"><?= htmlspecialchars(getSetting('empresa_direccion') ?? '') ?></p>
            </div>
            <div class="col-6 text-end">
                <div class="p-3 border rounded d-inline-block">
                    <div class="fs-5 fw-bold text-primary">COMPRA</div>
                    <div class="fw-bold"><?= htmlspecialchars($compra['folio']) ?></div>
                    <div class="text-muted small"><?= date('d/m/Y', strtotime($compra['fecha'])) ?></div>
                    <div class="mt-1"><span class="badge-<?= $compra['estado'] === 'recibida' ? 'activo' : 'cancelada' ?>"><?= ucfirst($compra['estado']) ?></span></div>
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <h6 class="text-muted text-uppercase small mb-1">Proveedor</h6>
                <p class="fw-bold mb-1"><?= htmlspecialchars($compra['proveedor']) ?></p>
                <?php if ($compra['prov_empresa']): ?><p class="small mb-0"><?= htmlspecialchars($compra['prov_empresa']) ?></p><?php endif; ?>
            </div>
            <div class="col-md-6">
                <h6 class="text-muted text-uppercase small mb-1">Responsable</h6>
                <p class="mb-0"><?= htmlspecialchars($compra['usuario']) ?></p>
                <?php if ($compra['notas']): ?><p class="small text-muted mt-1"><?= htmlspecialchars($compra['notas']) ?></p><?php endif; ?>
            </div>
        </div>
        <table class="table table-bordered table-sm" style="font-size:.88rem">
            <thead class="table-dark"><tr><th>#</th><th>Código</th><th>Producto</th><th class="text-center">Cant.</th><th class="text-end">P. Costo</th><th class="text-end">Subtotal</th></tr></thead>
            <tbody>
                <?php foreach ($detalles as $i => $d): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><code><?= htmlspecialchars($d['codigo']) ?></code></td>
                    <td><?= htmlspecialchars($d['producto']) ?></td>
                    <td class="text-center"><?= number_format($d['cantidad'],2) ?> <?= $d['unidad_medida'] ?></td>
                    <td class="text-end">Q <?= number_format($d['precio_unitario'],2) ?></td>
                    <td class="text-end fw-bold">Q <?= number_format($d['subtotal'],2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="row justify-content-end">
            <div class="col-md-4">
                <table class="table table-borderless table-sm mb-0">
                    <tr><td class="text-muted">Subtotal:</td><td class="text-end">Q <?= number_format($compra['subtotal'],2) ?></td></tr>
                    <?php if ($compra['descuento'] > 0): ?><tr><td class="text-muted">Descuento:</td><td class="text-end text-danger">-Q <?= number_format($compra['descuento'],2) ?></td></tr><?php endif; ?>
                    <tr style="display:none"><td class="text-muted">IVA (12%):</td><td class="text-end">Q <?= number_format($compra['iva'],2) ?></td></tr>
                    <tr class="border-top"><td class="fw-bold fs-5">TOTAL:</td><td class="text-end fw-bold fs-5 text-primary">Q <?= number_format($compra['total'],2) ?></td></tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

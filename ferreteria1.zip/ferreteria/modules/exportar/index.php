<?php
/**
 * FERRETERÍA LA CURVA --- Exportación a Excel
 * Exporta: Inventario completo, Stock por categoría, Movimientos de inventario
 * Usa salida CSV con BOM UTF-8 (compatible con Excel en español)
 */
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();

$db     = Database::getInstance();
$tipo   = $_GET['tipo']   ?? '';
$desde  = $_GET['desde']  ?? date('Y-m-01');
$hasta  = $_GET['hasta']  ?? date('Y-m-d');

// ── Si se solicita descarga ──────────────────────────────────
$tiposPermitidos = ['inventario', 'stock', 'movimientos'];
if ($tipo && isset($_GET['descargar'])) {
    if (!in_array($tipo, $tiposPermitidos)) {
        http_response_code(403);
        exit('Tipo de exportación no permitido.');
    }

    $nombreArchivo = 'ferreteria_' . $tipo . '_' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $out = fopen('php://output', 'w');
    // BOM para que Excel abra correctamente en español
    fputs($out, "\xEF\xBB\xBF");

    // ── INVENTARIO / PRODUCTOS ───────────────────────────────
    if ($tipo === 'inventario') {
        fputcsv($out, ['#','Código','Nombre','Categoría','Proveedor','Stock Actual',
                       'Stock Mínimo','Precio Costo (Q)','Precio Venta (Q)','Margen %',
                       'Sección','Estado'], ';');
        $rows = $db->fetchAll(
            "SELECT p.id, p.codigo, p.nombre,
                    c.nombre AS categoria,
                    pr.nombre AS proveedor,
                    p.stock_actual, p.stock_minimo,
                    p.precio_costo, p.precio_venta,
                    CASE WHEN p.precio_costo > 0
                         THEN ROUND(((p.precio_venta - p.precio_costo) / p.precio_costo)*100, 2)
                         ELSE 0 END AS margen,
                    CONCAT(COALESCE(p.seccion_letra,''), COALESCE(p.seccion_numero,'')) AS seccion,
                    IF(p.activo=1,'Activo','Inactivo') AS estado
             FROM productos p
             LEFT JOIN categorias c   ON p.categoria_id  = c.id
             LEFT JOIN proveedores pr ON p.proveedor_id  = pr.id
             ORDER BY p.nombre"
        );
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['id'], $r['codigo'], $r['nombre'], $r['categoria'] ?? '',
                $r['proveedor'] ?? '', $r['stock_actual'], $r['stock_minimo'],
                $r['precio_costo'], $r['precio_venta'], $r['margen'],
                $r['seccion'], $r['estado']
            ], ';');
        }
    }

    // ── STOCK POR CATEGORÍA ──────────────────────────────────
    elseif ($tipo === 'stock') {
        fputcsv($out, ['Categoría','Total Productos','Productos Activos',
                       'Stock Total','Stock Bajo Mínimo',
                       'Valor Costo Total (Q)','Valor Venta Total (Q)'], ';');
        $rows = $db->fetchAll(
            "SELECT
                    COALESCE(c.nombre, 'Sin categoría') AS categoria,
                    COUNT(p.id)                          AS total_productos,
                    SUM(p.activo)                        AS productos_activos,
                    SUM(p.stock_actual)                  AS stock_total,
                    SUM(CASE WHEN p.stock_actual <= p.stock_minimo THEN 1 ELSE 0 END) AS bajo_minimo,
                    ROUND(SUM(p.stock_actual * p.precio_costo), 2)  AS valor_costo,
                    ROUND(SUM(p.stock_actual * p.precio_venta), 2)  AS valor_venta
             FROM productos p
             LEFT JOIN categorias c ON p.categoria_id = c.id
             GROUP BY c.id, c.nombre
             ORDER BY categoria"
        );
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['categoria'],
                $r['total_productos'],
                $r['productos_activos'],
                $r['stock_total'],
                $r['bajo_minimo'],
                $r['valor_costo'],
                $r['valor_venta']
            ], ';');
        }
    }

    // ── MOVIMIENTOS DE INVENTARIO ────────────────────────────
    elseif ($tipo === 'movimientos') {
        fputcsv($out, ['#','Fecha','Producto','Código','Tipo Movimiento',
                       'Cantidad','Stock Anterior','Stock Nuevo','Referencia',
                       'Usuario','Notas'], ';');
        $rows = $db->fetchAll(
            "SELECT im.id,
                    DATE_FORMAT(im.created_at,'%d/%m/%Y %H:%i') AS fecha,
                    p.nombre AS producto, p.codigo,
                    im.tipo, im.cantidad, im.stock_anterior, im.stock_nuevo,
                    CONCAT(im.referencia_tipo, COALESCE(CONCAT(' #',im.referencia_id),'')) AS referencia,
                    CONCAT(u.nombre,' ',u.apellido) AS usuario,
                    im.notas
             FROM inventario_movimientos im
             JOIN productos p ON im.producto_id = p.id
             JOIN usuarios  u ON im.usuario_id  = u.id
             WHERE im.activo = 1
               AND DATE(im.created_at) BETWEEN ? AND ?
             ORDER BY im.id DESC",
            [$desde, $hasta]
        );
        foreach ($rows as $r) {
            fputcsv($out, [
                $r['id'], $r['fecha'], $r['producto'], $r['codigo'],
                ucfirst($r['tipo']), $r['cantidad'],
                $r['stock_anterior'], $r['stock_nuevo'],
                $r['referencia'], $r['usuario'], $r['notas'] ?? ''
            ], ';');
        }
    }

    fclose($out);
    exit;
}

// ── Página principal del módulo ──────────────────────────────
$pageTitle = 'Exportar a Excel';
require_once __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-file-earmark-excel me-2 text-success"></i>Exportar a Excel</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Exportar</li>
        </ol></nav>
    </div>
</div>

<!-- Filtro de fechas (para movimientos) -->
<div class="card shadow-sm mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end" id="formFechas">
            <div class="col-auto">
                <label class="form-label mb-0 fw-semibold">Período <span class="text-muted fw-normal">(movimientos)</span></label>
            </div>
            <div class="col-auto">
                <label class="form-label mb-0 small text-muted">Desde</label>
                <input type="date" name="desde" id="inpDesde" class="form-control form-control-sm" value="<?= htmlspecialchars($desde) ?>">
            </div>
            <div class="col-auto">
                <label class="form-label mb-0 small text-muted">Hasta</label>
                <input type="date" name="hasta" id="inpHasta" class="form-control form-control-sm" value="<?= htmlspecialchars($hasta) ?>">
            </div>
            <div class="col-auto">
                <label class="form-label mb-0 small text-muted">Período rápido</label>
                <select class="form-select form-select-sm" onchange="setPeriodo(this.value)">
                    <option value="">-- Seleccionar --</option>
                    <option value="hoy">Hoy</option>
                    <option value="semana">Esta semana</option>
                    <option value="mes">Este mes</option>
                    <option value="mes_anterior">Mes anterior</option>
                    <option value="trimestre">Este trimestre</option>
                    <option value="anio">Este año</option>
                    <option value="todo">Todo el histórico</option>
                </select>
            </div>
        </form>
    </div>
</div>

<!-- Tarjetas de exportación -->
<div class="row g-4">

    <!-- INVENTARIO COMPLETO -->
    <div class="col-md-6 col-lg-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="rounded-3 p-3 me-3" style="background:#e8f5e9">
                        <i class="bi bi-box-seam fs-3 text-success"></i>
                    </div>
                    <div>
                        <h5 class="mb-0">Inventario Completo</h5>
                        <small class="text-muted">Todos los productos con precios y stock</small>
                    </div>
                </div>
                <p class="text-muted small flex-grow-1">
                    Exporta el catálogo completo: código, nombre, categoría, proveedor,
                    stock actual, mínimo, precio costo, precio venta y margen de ganancia.
                </p>
                <div class="d-flex gap-2 mt-auto">
                    <span class="badge bg-success bg-opacity-10 text-success">Sin filtro de fechas</span>
                </div>
                <a href="?tipo=inventario&descargar=1&desde=<?= $desde ?>&hasta=<?= $hasta ?>"
                   class="btn btn-success mt-3 w-100">
                    <i class="bi bi-download me-2"></i>Descargar Excel
                </a>
            </div>
        </div>
    </div>

    <!-- STOCK POR CATEGORÍA -->
    <div class="col-md-6 col-lg-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="rounded-3 p-3 me-3" style="background:#e8f5e9">
                        <i class="bi bi-tags fs-3" style="color:#2e7d32"></i>
                    </div>
                    <div>
                        <h5 class="mb-0">Stock por Categoría</h5>
                        <small class="text-muted">Resumen agrupado por categoría</small>
                    </div>
                </div>
                <p class="text-muted small flex-grow-1">
                    Resumen consolidado por categoría: total de productos, stock acumulado,
                    productos bajo mínimo, valor al costo y valor al precio de venta.
                </p>
                <div class="d-flex gap-2 mt-auto">
                    <span class="badge bg-success bg-opacity-10 text-success">Sin filtro de fechas</span>
                </div>
                <a href="?tipo=stock&descargar=1&desde=<?= $desde ?>&hasta=<?= $hasta ?>"
                   class="btn mt-3 w-100" style="background:#2e7d32;color:#fff">
                    <i class="bi bi-download me-2"></i>Descargar Excel
                </a>
            </div>
        </div>
    </div>

    <!-- MOVIMIENTOS DE INVENTARIO -->
    <div class="col-md-6 col-lg-4">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-body d-flex flex-column">
                <div class="d-flex align-items-center mb-3">
                    <div class="rounded-3 p-3 me-3" style="background:#e3f2fd">
                        <i class="bi bi-clipboard-data fs-3 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0">Movimientos de Inventario</h5>
                        <small class="text-muted">Entradas, salidas y ajustes</small>
                    </div>
                </div>
                <p class="text-muted small flex-grow-1">
                    Historial de movimientos de stock: tipo de movimiento, cantidades,
                    stock anterior y nuevo, referencias y usuario responsable.
                </p>
                <div class="d-flex gap-2 mt-auto">
                    <span class="badge bg-primary bg-opacity-10 text-primary">Filtrado por fechas</span>
                </div>
                <a href="?tipo=movimientos&descargar=1&desde=<?= $desde ?>&hasta=<?= $hasta ?>"
                   class="btn btn-primary mt-3 w-100 btn-export" data-tipo="movimientos">
                    <i class="bi bi-download me-2"></i>Descargar Excel
                </a>
            </div>
        </div>
    </div>

</div>

<!-- Nota informativa -->
<div class="alert alert-info mt-4 d-flex align-items-start gap-2">
    <i class="bi bi-info-circle-fill mt-1"></i>
    <div>
        <strong>¿Cómo abrir el archivo en Excel?</strong><br>
        Los archivos se descargan en formato <strong>CSV separado por punto y coma (;)</strong>, optimizado para Excel en español.
        Si Excel no muestra las columnas correctamente, ve a <em>Datos → Texto en columnas → Delimitado → Punto y coma</em>.
        En versiones recientes de Excel puedes simplemente hacer doble clic en el archivo y se abrirá directamente.
    </div>
</div>

<script>
function setPeriodo(v) {
    const today = new Date();
    let desde, hasta = today.toISOString().split('T')[0];
    if (v === 'hoy') {
        desde = hasta;
    } else if (v === 'semana') {
        const d = new Date(today);
        d.setDate(d.getDate() - d.getDay() + 1);
        desde = d.toISOString().split('T')[0];
    } else if (v === 'mes') {
        desde = today.getFullYear() + '-' + String(today.getMonth()+1).padStart(2,'0') + '-01';
    } else if (v === 'mes_anterior') {
        const d1 = new Date(today.getFullYear(), today.getMonth()-1, 1);
        const d2 = new Date(today.getFullYear(), today.getMonth(), 0);
        desde = d1.toISOString().split('T')[0];
        hasta = d2.toISOString().split('T')[0];
    } else if (v === 'trimestre') {
        const m = today.getMonth();
        const startMonth = Math.floor(m/3)*3;
        desde = today.getFullYear() + '-' + String(startMonth+1).padStart(2,'0') + '-01';
    } else if (v === 'anio') {
        desde = today.getFullYear() + '-01-01';
    } else if (v === 'todo') {
        desde = '2000-01-01';
    }
    if (desde) {
        document.getElementById('inpDesde').value = desde;
        document.getElementById('inpHasta').value = hasta;
        actualizarLinks();
    }
}

function actualizarLinks() {
    const desde = document.getElementById('inpDesde').value;
    const hasta  = document.getElementById('inpHasta').value;
    document.querySelectorAll('a.btn-export, a[href*="descargar=1"]').forEach(function(a) {
        const url = new URL(a.href, window.location.href);
        url.searchParams.set('desde', desde);
        url.searchParams.set('hasta', hasta);
        a.href = url.toString();
    });
}

document.getElementById('inpDesde').addEventListener('change', actualizarLinks);
document.getElementById('inpHasta').addEventListener('change', actualizarLinks);
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

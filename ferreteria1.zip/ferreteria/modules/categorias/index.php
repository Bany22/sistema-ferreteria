<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';
Auth::requireLogin();
$db = Database::getInstance();
$error = '';

if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
    $id = (int)$_GET['id'];
    $r = $db->fetchOne("SELECT activo FROM categorias WHERE id=?", [$id]);
    if ($r) $db->query("UPDATE categorias SET activo=? WHERE id=?", [$r['activo'] ? 0 : 1, $id]);
    header('Location: index.php?ok=2'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $desc   = trim($_POST['descripcion'] ?? '');
    $activo = isset($_POST['activo']) ? 1 : 0;
    $id     = (int)($_POST['id'] ?? 0);
    if (!empty($nombre)) {
        if ($id) {
            $db->query("UPDATE categorias SET nombre=?,descripcion=?,activo=? WHERE id=?", [$nombre,$desc,$activo,$id]);
        } else {
            $db->query("INSERT INTO categorias (nombre,descripcion,activo) VALUES (?,?,?)", [$nombre,$desc,$activo]);
        }
        header('Location: index.php?ok=1'); exit;
    } else {
        $error = 'El nombre es obligatorio.';
    }
}

$pageTitle = 'Categorias';
require_once __DIR__ . '/../../includes/header.php';
$categorias = $db->fetchAll("SELECT c.*, (SELECT COUNT(*) FROM productos p WHERE p.categoria_id=c.id AND p.activo=1) as num_prod FROM categorias c ORDER BY c.id DESC");
?>
<?php if (isset($_GET['ok'])): ?>
<div class="alert alert-success alert-auto-close"><i class="bi bi-check-circle me-2"></i>Operacion exitosa.</div>
<?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="page-header">
    <div><h1><i class="bi bi-tags me-2 text-primary"></i>Categorias</h1>
        <nav aria-label="breadcrumb"><ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/index.php">Inicio</a></li>
            <li class="breadcrumb-item active">Categorias</li>
        </ol></nav>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCat" onclick="resetForm()">
        <i class="bi bi-plus-circle me-1"></i>Nueva Categoria
    </button>
</div>
<div class="card"><div class="card-body"><div class="table-responsive">
    <table class="table table-hover" id="tblCat">
        <thead><tr><th>#</th><th>Nombre</th><th>Descripcion</th><th>Productos</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
            <?php foreach ($categorias as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><strong><?= htmlspecialchars($c['nombre']) ?></strong></td>
                <td><?= htmlspecialchars($c['descripcion'] ?? '') ?></td>
                <td><span class="badge bg-secondary"><?= $c['num_prod'] ?> productos</span></td>
                <td><span class="badge-<?= $c['activo'] ? 'activo' : 'inactivo' ?>"><?= $c['activo'] ? 'Activa' : 'Inactiva' ?></span></td>
                <td class="table-actions">
                    <button class="btn btn-sm btn-outline-warning" onclick="editCat(<?= htmlspecialchars(json_encode($c)) ?>)"><i class="bi bi-pencil"></i></button>
                    <a href="?action=toggle&id=<?= $c['id'] ?>" class="btn btn-sm <?= $c['activo'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-delete"
                       data-msg="<?= $c['activo'] ? 'Desactivar categoria?' : 'Activar categoria?' ?>">
                        <i class="bi bi-<?= $c['activo'] ? 'toggle-on' : 'toggle-off' ?>"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div></div></div>

<div class="modal fade" id="modalCat" tabindex="-1">
    <div class="modal-dialog"><div class="modal-content">
        <form method="POST">
        <input type="hidden" name="id" id="fId">
        <div class="modal-header"><h5 class="modal-title" id="mTitle">Nueva Categoria</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-3"><label class="form-label">Nombre *</label><input type="text" name="nombre" id="fNombre" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Descripcion</label><textarea name="descripcion" id="fDesc" class="form-control" rows="3"></textarea></div>
            <div class="form-check form-switch"><input type="checkbox" name="activo" id="fActivo" class="form-check-input" value="1" checked><label class="form-check-label" for="fActivo">Activa</label></div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Guardar</button>
        </div>
        </form>
    </div></div>
</div>
<script>
const APP_URL = '<?= APP_URL ?>';
$(document).ready(function() { $('#tblCat').DataTable(); });
function resetForm() { document.getElementById('fId').value=''; document.getElementById('mTitle').textContent='Nueva Categoria'; document.getElementById('fNombre').value=''; document.getElementById('fDesc').value=''; document.getElementById('fActivo').checked=true; }
function editCat(c) { document.getElementById('fId').value=c.id; document.getElementById('mTitle').textContent='Editar Categoria'; document.getElementById('fNombre').value=c.nombre||''; document.getElementById('fDesc').value=c.descripcion||''; document.getElementById('fActivo').checked=c.activo==1; new bootstrap.Modal(document.getElementById('modalCat')).show(); }
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>

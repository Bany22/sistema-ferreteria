// ================================================================
// DIGICOMP — JavaScript Principal
// ================================================================

$(document).ready(function () {

    /* ── Sidebar Toggle ────────────────────────────────────────── */
    function closeMobileSidebar() {
        $('#sidebar').removeClass('mobile-open');
        $('#sidebarToggle i').removeClass('bi-x').addClass('bi-list');
        $('#sidebarOverlay').fadeOut(200, function () { $(this).remove(); });
    }

    function openMobileSidebar() {
        $('#sidebar').addClass('mobile-open');
        $('#sidebarToggle i').removeClass('bi-list').addClass('bi-x');
        if (!$('#sidebarOverlay').length) {
            $('<div id="sidebarOverlay"></div>')
                .appendTo('body')
                .fadeIn(200)
                .on('click', function () { closeMobileSidebar(); });
        }
    }

    $('#sidebarToggle').on('click', function () {
        var isMobile = window.innerWidth <= 768;
        if (isMobile) {
            if ($('#sidebar').hasClass('mobile-open')) {
                closeMobileSidebar();
            } else {
                openMobileSidebar();
            }
        } else {
            /* DESKTOP: colapsa a 68px */
            $('#sidebar').toggleClass('collapsed');
            $('#content').toggleClass('expanded');
        }
    });

    /* Cerrar sidebar móvil al navegar */
    $(document).on('click', '.sidebar-menu a', function () {
        if (window.innerWidth <= 768) { closeMobileSidebar(); }
    });

    /* Ajustar al rotar/redimensionar pantalla */
    var resizeTimer;
    $(window).on('resize', function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function () {
            if (window.innerWidth > 768) {
                $('#sidebar').removeClass('mobile-open');
                $('#sidebarOverlay').remove();
                $('#sidebarToggle i').removeClass('bi-x').addClass('bi-list');
            } else {
                $('#sidebar').removeClass('collapsed');
                $('#content').removeClass('expanded');
            }
        }, 150);
    });

    /* ── DataTables defaults ──────────────────────────────────── */
    if ($.fn.DataTable) {
        $.extend(true, $.fn.dataTable.defaults, {
            language: {
                search:      'Buscar:',
                lengthMenu:  'Mostrar _MENU_',
                info:        'Mostrando _START_–_END_ de _TOTAL_',
                infoEmpty:   'Sin registros',
                zeroRecords: 'Sin resultados',
                paginate: { first:'«', last:'»', next:'›', previous:'‹' }
            },
            pageLength: 15,
            responsive: true
        });
    }

    /* ── Select2 ─────────────────────────────────────────────── */
    if ($.fn.select2) {
        $.fn.select2.defaults.set('theme', 'bootstrap-5');
        $.fn.select2.defaults.set('language', 'es');
    }

    /* ── Auto-close alertas ──────────────────────────────────── */
    setTimeout(function () {
        $('.alert-auto-close').fadeOut(500, function () { $(this).remove(); });
    }, 4000);

    /* ── Confirmar acciones peligrosas ───────────────────────── */
    $(document).on('click', '.btn-delete', function (e) {
        e.preventDefault();
        var url = $(this).data('url') || $(this).attr('href');
        var msg = $(this).data('msg') || '¿Confirmar esta acción?';
        Swal.fire({
            title: 'Confirmar',
            text:  msg,
            icon:  'warning',
            showCancelButton:   true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor:  '#6b7280',
            confirmButtonText:  'Sí, continuar',
            cancelButtonText:   'Cancelar'
        }).then(function (r) {
            if (r.isConfirmed) window.location.href = url;
        });
    });
});

// ================================================================
// SALESFORM
// ================================================================
var SalesForm = {
    taxRate: 0.05,

    init: function (rate) {
        this.taxRate = (typeof rate !== 'undefined') ? rate : 0.05;
        this._bindEvents();
        this.updateTotals();
    },

    _bindEvents: function () {
        var self = this;
        $(document).on('input change', '.item-cantidad, .item-precio, .item-descuento', function () {
            self._recalcRow($(this).closest('tr'));
            self.updateTotals();
        });
        $(document).on('change', '.price-selector', function () {
            var row = $(this).closest('tr');
            var val = parseFloat($(this).val()) || 0;
            row.find('.item-precio').val(val.toFixed(2));
            self._recalcRow(row);
            self.updateTotals();
        });
    },

    _recalcRow: function (row) {
        var qty  = parseFloat(row.find('.item-cantidad').val())  || 0;
        var prc  = parseFloat(row.find('.item-precio').val())    || 0;
        var disc = parseFloat(row.find('.item-descuento').val()) || 0;
        var sub  = Math.max(0, qty * prc - disc);
        row.find('.item-subtotal').val(sub.toFixed(2));
        row.find('.item-subtotal-display').text(fmtQ(sub));
    },

    updateTotals: function () {
        var sub = 0;
        $('.item-subtotal').each(function () { sub += parseFloat($(this).val()) || 0; });
        var desc  = parseFloat($('#desc-global').val()) || 0;
        var neto  = Math.max(0, sub - desc);
        var iva   = neto * this.taxRate;
        var total = neto + iva;
        $('#display-subtotal').text(fmtQ(sub));
        $('#display-iva').text(fmtQ(iva));
        $('#display-total').text(fmtQ(total));
        $('#input-subtotal').val(sub.toFixed(2));
        $('#input-iva').val(iva.toFixed(2));
        $('#input-total').val(total.toFixed(2));
        $('#input-descuento').val(desc.toFixed(2));
    },

    addProductVenta: function (p) {
        var pid = parseInt(p.id);
        if ($('tr[data-pid="' + pid + '"]').length) {
            var qi = $('tr[data-pid="' + pid + '"] .item-cantidad');
            qi.val((parseFloat(qi.val()) || 0) + 1).trigger('input');
            return;
        }
        var num = $('#items-tbody tr:not(#empty-row)').length + 1;
        var pv  = parseFloat(p.precio_venta)   || 0;
        var pm  = parseFloat(p.precio_mayoreo) || 0;
        var p1  = parseFloat(p.precio1)        || 0;
        var p2  = parseFloat(p.precio2)        || 0;
        var stk = parseFloat(p.stock_actual)   || 0;
        var sc  = stk > 0 ? 'text-success' : 'text-danger';
        var opts = '<option value="' + pv.toFixed(2) + '">Precio Venta — Q ' + pv.toFixed(2) + '</option>';
        if (pm > 0) opts += '<option value="' + pm.toFixed(2) + '">Mayoreo — Q ' + pm.toFixed(2) + '</option>';
        if (p1 > 0) opts += '<option value="' + p1.toFixed(2) + '">Precio 1 — Q ' + p1.toFixed(2) + '</option>';
        if (p2 > 0) opts += '<option value="' + p2.toFixed(2) + '">Precio 2 — Q ' + p2.toFixed(2) + '</option>';
        var row = '<tr data-pid="' + pid + '">' +
            '<td class="text-center">' + num + '</td>' +
            '<td><input type="hidden" name="productos[]" value="' + pid + '">' +
            '<strong>' + escHtml(p.nombre) + '</strong>' +
            '<br><small class="text-muted">' + escHtml(p.codigo) + '</small>' +
            ' <small class="' + sc + '">Stock: ' + stk + '</small></td>' +
            '<td><input type="number" name="cantidades[]" class="form-control form-control-sm item-cantidad" value="1" min="0.01" step="0.01" style="width:80px"></td>' +
            '<td><select class="form-select form-select-sm price-selector mb-1">' + opts + '</select>' +
            '<div class="input-group input-group-sm"><span class="input-group-text">Q</span>' +
            '<input type="number" name="precios[]" class="form-control item-precio" value="' + pv.toFixed(2) + '" min="0" step="0.01"></div></td>' +
            '<td><div class="input-group input-group-sm" style="width:110px"><span class="input-group-text">Q</span>' +
            '<input type="number" name="descuentos[]" class="form-control item-descuento" value="0" min="0" step="0.01"></div></td>' +
            '<td class="text-end"><strong class="item-subtotal-display">' + fmtQ(pv) + '</strong>' +
            '<input type="hidden" name="subtotales[]" class="item-subtotal" value="' + pv.toFixed(2) + '"></td>' +
            '<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger remove-item"><i class="bi bi-trash"></i></button></td>' +
            '</tr>';
        $('#items-tbody').append(row);
        this.updateTotals();
    },

    addProductCompra: function (p) {
        var pid    = parseInt(p.id);
        if ($('tr[data-pid="' + pid + '"]').length) {
            var qi = $('tr[data-pid="' + pid + '"] .item-cantidad');
            qi.val((parseFloat(qi.val()) || 0) + 1).trigger('input');
            return;
        }
        var num    = $('#items-tbody tr:not(#empty-row)').length + 1;
        var pcosto = parseFloat(p.precio_costo)   || 0;
        var pventa = parseFloat(p.precio_venta)   || 0;
        var pmay   = parseFloat(p.precio_mayoreo) || 0;
        var pp1    = parseFloat(p.precio1)        || 0;
        var pp2    = parseFloat(p.precio2)        || 0;
        var stk    = parseFloat(p.stock_actual)   || 0;
        var sc     = stk > 0 ? 'text-success' : 'text-warning';
        var row = '<tr data-pid="' + pid + '">' +
            '<td class="text-center align-top pt-2">' + num + '</td>' +
            '<td><input type="hidden" name="productos[]" value="' + pid + '">' +
            '<div class="fw-semibold">' + escHtml(p.nombre) + '</div>' +
            '<small class="text-muted">' + escHtml(p.codigo) + '</small> <small class="' + sc + '">Stock: ' + stk + '</small>' +
            '<div class="mt-2 p-2 rounded border border-success-subtle bg-success-subtle">' +
            '<div class="small fw-bold text-success mb-1"><i class="bi bi-tags-fill me-1"></i>Actualizar Precios <small class="fw-normal text-muted">(0=no cambiar)</small></div>' +
            '<div class="row g-1">' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio Venta</label><div class="input-group input-group-sm"><span class="input-group-text">Q</span><input type="number" name="pventa[]" class="form-control" value="' + pventa.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Mayoreo</label><div class="input-group input-group-sm"><span class="input-group-text">Q</span><input type="number" name="pmayoreo[]" class="form-control" value="' + pmay.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio 1</label><div class="input-group input-group-sm"><span class="input-group-text">Q</span><input type="number" name="pp1[]" class="form-control" value="' + pp1.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '<div class="col-6"><label class="form-label mb-0" style="font-size:.7rem">Precio 2</label><div class="input-group input-group-sm"><span class="input-group-text">Q</span><input type="number" name="pp2[]" class="form-control" value="' + pp2.toFixed(2) + '" min="0" step="0.01"></div></div>' +
            '</div></div></td>' +
            '<td class="align-top pt-2"><input type="number" name="cantidades[]" class="form-control form-control-sm item-cantidad" value="1" min="0.01" step="0.01" style="width:80px"></td>' +
            '<td class="align-top pt-2"><div class="input-group input-group-sm"><span class="input-group-text">Q</span><input type="number" name="precios[]" class="form-control item-precio" value="' + pcosto.toFixed(2) + '" min="0" step="0.01"></div></td>' +
            '<td class="align-top pt-2"><div class="input-group input-group-sm" style="width:110px"><span class="input-group-text">Q</span><input type="number" name="descuentos[]" class="form-control item-descuento" value="0" min="0" step="0.01"></div></td>' +
            '<td class="text-end align-top pt-2"><strong class="item-subtotal-display">' + fmtQ(pcosto) + '</strong><input type="hidden" name="subtotales[]" class="item-subtotal" value="' + pcosto.toFixed(2) + '"></td>' +
            '<td class="text-center align-top pt-2"><button type="button" class="btn btn-sm btn-outline-danger remove-item"><i class="bi bi-trash"></i></button></td>' +
            '</tr>';
        $('#items-tbody').append(row);
        this.updateTotals();
    },

    renumber: function () {
        $('#items-tbody tr:not(#empty-row)').each(function (i) {
            $(this).find('td:first').text(i + 1);
        });
    }
};

// ================================================================
// UTILIDADES
// ================================================================
function fmtQ(n) {
    var v = parseFloat(n) || 0;
    return 'Q ' + v.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function escHtml(s) {
    return String(s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function showAlert(msg, type) {
    Swal.fire({ icon: type || 'success', title: msg, timer: 2500, showConfirmButton: false });
}

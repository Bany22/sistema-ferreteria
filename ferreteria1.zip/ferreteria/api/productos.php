<?php
require_once __DIR__ . '/../includes/auth.php';
if (!Auth::isLoggedIn()) { jsonResponse(array('error'=>'No autorizado'), 401); }

$db = Database::getInstance();
$q  = trim(isset($_GET['q'])  ? $_GET['q']  : '');
$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);

if ($id) {
    $row = $db->fetchOne(
        'SELECT id, codigo, nombre, precio_costo, precio_venta, precio_mayoreo,
                precio1, precio2, stock_actual, unidad_medida, iva_porcentaje
         FROM productos WHERE id = ? AND activo = 1',
        array($id)
    );
    jsonResponse($row ?: array());
}

if (strlen($q) >= 2) {
    $rows = $db->fetchAll(
        'SELECT id, codigo, nombre, precio_costo, precio_venta, precio_mayoreo,
                precio1, precio2, stock_actual, unidad_medida, iva_porcentaje
         FROM productos
         WHERE activo = 1 AND (nombre LIKE ? OR codigo LIKE ?)
         ORDER BY nombre LIMIT 30',
        array('%'.$q.'%', '%'.$q.'%')
    );
    jsonResponse($rows);
}

jsonResponse(array());

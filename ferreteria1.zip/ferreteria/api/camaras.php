<?php
require_once __DIR__ . '/../includes/auth.php';
if (!Auth::isLoggedIn()) { jsonResponse(array('error'=>'No autorizado'), 401); }

$db = Database::getInstance();
$q  = trim(isset($_GET['q'])  ? $_GET['q']  : '');
$id = (int)(isset($_GET['id']) ? $_GET['id'] : 0);

if ($id) {
    $row = $db->fetchOne(
        'SELECT p.id, p.codigo, p.nombre, p.tipo_producto, p.precio_costo, p.precio_venta,
                p.precio_mayoreo, p.precio1, p.precio2, p.stock_actual, p.unidad_medida,
                p.iva_porcentaje, p.es_kit,
                s.marca_id, m.nombre AS marca_nombre, s.resolucion, s.tipo_camara_id,
                t.nombre AS tipo_camara, s.tiene_audio, s.tiene_altavoz, s.full_color,
                s.wiz_color, s.ir_metros, s.tecnologia
         FROM productos p
         LEFT JOIN productos_camara_specs s ON p.id = s.producto_id
         LEFT JOIN camaras_marcas m ON s.marca_id = m.id
         LEFT JOIN camaras_tipos t ON s.tipo_camara_id = t.id
         WHERE p.id = ? AND p.activo = 1',
        array($id)
    );
    jsonResponse($row ?: array());
}

if (strlen($q) >= 2) {
    $rows = $db->fetchAll(
        'SELECT p.id, p.codigo, p.nombre, p.tipo_producto, p.precio_venta,
                p.stock_actual, p.unidad_medida, p.es_kit,
                m.nombre AS marca_nombre, s.resolucion, s.tecnologia
         FROM productos p
         LEFT JOIN productos_camara_specs s ON p.id = s.producto_id
         LEFT JOIN camaras_marcas m ON s.marca_id = m.id
         WHERE p.activo = 1 AND (p.nombre LIKE ? OR p.codigo LIKE ? OR m.nombre LIKE ?)
         ORDER BY p.tipo_producto, p.nombre LIMIT 40',
        array('%'.$q.'%', '%'.$q.'%', '%'.$q.'%')
    );
    jsonResponse($rows);
}

// Listar todos los productos de cámara (para modal)
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';
$whereExtra = '';
$params = array();
if ($tipo === 'camara') {
    $whereExtra = "AND p.tipo_producto IN ('camara','kit_combo','accesorio')";
}
$rows = $db->fetchAll(
    "SELECT p.id, p.codigo, p.nombre, p.tipo_producto, p.precio_venta,
            p.stock_actual, p.unidad_medida, p.es_kit,
            m.nombre AS marca_nombre, s.resolucion, s.tecnologia
     FROM productos p
     LEFT JOIN productos_camara_specs s ON p.id = s.producto_id
     LEFT JOIN camaras_marcas m ON s.marca_id = m.id
     WHERE p.activo = 1 $whereExtra
     ORDER BY p.tipo_producto, p.nombre LIMIT 100",
    $params
);
jsonResponse($rows);
